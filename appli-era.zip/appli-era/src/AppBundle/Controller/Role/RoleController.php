<?php
/**
 * Created by PhpStorm.
 * User: Rabi
 * Date: 07/06/2017
 * Time: 14:08
 */

namespace AppBundle\Controller\Role;


use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class RoleController extends Controller
{

}