<?php
/**
 * Created by PhpStorm.
 * User: Rabi
 * Date: 08/06/2017
 * Time: 16:28
 */

namespace AppBundle\Controller\User;


use AppBundle\Form\UserDetailsType;
use AppBundle\Form\oldUserType;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;

/**
 * @Route("/mon-compte")
 */
class DefaultController extends Controller
{



}