<?php
/**
 * Created by PhpStorm.
 * User: Rabi
 * Date: 06/06/2017
 * Time: 14:52
 */

namespace AppBundle\Controller\User;


use AppBundle\Entity\Business;
use AppBundle\Entity\Cda;
use AppBundle\Entity\Gagence;
use AppBundle\Entity\Reseau;
use AppBundle\Entity\User;
use AppBundle\Form\BusinessType;
use AppBundle\Form\CdaType;
use AppBundle\Form\GagenceType;
use AppBundle\Form\ReseauType;
use AppBundle\Form\UserType;
use Doctrine\ORM\Mapping\Id;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Security\Core\Authentication\Token\UsernamePasswordToken;

/**
 * @Route("/user")
 */
class UserController extends Controller
{

    /**
     * @Route()
     */
    public function indexAction()
    {
        return $this->render('user/index.html.twig');

    }


    /**
     * @return RedirectResponse|Response
     * @Route("/add")
     */
   public function signupAction(Request $request)
   {


       $form         = $this->createForm(UserType::class, $user     = new User());
       $formBusiness = $this->createForm(BusinessType::class, $compagny = new Business());

       if ($form->handleRequest($request)->isValid() && $formBusiness->handleRequest($request)->isValid() ) {

           $user->setCreatedAt(new \DateTime());
           $user->setUpdateAt(new \DateTime());

           $compagny->setCreatedAt(new \DateTime());
           $compagny->setUpdatedAt(new \DateTime());

           // On enregistre l'utilisateur en base de données
           $em = $this->getDoctrine()->getManager();


           $em->persist($user);

           $compagny->setNetwork($user);
           $em->persist($compagny);

           $em->flush();

           $this->addFlash('success', 'L/inscription effectuée avec succes !');


           // @todo On connecte l'utilisateur automatiquement
           $token = new UsernamePasswordToken($user, null, 'main', $user->getRoles());
           $this->get('security.token_storage')->setToken($token);
           $this->get('session')->set('_security_main', serialize($token));


           return $this->redirectToRoute('app_user_user_profil');


       }

       //return $this->render('user/signup.html.twig', [
       return $this->render('default/register.html.twig', [
           'form'           => $form->createView(),
           'formBusiness'   => $formBusiness->createView(),
       ]);

   }


    /**
     * @Route("/profil")
     */

   public function profilAction(Request $request)
   {
       $user = $this->getUser();

       $formDetails = $this->createForm(UserType::class, $user);
       if ($formDetails->handleRequest($request)->isValid()) {
           $this->getDoctrine()->getManager()->flush();

           return $this->redirectToRoute('app_user_user_index');
       }
       $em = $this->getDoctrine()->getManager();
       $users = $em->getRepository(User::class)->findBy(
           ['email' => $user->getEmail() ],
           ['id' => 'ASC'] // DESC
       );
        return $this->render('user/profile.html.twig',[
            'users' => $users,
            'formDetails' => $formDetails->createView(),

        ]);
   }


    /**
     * @Route("/{id}", requirements={"id":"\d+"})
     */
    public function updateAction(Request $request, User $user)
    {

        $form = $this->createForm(UserType::class, $user);
        if ($form->handleRequest($request)->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            $this->addFlash('success', 'Utilisateur modifié avec succès.');

            return $this->redirectToRoute('app_user_user_index');
        }

        return $this->render('user/profile.html.twig', [
            'formDetails' => $form->createView(),
            'users' => $user,
        ]);
    }



    /**
     * @Route("/{id}/supprimer", requirements={"id":"\d+"})
     */
    public function deleteAction(Request $request, User $user)
    {
        $token = $request->query->get('_token');
        if (!$this->isCsrfTokenValid('USER_DELETE', $token)) {
            throw $this->createAccessDeniedException();
        }

        $em = $this->getDoctrine()->getManager();
        $em->remove($user);
        $em->flush();

        $this->addFlash('success', 'Utilisateur supprimée avec succès.');

        return $this->redirectToRoute('app_user_user_index');
    }

    /**
     * @Route("/agence")
     */

    public function agenceAction(Request $request)
    {

        return $this->render('user/agence.html.twig');
    }

    /**
     * @Route("/code/reseau")
     */
    public function addreseauAction(Request $request)
    {

        $form = $this->createForm(ReseauType::class, $reseau = new Reseau());
        if ($form->handleRequest($request)->isValid()) {

            $em = $this->getDoctrine()->getManager();
            $em->persist($reseau);
            $em->flush();


            $user = $this->getUser();
            $user->setRole('ROLE_RESEAU');
            //$user->setReseau($reseau->getCodeAffReseau());

            $em->persist($user);
            $em->flush();

            $this->addFlash('success', 'Le code affialiation ' .$reseau->getCodeAffReseau() . ' a été créé avec succès !');

               return $this->redirectToRoute('app_user_user_addreseau');
        }

        return $this->render('user/reseau/addreseau.html.twig', [
            'form' => $form->createView(),
        ]);

    }


    /**
     * @Route("/code/cda")
     */
    public function addcdaAction(Request $request)
    {

        $form = $this->createForm(CdaType::class, $cda = new Cda());
        if ($form->handleRequest($request)->isValid()) {

            $em = $this->getDoctrine()->getManager();
            $em->persist($cda);

            $user = $this->getUser();
            $user->setRole('ROLE_CDA');
            $user->setCda($cda->getCodeAffCda());
            $user->setReseau($cda->getCodeReseau());


            $em->persist($user);
            $em->flush();


            $this->addFlash('success', 'Le code affialiation ' .$cda->getCodeAffCda() . ' a été créé avec succès !');

            return $this->redirectToRoute('app_user_user_affiliate');
        }

        return $this->render('user/cda/add.cda.html.twig', [
            'form' => $form->createView(),
        ]);

    }

    /**
     * @Route("/code/gagence")
     */
    public function addgagenceAction(Request $request)
    {

        $form = $this->createForm(GagenceType::class, $gagence = new Gagence());
        if ($form->handleRequest($request)->isValid()) {

            $em = $this->getDoctrine()->getManager();
            $em->persist($gagence);

            $user = $this->getUser();

            $user->setRole('ROLE_GROUPE_AGENCE');
            $user->setGagence($gagence);

            $em->persist($user);
            $em->flush();

            $this->addFlash('success', 'Le code affialiation ' .$gagence->getCodeAffGrp() . ' a été créé avec succès !');

            return $this->redirectToRoute('app_user_user_addgagence');
        }

        return $this->render('user/gagence/gagence.html.twig', [
            'form' => $form->createView(),

        ]);

    }


    /**
     * @Route("/affiliation")
     */
    public function affiliateAction()
    {
        return $this->render('user/affiliate.html.twig');
    }

}