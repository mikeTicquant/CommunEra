<?php
/**
 * Created by PhpStorm.
 * User: Rabi
 * Date: 22/06/2017
 * Time: 11:12
 */

namespace AppBundle\Controller\Business;


use AppBundle\Entity\Business;
use AppBundle\Form\BusinessType;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;

/**
 * @Route("/entreprise")
 */
class BusinessController extends Controller
{

    /**
     * @Route()
     */
    public function addAction(Request $request){

        $form = $this->createForm(BusinessType::class, $compagny = new Business());
        if ($form->handleRequest($request)->isValid()) {

            $compagny->setCreatedAt(new \DateTime());
            $compagny->setUpdatedAt(new \DateTime());

            $em = $this->getDoctrine()->getManager();
            $em->persist($compagny);
            $em->flush();

            $this->addFlash('success', 'Votre entreprise a éré créeavec succes !');

            return $this->redirectToRoute('app_user_user_profil');
        }

        return $this->render('Business/index.html.twig', [
            'form' => $form->createView(),
        ]);

    }


}