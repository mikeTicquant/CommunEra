<?php

/**
 * Created by PhpStorm.
 * User: Rabi
 * Date: 26/06/2017
 * Time: 16:38
 */

namespace AppBundle\Controller\Notification;

use AppBundle\Entity\Notification;
use AppBundle\Form\NotificationType;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;

/**
 * @Route("/notification")
 */
class NotificationController extends Controller
{

    /**
     * @Route()
     */
    public function indexAction(Request $request)
    {
        $form = $this->createForm(NotificationType::class, $notification = new Notification());
        if ($form->handleRequest($request)->isValid()) {

            $em = $this->getDoctrine()->getManager();
            $em->persist($notification);

            $em->flush();


            $this->addFlash('success', 'Notification a été créé avec succès !');


            return $this->redirectToRoute('app_notification_notification_index');
        }

        return $this->render('notif/index.html.twig', [
            'form' => $form->createView(),
        ]);


    }

}