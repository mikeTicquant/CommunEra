<?php
/**
 * Created by PhpStorm.
 * User: Rabi
 * Date: 26/06/2017
 * Time: 16:03
 */

namespace AppBundle\Entity;


use AppBundle\Form\NotificationType;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * @ORM\Entity()
 */
class Notification extends NotificationType
{

    use IdTrait;

    /**
     * @ORM\Column()
     * @Assert\Type("string")
     * @Assert\NotNull()
     */
    private $alert;



    /**
     * @ORM\Column()
     * @Assert\NotNull()
     */
    private $liste;

    /**
     * @return mixed
     */
    public function getListe()
    {
        return $this->liste;
    }

    /**
     * @param mixed $liste
     */
    public function setListe($liste)
    {
        $this->liste = $liste;
    }

    /**
     * @ORM\Column(type="boolean", nullable=true, options={"default":false})
     */
    private $status = true;

    /**
     * @ORM\Column(type="datetime", nullable=true)
     */
    private $date_update;

    /**
     * @var string
     * @ORM\Column(nullable=true)
     * @Assert\Type("string")
     */
    private $code;


    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return mixed
     */
    public function getAlert()
    {
        return $this->alert;
    }

    /**
     * @param mixed $alert
     */
    public function setAlert($alert)
    {
        $this->alert = $alert;
    }

    /**
     * @return mixed
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * @param mixed $status
     */
    public function setStatus($status)
    {
        $this->status = $status;
    }

    /**
     * @return mixed
     */
    public function getDateUpdate()
    {
        return $this->date_update;
    }

    /**
     * @param mixed $date_update
     */
    public function setDateUpdate($date_update)
    {
        $this->date_update = $date_update;
    }

    /**
     * @return mixed
     */
    public function getCode()
    {
        return $this->code;
    }

    /**
     * @param mixed $code
     */
    public function setCode($code)
    {
        $this->code = $code;
    }


}