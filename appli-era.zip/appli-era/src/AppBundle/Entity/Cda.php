<?php
/**
 * Created by PhpStorm.
 * User: Rabi
 * Date: 19/06/2017
 * Time: 15:16
 */

namespace AppBundle\Entity;


use AppBundle\Controller\User\UserController;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
use Symfony\Component\Validator\Constraints as Assert;

/**
* @ORM\Entity()
* @UniqueEntity(fields={"code_aff_cda"}, errorPath="code_aff_cda")
 */
class Cda extends UserController
{
    /**
     * @ORM\Id()
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;


    /**
     * @ORM\Column(type="string")
     * @Assert\Type("string")
     * @Assert\NotNull()
     * @Assert\Length(min=6, max=30)
     */
    private $code_aff_cda;


    /**
     * @ORM\ManyToOne(targetEntity="Reseau")
     */
    private $code_reseau;


    public function __toString()
    {
        return $this->getId() . ' - ' . $this->getCodeAffCda();
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return mixed
     */
    public function getCodeAffCda()
    {
        return $this->code_aff_cda;
    }

    /**
     * @param mixed $code_aff_cda
     */
    public function setCodeAffCda($code_aff_cda)
    {
        $this->code_aff_cda = $code_aff_cda;
    }

    /**
     * @return mixed
     */
    public function getCodeReseau()
    {
        return $this->code_reseau;
    }

    /**
     * @param mixed $code_reseau
     */
    public function setCodeReseau($code_reseau)
    {
        $this->code_reseau = $code_reseau;
    }


}