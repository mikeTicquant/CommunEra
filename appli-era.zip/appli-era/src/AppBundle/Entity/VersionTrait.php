<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Trait VersionTrait
 *
 * @author "Emmanuel BALLERY" <emmanuel.ballery@gmail.com>
 */
trait VersionTrait
{
    /**
     * @var int
     * @ORM\Column(type="integer", columnDefinition="INT NOT NULL DEFAULT 1")
     * @Assert\NotNull()
     * @Assert\Type("int")
     * @Assert\GreaterThan(0)
     */
    private $version = 1;

    /**
     * Get Version
     *
     * @return int
     */
    public function getVersion()
    {
        return $this->version;
    }

    /**
     * Set Version
     *
     * @param int $version
     *
     * @return $this
     */
    public function setVersion($version)
    {
        $this->version = $version;

        return $this;
    }
}
