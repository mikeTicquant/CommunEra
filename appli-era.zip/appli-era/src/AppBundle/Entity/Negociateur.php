<?php
/**
 * Created by PhpStorm.
 * User: Rabi
 * Date: 19/06/2017
 * Time: 14:57
 */

namespace AppBundle\Entity;


use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity()
 */
class Negociateur
{

    use IdTrait;

    /**
     * @ORM\ManyToOne(targetEntity="Agence")
     */
    private $code_agece;

}