<?php
/**
 * Created by PhpStorm.
 * User: Rabi
 * Date: 19/06/2017
 * Time: 15:22
 */

namespace AppBundle\Entity;

use AppBundle\Controller\User\UserController;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * @ORM\Entity()
 * @UniqueEntity(fields={"code_aff_grp"}, errorPath="code_aff_grp")
 */
class Gagence extends UserController
{


    /**
     * @ORM\Id()
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;


    /**
     * @ORM\Column(type="string")
     * @Assert\Type("string")
     * @Assert\NotNull()
     * @Assert\Length(min=6, max=30)
     */
    private $code_aff_grp;


    /**
     * @ORM\ManyToOne(targetEntity="AppBundle\Entity\Gagence")
     */
    private $code_cda;


    public function __toString()
    {
        return $this->getId() . ' - ' . $this->getCodeCda();
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return mixed
     */
    public function getCodeAffGrp()
    {
        return $this->code_aff_grp;
    }

    /**
     * @param mixed $code_aff_grp
     */
    public function setCodeAffGrp($code_aff_grp)
    {
        $this->code_aff_grp = $code_aff_grp;
    }

    /**
     * @return mixed
     */
    public function getCodeCda()
    {
        return $this->code_cda;
    }

    /**
     * @param mixed $code_cda
     */
    public function setCodeCda($code_cda)
    {
        $this->code_cda = $code_cda;
    }


}