<?php
/**
 * Created by PhpStorm.
 * User: Rabi
 * Date: 07/06/2017
 * Time: 09:58
 */

namespace AppBundle\Entity;


use AppBundle\Controller\Nego\NegoController;

class Nego extends NegoController
{


}