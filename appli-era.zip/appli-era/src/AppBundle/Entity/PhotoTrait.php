<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\Validator\Constraints as Assert;


trait PhotoTrait
{
    /**
     * @var null|string
     * @ORM\Column(length=1000, nullable=true)
     * @Assert\Type("string")
     * @Assert\Length(max=1000)
     */
    private $photo;

    /**
     * @var null|UploadedFile
     * @Assert\Image()
     */
    private $photoFile;

    /**
     * Get Photo
     *
     * @return null|string
     */
    public function getPhoto()
    {
        return $this->photo;
    }

    /**
     * Set Photo
     *
     * @param null|string $photo
     *
     * @return $this
     */
    public function setPhoto($photo)
    {
        $this->photo = $photo;

        return $this;
    }

    /**
     * Get PhotoFile
     *
     * @return null|UploadedFile
     */
    public function getPhotoFile()
    {
        return $this->photoFile;
    }

    /**
     * Set PhotoFile
     *
     * @param null|UploadedFile $photoFile
     *
     * @return $this
     */
    public function setPhotoFile(UploadedFile $photoFile = null)
    {
        $this->photoFile = $photoFile;

        return $this;
    }
}
