<?php
/**
 * Created by PhpStorm.
 * User: Rabi
 * Date: 19/06/2017
 * Time: 15:33
 */

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * @ORM\Entity()
 * @UniqueEntity(fields={"code_aff_reseau"}, errorPath="code_aff_reseau")
 */
class Agence
{


    /**
     * @ORM\Id()
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;


    /**
     * @ORM\Column(type="string")
     * @Assert\Type("string")
     * @Assert\NotNull()
     * @Assert\Length(min=6, max=30)
     */
    private $code_aff_agence;


    /**
     * @ORM\ManyToOne(targetEntity="Gagence")
     */
    private $code_agence;

}