<?php

namespace AppBundle\Form;

use AppBundle\Entity\User;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\FileType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\RepeatedType;
use Symfony\Component\Form\Extension\Core\Type\TextType;


class UserType extends AbstractType
{


    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add('civility', ChoiceType::class, array(
            'choices' => array(
                'Monsieur' => 'M',
                'Madame'   => 'F'),
                'label'    => 'Civilité',
                'required' => false,
        ))
            ->add('first_name', TextType::class, [
                'label' => 'Nom*'
            ])
            ->add('last_name', TextType::class, [
                'label' => 'Prénom*'
            ])
            ->add('email', RepeatedType::class, [
                'type' => EmailType::class,
                'first_options' => ['label' => 'Email*'],
                'second_options' => ['label' => 'Répéter l email* '],

            ])

            ->add('job', TextType::class, [
                'label' => 'Poste'
            ])
            ->add('role', ChoiceType::class, array(
                'choices'   => array(
                    'Président du cda'             => 'ROLE_CDA',
                    'Responsable groupe d\'agence' => 'ROLE_GRP_AGENCE',
                    'Directeur d\'agence'          => 'ROLE_AGENCE',
                    'Négociateur'                  => 'ROLE_NEGOCIATEUR',
                    'Réseau'                       => 'ROLE_RESEAU',
                ),
                'label' => 'Vous êtes *',
            ))
            ->add('address_street', TextType::class, [
                'label' => 'Adresse*'
            ])
            ->add('address_street2', TextType::class, [
                'label' => 'Complément adresse'
            ])
            ->add('address_postal_code', TextType::class, [
                'label' => 'Code postal*'
            ])
            ->add('address_city', TextType::class, [
                'label' => 'Ville*'
            ])
            ->add('rawPassword', RepeatedType::class, [
                'type' => PasswordType::class,
                'first_options' => ['label' => 'Mot de passe'],
                'second_options' => ['label' => 'Mot de passe (bis)'],
            ])
            ->add('photoFile', FileType::class, [
                'label' => 'Photo de profil',
                'required' => false,
            ])
            ->addEventListener(FormEvents::SUBMIT, function (FormEvent $event) {
                $user = $event->getData();
                if ($user instanceof User) {
                    $user->setVersion(1 + $user->getVersion());
                    $event->setData($user);
                }
            })

            ->add('signature', CheckboxType::class, [
                'label' => 'J\'ai lu et j\'accepte les conditions générales et notre politique de confidentialité.'
            ]);

    }


    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => User::class,
        ]);
    }



}

