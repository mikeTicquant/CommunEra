<?php
/**
 * Created by PhpStorm.
 * User: Rabi
 * Date: 22/06/2017
 * Time: 11:03
 */

namespace AppBundle\Form;


use AppBundle\Entity\Business;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class BusinessType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {

        $builder
                ->add('name', TextType::class, [
                'label' => 'Raison sociale*'
                ])
                ->add('siren', TextType::class, [
                'label' => 'SIREN*'
                ])
                ->add('addressStreet', TextType::class, [
                'label' => 'Adresse'
                ])
                ->add('addressStreet2', TextType::class, [
                'label' => 'Complément d\'adresse'
                ])
                ->add('addressPostalCode', TextType::class, [
                'label' => 'Code postal'
                ])
                ->add('addressCity', TextType::class, [
                'label' => 'Ville'
                ]);

    }

    public function configureOptions(OptionsResolver $resolver)
    {
                $resolver->setDefaults([
                    'data_class' => Business::class,
                ]);
    }

}