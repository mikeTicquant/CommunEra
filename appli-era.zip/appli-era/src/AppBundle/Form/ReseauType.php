<?php
/**
 * Created by PhpStorm.
 * User: Rabi
 * Date: 20/06/2017
 * Time: 11:24
 */

namespace AppBundle\Form;


use AppBundle\Entity\Reseau;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class ReseauType extends AbstractType
{



    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add('codeAffReseau', TextType::class, [
                'label' => 'Code reseau',
            ]);

    }


    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Reseau::class,
        ]);
    }

}