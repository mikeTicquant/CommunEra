<?php
/**
 * Created by PhpStorm.
 * User: Rabi
 * Date: 20/06/2017
 * Time: 18:28
 */

namespace AppBundle\Form;


use AppBundle\Entity\Cda;
use AppBundle\Entity\Reseau;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class CdaType extends AbstractType
{


    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('codeAffCda', TextType::class, [
            'label' => 'Code d\'affiliation cda',
        ])
            ->add('codeReseau', EntityType::class, [
                'label' => 'Code d\'affiliation reseau',
                'class' => Reseau::class,
                'empty_data' => null,
                'placeholder' => 'Sélectionnez un reseau ...',
            ]);

    }


    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Cda::class,
        ]);
    }


}