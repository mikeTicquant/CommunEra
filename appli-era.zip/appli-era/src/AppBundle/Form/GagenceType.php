<?php
/**
 * Created by PhpStorm.
 * User: Rabi
 * Date: 21/06/2017
 * Time: 01:45
 */

namespace AppBundle\Form;


use AppBundle\Entity\Cda;
use AppBundle\Entity\Gagence;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class GagenceType extends AbstractType
{

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('codeAffGrp', TextType::class, [
                'label' => 'Code d\'affiliation groupe d\'agence',
            ])
            ->add('codeCda', EntityType::class, [
                'label' => 'Code d\'affiliation Cda',
                'class' => Cda::class,
                'empty_data' => null,
                'placeholder' => 'Sélectionnez un cda ...',
            ]);

    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Gagence::class,
        ]);
    }

}