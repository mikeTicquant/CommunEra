<?php

namespace AppBundle\EventListener;


use AppBundle\Entity\User;
use AppBundle\Upload\Uploader;
use Doctrine\ORM\Event\LifecycleEventArgs;

/**
 * Class DoctrineFileEventListener
 *
 * @author "Emmanuel BALLERY" <emmanuel.ballery@gmail.com>
 */
class DoctrineFileEventListener
{
    /**
     * @var string
     */
    private $userPhotoPath;



    /**
     * @var Uploader
     */
    private $userPhotoUploader;



    /**
     * @param string   $userPhotoPath
     * @param Uploader $userPhotoUploader
     */
    public function __construct(
        $userPhotoPath,
        Uploader $userPhotoUploader
    ) {
        $this->userPhotoPath = $userPhotoPath;
        $this->userPhotoUploader = $userPhotoUploader;
    }

    /**
     * @param LifecycleEventArgs $event
     */
    public function prePersist(LifecycleEventArgs $event)
    {
        $entity = $event->getEntity();

        if ($entity instanceof User) {
            $filename = $this->userPhotoUploader->upload($entity->getPhotoFile(), $entity->getPhoto());
            $entity->setPhoto($filename)->setPhotoFile(null);
        }

    }

    /**
     * @param LifecycleEventArgs $event
     */
    public function preUpdate(LifecycleEventArgs $event)
    {
        $entity = $event->getEntity();

        if ($entity instanceof User) {
            $filename = $this->userPhotoUploader->upload($entity->getPhotoFile(), $entity->getPhoto());
            $entity->setPhoto($filename)->setPhotoFile(null);
        }


    }

    /**
     * Post remove
     *
     * @param LifecycleEventArgs $event
     */
    public function postRemove(LifecycleEventArgs $event)
    {
        $entity = $event->getEntity();

        // Supprimer la photo de profil des utilisateurs
        if ($entity instanceof User) {
            $this->delete($this->userPhotoPath . '/' . $entity->getPhoto());
        }


    }

    /**
     * Delete
     *
     * @param null|string $path
     */
    private function delete($path = null)
    {
        if (null !== $path) {
            if (file_exists($path)) {
                unlink($path);
            }
        }
    }
}
