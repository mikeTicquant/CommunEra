<?php

namespace AppBundle\EventListener;

use AppBundle\Entity\User;
use Doctrine\ORM\Event\LifecycleEventArgs;
use Symfony\Component\Security\Core\Encoder\UserPasswordEncoder;


class DoctrineUserPasswordEventListener
{
    /**
     * @var UserPasswordEncoder
     */
    private $encoder;

    /**
     * @param UserPasswordEncoder $encoder
     */
    public function __construct(UserPasswordEncoder $encoder)
    {
        $this->encoder = $encoder;
    }

    /**
     * @param LifecycleEventArgs $event
     */
    public function prePersist(LifecycleEventArgs $event)
    {
        $entity = $event->getEntity();

        if ($entity instanceof User) {
            $this->encode($entity);
        }
    }

    /**
     * @param LifecycleEventArgs $event
     */
    public function preUpdate(LifecycleEventArgs $event)
    {
        $entity = $event->getEntity();

        if ($entity instanceof User) {
            $this->encode($entity);
        }
    }

    /**
     * @param User $user
     */
    private function encode(User $user)
    {
        if (null !== $raw = $user->getRawPassword()) {
            $encoded = $this->encoder->encodePassword($user, $raw);

            $user
                ->setPassword($encoded);

        }
    }
}
