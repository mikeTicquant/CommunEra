<?php

namespace AppBundle\Upload;

use Symfony\Component\HttpFoundation\File\UploadedFile;

/**
 * Class Uploader
 *
 * @author "Emmanuel BALLERY" <emmanuel.ballery@gmail.com>
 */
class Uploader
{
    /**
     * @var string
     */
    private $dir;

    /**
     * @param string $dir
     */
    public function __construct($dir)
    {
        $this->dir = $dir;
    }

    /**
     * Upload
     *
     * @param UploadedFile|null $file            File
     * @param null              $currentFilename Current filename
     *
     * @return null|string
     */
    public function upload(UploadedFile $file = null, $currentFilename = null)
    {
        if (null !== $file) {
            if (null !== $currentFilename) {
                // Remove old file to prevent cache
                $path = $this->dir . '/' . $currentFilename;
                if (file_exists($path)) {
                    unlink($path);
                }
            }

            $filename = md5(uniqid()) . '.' . $file->guessExtension();

            $file->move($this->dir, $filename);

            if (false !== $realpath = realpath($this->dir . '/' . $filename)) {
                return basename($realpath);
            }

            return null;
        }

        return $currentFilename;
    }
}
