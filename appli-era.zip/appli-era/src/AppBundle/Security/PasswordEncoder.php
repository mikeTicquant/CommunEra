<?php

namespace AppBundle\Security;

use AppBundle\Entity\User;
use Symfony\Component\Security\Core\Encoder\UserPasswordEncoderInterface;


class PasswordEncoder
{
    /**
     * @var UserPasswordEncoderInterface
     */
    private $passwordEncoder;

    /**
     * @param UserPasswordEncoderInterface $passwordEncoder
     */
    public function __construct(UserPasswordEncoderInterface $passwordEncoder)
    {
        $this->passwordEncoder = $passwordEncoder;
    }

    /**
     * @param User $user
     */
    public function encodePassword(User $user)
    {
        if (null !== $rawPassword = $user->getRawPassword()) {
            $encodedPassword = $this->passwordEncoder->encodePassword($user, $rawPassword);

            $user
                ->setPassword($encodedPassword)
                ->setRawPassword(null);
        }
    }
}
