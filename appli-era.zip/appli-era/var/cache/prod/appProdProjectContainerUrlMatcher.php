<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appProdProjectContainerUrlMatcher.
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appProdProjectContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $context = $this->context;
        $request = $this->request;

        // app_agence_agence_index
        if ($pathinfo === '/agence') {
            return array (  '_controller' => 'AppBundle\\Controller\\Agence\\AgenceController::indexAction',  '_route' => 'app_agence_agence_index',);
        }

        // app_cda_cda_index
        if ($pathinfo === '/cda') {
            return array (  '_controller' => 'AppBundle\\Controller\\Cda\\CdaController::indexAction',  '_route' => 'app_cda_cda_index',);
        }

        // homepage
        if (rtrim($pathinfo, '/') === '') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'homepage');
            }

            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::indexAction',  '_route' => 'homepage',);
        }

        // app_grpagence_grpagence_index
        if ($pathinfo === '/groupe') {
            return array (  '_controller' => 'AppBundle\\Controller\\Grpagence\\GrpagenceController::indexAction',  '_route' => 'app_grpagence_grpagence_index',);
        }

        // app_nego_nego_index
        if ($pathinfo === '/nego') {
            return array (  '_controller' => 'AppBundle\\Controller\\Nego\\NegoController::indexAction',  '_route' => 'app_nego_nego_index',);
        }

        // app_reseau_reseau_index
        if ($pathinfo === '/reseau') {
            return array (  '_controller' => 'AppBundle\\Controller\\Reseau\\ReseauController::indexAction',  '_route' => 'app_reseau_reseau_index',);
        }

        // login
        if ($pathinfo === '/login') {
            return array (  '_controller' => 'AppBundle\\Controller\\SecurityController::loginAction',  '_route' => 'login',);
        }

        // app_security_afterlogin
        if ($pathinfo === '/connexion/redirection') {
            return array (  '_controller' => 'AppBundle\\Controller\\SecurityController::afterLoginAction',  '_route' => 'app_security_afterlogin',);
        }

        if (0 === strpos($pathinfo, '/user')) {
            // app_user_user_index
            if ($pathinfo === '/user') {
                return array (  '_controller' => 'AppBundle\\Controller\\User\\UserController::indexAction',  '_route' => 'app_user_user_index',);
            }

            // app_user_user_signup
            if ($pathinfo === '/user/add') {
                return array (  '_controller' => 'AppBundle\\Controller\\User\\UserController::signupAction',  '_route' => 'app_user_user_signup',);
            }

            // app_user_user_profil
            if ($pathinfo === '/user/profil') {
                return array (  '_controller' => 'AppBundle\\Controller\\User\\UserController::profilAction',  '_route' => 'app_user_user_profil',);
            }

            // app_user_user_update
            if (preg_match('#^/user/(?P<id>\\d+)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'app_user_user_update')), array (  '_controller' => 'AppBundle\\Controller\\User\\UserController::updateAction',));
            }

            // app_user_user_delete
            if (preg_match('#^/user/(?P<id>\\d+)/supprimer$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'app_user_user_delete')), array (  '_controller' => 'AppBundle\\Controller\\User\\UserController::deleteAction',));
            }

            // app_user_user_agence
            if ($pathinfo === '/user/agence') {
                return array (  '_controller' => 'AppBundle\\Controller\\User\\UserController::agenceAction',  '_route' => 'app_user_user_agence',);
            }

        }

        // logout
        if ($pathinfo === '/deconnexion') {
            return array('_route' => 'logout');
        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
