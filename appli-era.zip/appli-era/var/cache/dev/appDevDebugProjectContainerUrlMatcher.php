<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appDevDebugProjectContainerUrlMatcher.
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appDevDebugProjectContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $context = $this->context;
        $request = $this->request;

        if (0 === strpos($pathinfo, '/_')) {
            // _wdt
            if (0 === strpos($pathinfo, '/_wdt') && preg_match('#^/_wdt/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_wdt')), array (  '_controller' => 'web_profiler.controller.profiler:toolbarAction',));
            }

            if (0 === strpos($pathinfo, '/_profiler')) {
                // _profiler_home
                if (rtrim($pathinfo, '/') === '/_profiler') {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', '_profiler_home');
                    }

                    return array (  '_controller' => 'web_profiler.controller.profiler:homeAction',  '_route' => '_profiler_home',);
                }

                if (0 === strpos($pathinfo, '/_profiler/search')) {
                    // _profiler_search
                    if ($pathinfo === '/_profiler/search') {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchAction',  '_route' => '_profiler_search',);
                    }

                    // _profiler_search_bar
                    if ($pathinfo === '/_profiler/search_bar') {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchBarAction',  '_route' => '_profiler_search_bar',);
                    }

                }

                // _profiler_info
                if (0 === strpos($pathinfo, '/_profiler/info') && preg_match('#^/_profiler/info/(?P<about>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_info')), array (  '_controller' => 'web_profiler.controller.profiler:infoAction',));
                }

                // _profiler_phpinfo
                if ($pathinfo === '/_profiler/phpinfo') {
                    return array (  '_controller' => 'web_profiler.controller.profiler:phpinfoAction',  '_route' => '_profiler_phpinfo',);
                }

                // _profiler_search_results
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/search/results$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_search_results')), array (  '_controller' => 'web_profiler.controller.profiler:searchResultsAction',));
                }

                // _profiler_open_file
                if ($pathinfo === '/_profiler/open') {
                    return array (  '_controller' => 'web_profiler.controller.profiler:openAction',  '_route' => '_profiler_open_file',);
                }

                // _profiler
                if (preg_match('#^/_profiler/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler')), array (  '_controller' => 'web_profiler.controller.profiler:panelAction',));
                }

                // _profiler_router
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/router$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_router')), array (  '_controller' => 'web_profiler.controller.router:panelAction',));
                }

                // _profiler_exception
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception')), array (  '_controller' => 'web_profiler.controller.exception:showAction',));
                }

                // _profiler_exception_css
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception\\.css$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception_css')), array (  '_controller' => 'web_profiler.controller.exception:cssAction',));
                }

            }

            // _twig_error_test
            if (0 === strpos($pathinfo, '/_error') && preg_match('#^/_error/(?P<code>\\d+)(?:\\.(?P<_format>[^/]++))?$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_twig_error_test')), array (  '_controller' => 'twig.controller.preview_error:previewErrorPageAction',  '_format' => 'html',));
            }

        }

        if (0 === strpos($pathinfo, '/a')) {
            if (0 === strpos($pathinfo, '/admin')) {
                // app_admin_default_index
                if ($pathinfo === '/admin') {
                    return array (  '_controller' => 'AppBundle\\Controller\\Admin\\DefaultController::indexAction',  '_route' => 'app_admin_default_index',);
                }

                if (0 === strpos($pathinfo, '/administration/user')) {
                    // app_admin_user_index
                    if ($pathinfo === '/administration/user') {
                        return array (  '_controller' => 'AppBundle\\Controller\\Admin\\UserController::indexAction',  '_route' => 'app_admin_user_index',);
                    }

                    // app_admin_user_create
                    if ($pathinfo === '/administration/user/creer') {
                        return array (  '_controller' => 'AppBundle\\Controller\\Admin\\UserController::createAction',  '_route' => 'app_admin_user_create',);
                    }

                    // app_admin_user_update
                    if (preg_match('#^/administration/user/(?P<id>\\d+)$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'app_admin_user_update')), array (  '_controller' => 'AppBundle\\Controller\\Admin\\UserController::updateAction',));
                    }

                    // app_admin_user_delete
                    if (preg_match('#^/administration/user/(?P<id>\\d+)/supprimer$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'app_admin_user_delete')), array (  '_controller' => 'AppBundle\\Controller\\Admin\\UserController::deleteAction',));
                    }

                }

            }

            // app_agence_agence_index
            if ($pathinfo === '/agence') {
                return array (  '_controller' => 'AppBundle\\Controller\\Agence\\AgenceController::indexAction',  '_route' => 'app_agence_agence_index',);
            }

        }

        // app_business_business_add
        if ($pathinfo === '/entreprise') {
            return array (  '_controller' => 'AppBundle\\Controller\\Business\\BusinessController::addAction',  '_route' => 'app_business_business_add',);
        }

        // app_cda_cda_index
        if ($pathinfo === '/cda') {
            return array (  '_controller' => 'AppBundle\\Controller\\Cda\\CdaController::indexAction',  '_route' => 'app_cda_cda_index',);
        }

        // homepage
        if (rtrim($pathinfo, '/') === '') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'homepage');
            }

            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::indexAction',  '_route' => 'homepage',);
        }

        // app_grpagence_grpagence_index
        if ($pathinfo === '/groupe') {
            return array (  '_controller' => 'AppBundle\\Controller\\Grpagence\\GrpagenceController::indexAction',  '_route' => 'app_grpagence_grpagence_index',);
        }

        if (0 === strpos($pathinfo, '/n')) {
            // app_nego_nego_index
            if ($pathinfo === '/nego') {
                return array (  '_controller' => 'AppBundle\\Controller\\Nego\\NegoController::indexAction',  '_route' => 'app_nego_nego_index',);
            }

            // app_notification_notification_index
            if ($pathinfo === '/notification') {
                return array (  '_controller' => 'AppBundle\\Controller\\Notification\\NotificationController::indexAction',  '_route' => 'app_notification_notification_index',);
            }

        }

        // app_reseau_reseau_index
        if ($pathinfo === '/reseau') {
            return array (  '_controller' => 'AppBundle\\Controller\\Reseau\\ReseauController::indexAction',  '_route' => 'app_reseau_reseau_index',);
        }

        // login
        if ($pathinfo === '/login') {
            return array (  '_controller' => 'AppBundle\\Controller\\SecurityController::loginAction',  '_route' => 'login',);
        }

        // app_security_afterlogin
        if ($pathinfo === '/connexion/redirection') {
            return array (  '_controller' => 'AppBundle\\Controller\\SecurityController::afterLoginAction',  '_route' => 'app_security_afterlogin',);
        }

        if (0 === strpos($pathinfo, '/user')) {
            // app_user_user_index
            if ($pathinfo === '/user') {
                return array (  '_controller' => 'AppBundle\\Controller\\User\\UserController::indexAction',  '_route' => 'app_user_user_index',);
            }

            // app_user_user_signup
            if ($pathinfo === '/user/add') {
                return array (  '_controller' => 'AppBundle\\Controller\\User\\UserController::signupAction',  '_route' => 'app_user_user_signup',);
            }

            // app_user_user_profil
            if ($pathinfo === '/user/profil') {
                return array (  '_controller' => 'AppBundle\\Controller\\User\\UserController::profilAction',  '_route' => 'app_user_user_profil',);
            }

            // app_user_user_update
            if (preg_match('#^/user/(?P<id>\\d+)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'app_user_user_update')), array (  '_controller' => 'AppBundle\\Controller\\User\\UserController::updateAction',));
            }

            // app_user_user_delete
            if (preg_match('#^/user/(?P<id>\\d+)/supprimer$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'app_user_user_delete')), array (  '_controller' => 'AppBundle\\Controller\\User\\UserController::deleteAction',));
            }

            // app_user_user_agence
            if ($pathinfo === '/user/agence') {
                return array (  '_controller' => 'AppBundle\\Controller\\User\\UserController::agenceAction',  '_route' => 'app_user_user_agence',);
            }

            if (0 === strpos($pathinfo, '/user/code')) {
                // app_user_user_addreseau
                if ($pathinfo === '/user/code/reseau') {
                    return array (  '_controller' => 'AppBundle\\Controller\\User\\UserController::addreseauAction',  '_route' => 'app_user_user_addreseau',);
                }

                // app_user_user_addcda
                if ($pathinfo === '/user/code/cda') {
                    return array (  '_controller' => 'AppBundle\\Controller\\User\\UserController::addcdaAction',  '_route' => 'app_user_user_addcda',);
                }

                // app_user_user_addgagence
                if ($pathinfo === '/user/code/gagence') {
                    return array (  '_controller' => 'AppBundle\\Controller\\User\\UserController::addgagenceAction',  '_route' => 'app_user_user_addgagence',);
                }

            }

            // app_user_user_affiliate
            if ($pathinfo === '/user/affiliation') {
                return array (  '_controller' => 'AppBundle\\Controller\\User\\UserController::affiliateAction',  '_route' => 'app_user_user_affiliate',);
            }

        }

        // logout
        if ($pathinfo === '/deconnexion') {
            return array('_route' => 'logout');
        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
