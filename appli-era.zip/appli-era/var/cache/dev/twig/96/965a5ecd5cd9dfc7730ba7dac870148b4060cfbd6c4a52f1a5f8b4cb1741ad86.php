<?php

/* agence/index.html.twig */
class __TwigTemplate_ad2bfe3546abd8b1c88bb520baf5412f0172183202aadb4301924e66c9f5da65 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "agence/index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b43fea4cc3d0ebd7a3d3316fa938384b4b307b67bcc27c641725c4c1505e6864 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b43fea4cc3d0ebd7a3d3316fa938384b4b307b67bcc27c641725c4c1505e6864->enter($__internal_b43fea4cc3d0ebd7a3d3316fa938384b4b307b67bcc27c641725c4c1505e6864_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "agence/index.html.twig"));

        $__internal_bd51a82c2287c20d547fb50272ec29b145dbace7e757c2bde4659a70a4a7747c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bd51a82c2287c20d547fb50272ec29b145dbace7e757c2bde4659a70a4a7747c->enter($__internal_bd51a82c2287c20d547fb50272ec29b145dbace7e757c2bde4659a70a4a7747c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "agence/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b43fea4cc3d0ebd7a3d3316fa938384b4b307b67bcc27c641725c4c1505e6864->leave($__internal_b43fea4cc3d0ebd7a3d3316fa938384b4b307b67bcc27c641725c4c1505e6864_prof);

        
        $__internal_bd51a82c2287c20d547fb50272ec29b145dbace7e757c2bde4659a70a4a7747c->leave($__internal_bd51a82c2287c20d547fb50272ec29b145dbace7e757c2bde4659a70a4a7747c_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_44824149ac9ed9754018e5917c3fd8987571869b14af0d6e6cf59b12454f9f82 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_44824149ac9ed9754018e5917c3fd8987571869b14af0d6e6cf59b12454f9f82->enter($__internal_44824149ac9ed9754018e5917c3fd8987571869b14af0d6e6cf59b12454f9f82_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_7f10f93aca1cab123c1ac21d00a7aad7b8a0a6bd0ebdb16745760cf12398567f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7f10f93aca1cab123c1ac21d00a7aad7b8a0a6bd0ebdb16745760cf12398567f->enter($__internal_7f10f93aca1cab123c1ac21d00a7aad7b8a0a6bd0ebdb16745760cf12398567f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    <h1>Espace Agence</h1>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
";
        
        $__internal_7f10f93aca1cab123c1ac21d00a7aad7b8a0a6bd0ebdb16745760cf12398567f->leave($__internal_7f10f93aca1cab123c1ac21d00a7aad7b8a0a6bd0ebdb16745760cf12398567f_prof);

        
        $__internal_44824149ac9ed9754018e5917c3fd8987571869b14af0d6e6cf59b12454f9f82->leave($__internal_44824149ac9ed9754018e5917c3fd8987571869b14af0d6e6cf59b12454f9f82_prof);

    }

    public function getTemplateName()
    {
        return "agence/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 3,  40 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block body %}
    <h1>Espace Agence</h1>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
{% endblock %}", "agence/index.html.twig", "C:\\wamp64\\www\\appli-era\\app\\Resources\\views\\agence\\index.html.twig");
    }
}
