<?php

/* cda/index.html.twig */
class __TwigTemplate_718fbc0a9b9eb553df112cc91dba2815f3d4a2be0b7e143054975061f1a74093 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "cda/index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_134e994ae829a1b3a80b27465b1b49ba024af2b745ffdbcfd3afcfc2c645b3aa = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_134e994ae829a1b3a80b27465b1b49ba024af2b745ffdbcfd3afcfc2c645b3aa->enter($__internal_134e994ae829a1b3a80b27465b1b49ba024af2b745ffdbcfd3afcfc2c645b3aa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "cda/index.html.twig"));

        $__internal_2736d31947ac581fb9d91164c29dbcf90061e87b9f1004f7a0a536122c201134 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2736d31947ac581fb9d91164c29dbcf90061e87b9f1004f7a0a536122c201134->enter($__internal_2736d31947ac581fb9d91164c29dbcf90061e87b9f1004f7a0a536122c201134_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "cda/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_134e994ae829a1b3a80b27465b1b49ba024af2b745ffdbcfd3afcfc2c645b3aa->leave($__internal_134e994ae829a1b3a80b27465b1b49ba024af2b745ffdbcfd3afcfc2c645b3aa_prof);

        
        $__internal_2736d31947ac581fb9d91164c29dbcf90061e87b9f1004f7a0a536122c201134->leave($__internal_2736d31947ac581fb9d91164c29dbcf90061e87b9f1004f7a0a536122c201134_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_a698a9319a8133cdff961421a0e00e556823385e1482708e2cb6138526544084 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a698a9319a8133cdff961421a0e00e556823385e1482708e2cb6138526544084->enter($__internal_a698a9319a8133cdff961421a0e00e556823385e1482708e2cb6138526544084_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_6f0a5661c92efd9c3b33d1108d92820d1b908398451575ad9199482bdaf4a37d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6f0a5661c92efd9c3b33d1108d92820d1b908398451575ad9199482bdaf4a37d->enter($__internal_6f0a5661c92efd9c3b33d1108d92820d1b908398451575ad9199482bdaf4a37d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    <h1>Espace Cda</h1>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
";
        
        $__internal_6f0a5661c92efd9c3b33d1108d92820d1b908398451575ad9199482bdaf4a37d->leave($__internal_6f0a5661c92efd9c3b33d1108d92820d1b908398451575ad9199482bdaf4a37d_prof);

        
        $__internal_a698a9319a8133cdff961421a0e00e556823385e1482708e2cb6138526544084->leave($__internal_a698a9319a8133cdff961421a0e00e556823385e1482708e2cb6138526544084_prof);

    }

    public function getTemplateName()
    {
        return "cda/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 3,  40 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block body %}
    <h1>Espace Cda</h1>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
{% endblock %}", "cda/index.html.twig", "C:\\wamp64\\www\\appli-era\\app\\Resources\\views\\cda\\index.html.twig");
    }
}
