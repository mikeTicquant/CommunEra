<?php

/* admin/_footer_admin.html.twig */
class __TwigTemplate_d49fe5879ab687e3248de2728edda1981fbcddf0c4586ca71678f65e60e51f45 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2c5f64f02e48620fa66f9359dcade759efde3c191da7bc90fa6410f8ed18d4f7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2c5f64f02e48620fa66f9359dcade759efde3c191da7bc90fa6410f8ed18d4f7->enter($__internal_2c5f64f02e48620fa66f9359dcade759efde3c191da7bc90fa6410f8ed18d4f7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/_footer_admin.html.twig"));

        $__internal_517c0664f19cc46679a1b0e497263f99a91a6fa96f09f14cdf9f69882ff6368c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_517c0664f19cc46679a1b0e497263f99a91a6fa96f09f14cdf9f69882ff6368c->enter($__internal_517c0664f19cc46679a1b0e497263f99a91a6fa96f09f14cdf9f69882ff6368c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/_footer_admin.html.twig"));

        // line 1
        echo "<!--=== Footer Version 1 ===-->
<div class=\"footer-v1\">
    <div class=\"footer\">
        <div class=\"container\">
            <div class=\"row\">
                <!-- About -->
                <div class=\"col-md-3 md-margin-bottom-40\">
                    <div class=\"headline\"><h2>A PROPOS</h2></div>
                    <p></p>
                </div><!--/col-md-3-->
                <!-- End About -->

                <!-- Latest -->
                <div class=\"col-md-3 md-margin-bottom-40\">
                    <div class=\"posts\">
                        <div class=\"headline\"><h2>Derniers Posts</h2></div>
                        <ul class=\"list-unstyled latest-list\">
                            <li>
                                <a href=\"#\">Incredible content</a>
                                <small>May 8, 2014</small>
                            </li>
                            <li>
                                <a href=\"#\">Best shoots</a>
                                <small>June 23, 2014</small>
                            </li>
                            <li>
                                <a href=\"#\">New Terms and Conditions</a>
                                <small>September 15, 2014</small>
                            </li>
                        </ul>
                    </div>
                </div><!--/col-md-3-->
                <!-- End Latest -->

                <!-- Link List -->
                <div class=\"col-md-3 md-margin-bottom-40\">
                    <div class=\"headline\"><h2>LIENS UTILES</h2></div>
                    <ul class=\"list-unstyled link-list\">
                        <li><a href=\"#\">Mentions légales</a><i class=\"fa fa-angle-right\"></i></li>
                        <li><a href=\"#\">Politique de confidentialité</a><i class=\"fa fa-angle-right\"></i></li>
                        <li><a href=\"#\">Conditions Générales</a><i class=\"fa fa-angle-right\"></i></li>
                        <li><a href=\"#\">Nous contacter</a><i class=\"fa fa-angle-right\"></i></li>
                    </ul>
                </div><!--/col-md-3-->
                <!-- End Link List -->

                <!-- Address -->
                <div class=\"col-md-3 map-img md-margin-bottom-40\">
                    <div class=\"headline\"><h2>CONTACTS</h2></div>
                    <address class=\"md-margin-bottom-40\">
                        295 rue Saint-Jacques <br />
                        75005 PARIS <br />
                        Phone: 800 123 3456 <br />
                        Fax: 800 123 3456 <br />
                        Email: <a href=\"mailto:info@prospec.fr\" class=\"\">info@prospec.fr</a>
                    </address>
                </div><!--/col-md-3-->
                <!-- End Address -->
            </div>
        </div>
    </div><!--/footer-->

    <div class=\"copyright\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-md-6\">
                    <p>
                        2017 &copy; All Rights Reserved.
                        <a href=\"#\">Privacy Policy</a> | <a href=\"#\">Terms of Service</a>
                    </p>
                </div>

                <!-- Social Links -->
                <div class=\"col-md-6\">
                    <ul class=\"footer-socials list-inline\">
                        <li>
                            <a href=\"#\" class=\"tooltips\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"\" data-original-title=\"Facebook\">
                                <i class=\"fa fa-facebook\"></i>
                            </a>
                        </li>
                        <li>
                            <a href=\"#\" class=\"tooltips\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"\" data-original-title=\"Skype\">
                                <i class=\"fa fa-skype\"></i>
                            </a>
                        </li>
                        <li>
                            <a href=\"#\" class=\"tooltips\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"\" data-original-title=\"Google Plus\">
                                <i class=\"fa fa-google-plus\"></i>
                            </a>
                        </li>
                        <li>
                            <a href=\"#\" class=\"tooltips\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"\" data-original-title=\"Linkedin\">
                                <i class=\"fa fa-linkedin\"></i>
                            </a>
                        </li>
                        <li>
                            <a href=\"#\" class=\"tooltips\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"\" data-original-title=\"Pinterest\">
                                <i class=\"fa fa-pinterest\"></i>
                            </a>
                        </li>
                        <li>
                            <a href=\"#\" class=\"tooltips\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"\" data-original-title=\"Twitter\">
                                <i class=\"fa fa-twitter\"></i>
                            </a>
                        </li>
                        <li>
                            <a href=\"#\" class=\"tooltips\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"\" data-original-title=\"Dribbble\">
                                <i class=\"fa fa-dribbble\"></i>
                            </a>
                        </li>
                    </ul>
                </div>
                <!-- End Social Links -->
            </div>
        </div>
    </div><!--/copyright-->
</div>
<!--=== End Footer Version 1 ===-->";
        
        $__internal_2c5f64f02e48620fa66f9359dcade759efde3c191da7bc90fa6410f8ed18d4f7->leave($__internal_2c5f64f02e48620fa66f9359dcade759efde3c191da7bc90fa6410f8ed18d4f7_prof);

        
        $__internal_517c0664f19cc46679a1b0e497263f99a91a6fa96f09f14cdf9f69882ff6368c->leave($__internal_517c0664f19cc46679a1b0e497263f99a91a6fa96f09f14cdf9f69882ff6368c_prof);

    }

    public function getTemplateName()
    {
        return "admin/_footer_admin.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!--=== Footer Version 1 ===-->
<div class=\"footer-v1\">
    <div class=\"footer\">
        <div class=\"container\">
            <div class=\"row\">
                <!-- About -->
                <div class=\"col-md-3 md-margin-bottom-40\">
                    <div class=\"headline\"><h2>A PROPOS</h2></div>
                    <p></p>
                </div><!--/col-md-3-->
                <!-- End About -->

                <!-- Latest -->
                <div class=\"col-md-3 md-margin-bottom-40\">
                    <div class=\"posts\">
                        <div class=\"headline\"><h2>Derniers Posts</h2></div>
                        <ul class=\"list-unstyled latest-list\">
                            <li>
                                <a href=\"#\">Incredible content</a>
                                <small>May 8, 2014</small>
                            </li>
                            <li>
                                <a href=\"#\">Best shoots</a>
                                <small>June 23, 2014</small>
                            </li>
                            <li>
                                <a href=\"#\">New Terms and Conditions</a>
                                <small>September 15, 2014</small>
                            </li>
                        </ul>
                    </div>
                </div><!--/col-md-3-->
                <!-- End Latest -->

                <!-- Link List -->
                <div class=\"col-md-3 md-margin-bottom-40\">
                    <div class=\"headline\"><h2>LIENS UTILES</h2></div>
                    <ul class=\"list-unstyled link-list\">
                        <li><a href=\"#\">Mentions légales</a><i class=\"fa fa-angle-right\"></i></li>
                        <li><a href=\"#\">Politique de confidentialité</a><i class=\"fa fa-angle-right\"></i></li>
                        <li><a href=\"#\">Conditions Générales</a><i class=\"fa fa-angle-right\"></i></li>
                        <li><a href=\"#\">Nous contacter</a><i class=\"fa fa-angle-right\"></i></li>
                    </ul>
                </div><!--/col-md-3-->
                <!-- End Link List -->

                <!-- Address -->
                <div class=\"col-md-3 map-img md-margin-bottom-40\">
                    <div class=\"headline\"><h2>CONTACTS</h2></div>
                    <address class=\"md-margin-bottom-40\">
                        295 rue Saint-Jacques <br />
                        75005 PARIS <br />
                        Phone: 800 123 3456 <br />
                        Fax: 800 123 3456 <br />
                        Email: <a href=\"mailto:info@prospec.fr\" class=\"\">info@prospec.fr</a>
                    </address>
                </div><!--/col-md-3-->
                <!-- End Address -->
            </div>
        </div>
    </div><!--/footer-->

    <div class=\"copyright\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-md-6\">
                    <p>
                        2017 &copy; All Rights Reserved.
                        <a href=\"#\">Privacy Policy</a> | <a href=\"#\">Terms of Service</a>
                    </p>
                </div>

                <!-- Social Links -->
                <div class=\"col-md-6\">
                    <ul class=\"footer-socials list-inline\">
                        <li>
                            <a href=\"#\" class=\"tooltips\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"\" data-original-title=\"Facebook\">
                                <i class=\"fa fa-facebook\"></i>
                            </a>
                        </li>
                        <li>
                            <a href=\"#\" class=\"tooltips\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"\" data-original-title=\"Skype\">
                                <i class=\"fa fa-skype\"></i>
                            </a>
                        </li>
                        <li>
                            <a href=\"#\" class=\"tooltips\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"\" data-original-title=\"Google Plus\">
                                <i class=\"fa fa-google-plus\"></i>
                            </a>
                        </li>
                        <li>
                            <a href=\"#\" class=\"tooltips\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"\" data-original-title=\"Linkedin\">
                                <i class=\"fa fa-linkedin\"></i>
                            </a>
                        </li>
                        <li>
                            <a href=\"#\" class=\"tooltips\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"\" data-original-title=\"Pinterest\">
                                <i class=\"fa fa-pinterest\"></i>
                            </a>
                        </li>
                        <li>
                            <a href=\"#\" class=\"tooltips\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"\" data-original-title=\"Twitter\">
                                <i class=\"fa fa-twitter\"></i>
                            </a>
                        </li>
                        <li>
                            <a href=\"#\" class=\"tooltips\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"\" data-original-title=\"Dribbble\">
                                <i class=\"fa fa-dribbble\"></i>
                            </a>
                        </li>
                    </ul>
                </div>
                <!-- End Social Links -->
            </div>
        </div>
    </div><!--/copyright-->
</div>
<!--=== End Footer Version 1 ===-->", "admin/_footer_admin.html.twig", "C:\\wamp64\\www\\appli-era\\app\\Resources\\views\\admin\\_footer_admin.html.twig");
    }
}
