<?php

/* @Twig/Exception/exception.css.twig */
class __TwigTemplate_8bd0d709545c2e0eff3699e9dee149826229f8811ac78dddb18b7dfce31ebdb2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f5069f7488fd4dfb581d286ff3af887c5fb098a9ec8d8d364cf21d96fb824ad4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f5069f7488fd4dfb581d286ff3af887c5fb098a9ec8d8d364cf21d96fb824ad4->enter($__internal_f5069f7488fd4dfb581d286ff3af887c5fb098a9ec8d8d364cf21d96fb824ad4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.css.twig"));

        $__internal_3bf4a2dc07f56523b90cace828cf4113c3c9d2dfe195409f9d3e59e2b87e82b3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3bf4a2dc07f56523b90cace828cf4113c3c9d2dfe195409f9d3e59e2b87e82b3->enter($__internal_3bf4a2dc07f56523b90cace828cf4113c3c9d2dfe195409f9d3e59e2b87e82b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        $this->loadTemplate("@Twig/Exception/exception.txt.twig", "@Twig/Exception/exception.css.twig", 2)->display(array_merge($context, array("exception" => ($context["exception"] ?? $this->getContext($context, "exception")))));
        // line 3
        echo "*/
";
        
        $__internal_f5069f7488fd4dfb581d286ff3af887c5fb098a9ec8d8d364cf21d96fb824ad4->leave($__internal_f5069f7488fd4dfb581d286ff3af887c5fb098a9ec8d8d364cf21d96fb824ad4_prof);

        
        $__internal_3bf4a2dc07f56523b90cace828cf4113c3c9d2dfe195409f9d3e59e2b87e82b3->leave($__internal_3bf4a2dc07f56523b90cace828cf4113c3c9d2dfe195409f9d3e59e2b87e82b3_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  30 => 3,  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{% include '@Twig/Exception/exception.txt.twig' with { 'exception': exception } %}
*/
", "@Twig/Exception/exception.css.twig", "C:\\wamp64\\www\\appli-era\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception.css.twig");
    }
}
