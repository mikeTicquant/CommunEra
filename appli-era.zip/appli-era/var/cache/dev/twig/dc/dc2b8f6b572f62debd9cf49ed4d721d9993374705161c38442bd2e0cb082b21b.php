<?php

/* @Framework/FormTable/button_row.html.php */
class __TwigTemplate_7705f5f16ae20cf321cf838896f6a640eec275c13d7f0c049caaef631ce3e3a7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5f9e6dad17a429b68293cce6177503500e85bdf3fb9251f9120a1631096833b7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5f9e6dad17a429b68293cce6177503500e85bdf3fb9251f9120a1631096833b7->enter($__internal_5f9e6dad17a429b68293cce6177503500e85bdf3fb9251f9120a1631096833b7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        $__internal_900fc45d1485545702d16815c50ba13bb68156a114492997ad82cc06be0666ad = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_900fc45d1485545702d16815c50ba13bb68156a114492997ad82cc06be0666ad->enter($__internal_900fc45d1485545702d16815c50ba13bb68156a114492997ad82cc06be0666ad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        // line 1
        echo "<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_5f9e6dad17a429b68293cce6177503500e85bdf3fb9251f9120a1631096833b7->leave($__internal_5f9e6dad17a429b68293cce6177503500e85bdf3fb9251f9120a1631096833b7_prof);

        
        $__internal_900fc45d1485545702d16815c50ba13bb68156a114492997ad82cc06be0666ad->leave($__internal_900fc45d1485545702d16815c50ba13bb68156a114492997ad82cc06be0666ad_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
", "@Framework/FormTable/button_row.html.php", "C:\\wamp64\\www\\appli-era\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\FormTable\\button_row.html.php");
    }
}
