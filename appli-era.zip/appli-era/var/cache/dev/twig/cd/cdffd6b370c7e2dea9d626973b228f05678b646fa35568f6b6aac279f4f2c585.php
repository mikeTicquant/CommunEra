<?php

/* :reseau:index.html.twig */
class __TwigTemplate_6d650bd83f61a48edb74330408808d7cff28a377775d82c314f757d357481017 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":reseau:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_86bbcdcc666ddccf2786d524c45f9ea5b45d0709f64c23e8f4b32319a38ce752 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_86bbcdcc666ddccf2786d524c45f9ea5b45d0709f64c23e8f4b32319a38ce752->enter($__internal_86bbcdcc666ddccf2786d524c45f9ea5b45d0709f64c23e8f4b32319a38ce752_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":reseau:index.html.twig"));

        $__internal_c49c1717eaec8b6a8ad77c1ccff8edcc136e798f35f9b160106a33bde938b44d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c49c1717eaec8b6a8ad77c1ccff8edcc136e798f35f9b160106a33bde938b44d->enter($__internal_c49c1717eaec8b6a8ad77c1ccff8edcc136e798f35f9b160106a33bde938b44d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":reseau:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_86bbcdcc666ddccf2786d524c45f9ea5b45d0709f64c23e8f4b32319a38ce752->leave($__internal_86bbcdcc666ddccf2786d524c45f9ea5b45d0709f64c23e8f4b32319a38ce752_prof);

        
        $__internal_c49c1717eaec8b6a8ad77c1ccff8edcc136e798f35f9b160106a33bde938b44d->leave($__internal_c49c1717eaec8b6a8ad77c1ccff8edcc136e798f35f9b160106a33bde938b44d_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_0bd5e5c7bf2df19e38c0019303d1504622ba196607c62d373c2b375abee1439a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0bd5e5c7bf2df19e38c0019303d1504622ba196607c62d373c2b375abee1439a->enter($__internal_0bd5e5c7bf2df19e38c0019303d1504622ba196607c62d373c2b375abee1439a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_e33134f6b85a54c4c8b9b7eb3cc44a69b4ff09582da783393f8ec0df3574e0cc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e33134f6b85a54c4c8b9b7eb3cc44a69b4ff09582da783393f8ec0df3574e0cc->enter($__internal_e33134f6b85a54c4c8b9b7eb3cc44a69b4ff09582da783393f8ec0df3574e0cc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    <h1>Espace Reseau</h1>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
";
        
        $__internal_e33134f6b85a54c4c8b9b7eb3cc44a69b4ff09582da783393f8ec0df3574e0cc->leave($__internal_e33134f6b85a54c4c8b9b7eb3cc44a69b4ff09582da783393f8ec0df3574e0cc_prof);

        
        $__internal_0bd5e5c7bf2df19e38c0019303d1504622ba196607c62d373c2b375abee1439a->leave($__internal_0bd5e5c7bf2df19e38c0019303d1504622ba196607c62d373c2b375abee1439a_prof);

    }

    public function getTemplateName()
    {
        return ":reseau:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 3,  40 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block body %}
    <h1>Espace Reseau</h1>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
{% endblock %}", ":reseau:index.html.twig", "C:\\wamp64\\www\\appli-era\\app/Resources\\views/reseau/index.html.twig");
    }
}
