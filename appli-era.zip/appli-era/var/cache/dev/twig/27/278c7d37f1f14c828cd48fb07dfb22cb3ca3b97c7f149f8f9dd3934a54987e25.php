<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_f8309c6faf8baa1ce2b6b081a06175fbdd5512ec275589ed20d0bb2dd7f144c6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3534cbcd01607445b3406f33ca3818c7b5b4834083a5870a32610674cb34e38f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3534cbcd01607445b3406f33ca3818c7b5b4834083a5870a32610674cb34e38f->enter($__internal_3534cbcd01607445b3406f33ca3818c7b5b4834083a5870a32610674cb34e38f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        $__internal_54327fb7d6c2de7176d881f234c8bad589767d656d634467c82c81812d17eaf1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_54327fb7d6c2de7176d881f234c8bad589767d656d634467c82c81812d17eaf1->enter($__internal_54327fb7d6c2de7176d881f234c8bad589767d656d634467c82c81812d17eaf1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_3534cbcd01607445b3406f33ca3818c7b5b4834083a5870a32610674cb34e38f->leave($__internal_3534cbcd01607445b3406f33ca3818c7b5b4834083a5870a32610674cb34e38f_prof);

        
        $__internal_54327fb7d6c2de7176d881f234c8bad589767d656d634467c82c81812d17eaf1->leave($__internal_54327fb7d6c2de7176d881f234c8bad589767d656d634467c82c81812d17eaf1_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@Framework/Form/button_label.html.php", "C:\\wamp64\\www\\appli-era\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\button_label.html.php");
    }
}
