<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_36cb82f75196bf9e4aab021893c45f899aca6e790c49083d9bb97811da40c120 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2b0829307e7ff8dde379729552dc43098122778f341d64284c7a092217ae3218 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2b0829307e7ff8dde379729552dc43098122778f341d64284c7a092217ae3218->enter($__internal_2b0829307e7ff8dde379729552dc43098122778f341d64284c7a092217ae3218_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_590a95e0f7f5d307e7360ed58e18a4ebc0d3f4ce16473957bbcabeaff38100e3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_590a95e0f7f5d307e7360ed58e18a4ebc0d3f4ce16473957bbcabeaff38100e3->enter($__internal_590a95e0f7f5d307e7360ed58e18a4ebc0d3f4ce16473957bbcabeaff38100e3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2b0829307e7ff8dde379729552dc43098122778f341d64284c7a092217ae3218->leave($__internal_2b0829307e7ff8dde379729552dc43098122778f341d64284c7a092217ae3218_prof);

        
        $__internal_590a95e0f7f5d307e7360ed58e18a4ebc0d3f4ce16473957bbcabeaff38100e3->leave($__internal_590a95e0f7f5d307e7360ed58e18a4ebc0d3f4ce16473957bbcabeaff38100e3_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_d32c24f6d6cba0be0b090fe76a7da3e029d8108b9de02b844c836bfb14470698 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d32c24f6d6cba0be0b090fe76a7da3e029d8108b9de02b844c836bfb14470698->enter($__internal_d32c24f6d6cba0be0b090fe76a7da3e029d8108b9de02b844c836bfb14470698_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_7580e348e3e56ef0d1cd92ceab415883f1bfe14049d1bacc99b396ca312b66f8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7580e348e3e56ef0d1cd92ceab415883f1bfe14049d1bacc99b396ca312b66f8->enter($__internal_7580e348e3e56ef0d1cd92ceab415883f1bfe14049d1bacc99b396ca312b66f8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_7580e348e3e56ef0d1cd92ceab415883f1bfe14049d1bacc99b396ca312b66f8->leave($__internal_7580e348e3e56ef0d1cd92ceab415883f1bfe14049d1bacc99b396ca312b66f8_prof);

        
        $__internal_d32c24f6d6cba0be0b090fe76a7da3e029d8108b9de02b844c836bfb14470698->leave($__internal_d32c24f6d6cba0be0b090fe76a7da3e029d8108b9de02b844c836bfb14470698_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_54aa26defcf4108f3ecaa078c687b962a26603eafd8861ff6b095bf09d061c98 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_54aa26defcf4108f3ecaa078c687b962a26603eafd8861ff6b095bf09d061c98->enter($__internal_54aa26defcf4108f3ecaa078c687b962a26603eafd8861ff6b095bf09d061c98_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_b902aa2f83dd2a1fbf3acf5a7d698896d8b78434b3b64286b61f06602bb1057b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b902aa2f83dd2a1fbf3acf5a7d698896d8b78434b3b64286b61f06602bb1057b->enter($__internal_b902aa2f83dd2a1fbf3acf5a7d698896d8b78434b3b64286b61f06602bb1057b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_b902aa2f83dd2a1fbf3acf5a7d698896d8b78434b3b64286b61f06602bb1057b->leave($__internal_b902aa2f83dd2a1fbf3acf5a7d698896d8b78434b3b64286b61f06602bb1057b_prof);

        
        $__internal_54aa26defcf4108f3ecaa078c687b962a26603eafd8861ff6b095bf09d061c98->leave($__internal_54aa26defcf4108f3ecaa078c687b962a26603eafd8861ff6b095bf09d061c98_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_415cf9e883f100174fe8eb1a1bf54f2e4a12e2751231c925c3dafceb50ad0958 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_415cf9e883f100174fe8eb1a1bf54f2e4a12e2751231c925c3dafceb50ad0958->enter($__internal_415cf9e883f100174fe8eb1a1bf54f2e4a12e2751231c925c3dafceb50ad0958_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_99fc5b7369628485af707180d1aa2e04e204c6b73cb14bb57017e8d4080bd563 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_99fc5b7369628485af707180d1aa2e04e204c6b73cb14bb57017e8d4080bd563->enter($__internal_99fc5b7369628485af707180d1aa2e04e204c6b73cb14bb57017e8d4080bd563_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_99fc5b7369628485af707180d1aa2e04e204c6b73cb14bb57017e8d4080bd563->leave($__internal_99fc5b7369628485af707180d1aa2e04e204c6b73cb14bb57017e8d4080bd563_prof);

        
        $__internal_415cf9e883f100174fe8eb1a1bf54f2e4a12e2751231c925c3dafceb50ad0958->leave($__internal_415cf9e883f100174fe8eb1a1bf54f2e4a12e2751231c925c3dafceb50ad0958_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "C:\\wamp64\\www\\appli-era\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
