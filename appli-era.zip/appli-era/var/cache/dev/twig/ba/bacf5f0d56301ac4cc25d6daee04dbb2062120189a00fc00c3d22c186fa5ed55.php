<?php

/* @Framework/Form/submit_widget.html.php */
class __TwigTemplate_f36809a933f07499a17a19595c53b10aa963ae08aa007722828a211328d0e041 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3c93c29426b8dfd25cfdbba6a18736a3340b4315f4341ebb8483aedea425a797 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3c93c29426b8dfd25cfdbba6a18736a3340b4315f4341ebb8483aedea425a797->enter($__internal_3c93c29426b8dfd25cfdbba6a18736a3340b4315f4341ebb8483aedea425a797_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/submit_widget.html.php"));

        $__internal_73da83c55e64f4ca9f71323f2a4d97aeacd010214e9e30ca85cd1787ce4acfd5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_73da83c55e64f4ca9f71323f2a4d97aeacd010214e9e30ca85cd1787ce4acfd5->enter($__internal_73da83c55e64f4ca9f71323f2a4d97aeacd010214e9e30ca85cd1787ce4acfd5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/submit_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'submit')) ?>
";
        
        $__internal_3c93c29426b8dfd25cfdbba6a18736a3340b4315f4341ebb8483aedea425a797->leave($__internal_3c93c29426b8dfd25cfdbba6a18736a3340b4315f4341ebb8483aedea425a797_prof);

        
        $__internal_73da83c55e64f4ca9f71323f2a4d97aeacd010214e9e30ca85cd1787ce4acfd5->leave($__internal_73da83c55e64f4ca9f71323f2a4d97aeacd010214e9e30ca85cd1787ce4acfd5_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/submit_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'submit')) ?>
", "@Framework/Form/submit_widget.html.php", "C:\\wamp64\\www\\appli-era\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\submit_widget.html.php");
    }
}
