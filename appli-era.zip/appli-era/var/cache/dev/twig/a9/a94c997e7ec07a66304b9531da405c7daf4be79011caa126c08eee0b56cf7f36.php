<?php

/* ::_macro.html.twig */
class __TwigTemplate_00b26029543ea3ddd10026d25addab08f2ab215e8fc494bde2af6a774af84e4f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c0c29bb2aa46a5af5980ffdaa3127ea62c250f6eaf9e20c617e335bf33e2fd04 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c0c29bb2aa46a5af5980ffdaa3127ea62c250f6eaf9e20c617e335bf33e2fd04->enter($__internal_c0c29bb2aa46a5af5980ffdaa3127ea62c250f6eaf9e20c617e335bf33e2fd04_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::_macro.html.twig"));

        $__internal_f6a3737abf995803dab41ee02fc4d83131c20362e39e3d3e4231147be2985599 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f6a3737abf995803dab41ee02fc4d83131c20362e39e3d3e4231147be2985599->enter($__internal_f6a3737abf995803dab41ee02fc4d83131c20362e39e3d3e4231147be2985599_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::_macro.html.twig"));

        
        $__internal_c0c29bb2aa46a5af5980ffdaa3127ea62c250f6eaf9e20c617e335bf33e2fd04->leave($__internal_c0c29bb2aa46a5af5980ffdaa3127ea62c250f6eaf9e20c617e335bf33e2fd04_prof);

        
        $__internal_f6a3737abf995803dab41ee02fc4d83131c20362e39e3d3e4231147be2985599->leave($__internal_f6a3737abf995803dab41ee02fc4d83131c20362e39e3d3e4231147be2985599_prof);

    }

    // line 1
    public function getnav_li_a($__route__ = null, $__name__ = null, $__icon__ = null, $__currentRoute__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "route" => $__route__,
            "name" => $__name__,
            "icon" => $__icon__,
            "currentRoute" => $__currentRoute__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            $__internal_f56603763da805cdefacb7b775d5faa0e93be49ba8899cf0cd1c288f8c3b7a56 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
            $__internal_f56603763da805cdefacb7b775d5faa0e93be49ba8899cf0cd1c288f8c3b7a56->enter($__internal_f56603763da805cdefacb7b775d5faa0e93be49ba8899cf0cd1c288f8c3b7a56_prof = new Twig_Profiler_Profile($this->getTemplateName(), "macro", "nav_li_a"));

            $__internal_c296b69c433f43c8fd17499764039c3ca3fd2adef630b9ed33f230b44f493b1d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
            $__internal_c296b69c433f43c8fd17499764039c3ca3fd2adef630b9ed33f230b44f493b1d->enter($__internal_c296b69c433f43c8fd17499764039c3ca3fd2adef630b9ed33f230b44f493b1d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "macro", "nav_li_a"));

            // line 2
            echo "
    <li class=\"";
            // line 3
            echo ((( !twig_test_empty(($context["currentRoute"] ?? $this->getContext($context, "currentRoute"))) && (($context["route"] ?? $this->getContext($context, "route")) == ($context["currentRoute"] ?? $this->getContext($context, "currentRoute"))))) ? ("active") : (""));
            echo "\">
        <a href=\"";
            // line 4
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath(($context["route"] ?? $this->getContext($context, "route")));
            echo "\">
            ";
            // line 5
            if ((array_key_exists("icon", $context) &&  !twig_test_empty(($context["icon"] ?? $this->getContext($context, "icon"))))) {
                // line 6
                echo "                <span class=\"fa fa-fw fa-";
                echo twig_escape_filter($this->env, ($context["icon"] ?? $this->getContext($context, "icon")), "html", null, true);
                echo "\"></span>
            ";
            }
            // line 8
            echo "            ";
            echo twig_escape_filter($this->env, ($context["name"] ?? $this->getContext($context, "name")), "html", null, true);
            echo "
        </a>
    </li>

";
            
            $__internal_c296b69c433f43c8fd17499764039c3ca3fd2adef630b9ed33f230b44f493b1d->leave($__internal_c296b69c433f43c8fd17499764039c3ca3fd2adef630b9ed33f230b44f493b1d_prof);

            
            $__internal_f56603763da805cdefacb7b775d5faa0e93be49ba8899cf0cd1c288f8c3b7a56->leave($__internal_f56603763da805cdefacb7b775d5faa0e93be49ba8899cf0cd1c288f8c3b7a56_prof);

        } catch (Exception $e) {
            ob_end_clean();

            throw $e;
        } catch (Throwable $e) {
            ob_end_clean();

            throw $e;
        }

        return ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
    }

    public function getTemplateName()
    {
        return "::_macro.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 8,  67 => 6,  65 => 5,  61 => 4,  57 => 3,  54 => 2,  33 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% macro nav_li_a(route, name, icon, currentRoute) %}

    <li class=\"{{ (currentRoute is not empty and route == currentRoute) ? 'active' }}\">
        <a href=\"{{ path(route) }}\">
            {% if icon is defined and icon is not empty %}
                <span class=\"fa fa-fw fa-{{ icon }}\"></span>
            {% endif %}
            {{ name }}
        </a>
    </li>

{% endmacro %}
", "::_macro.html.twig", "C:\\wamp64\\www\\appli-era\\app/Resources\\views/_macro.html.twig");
    }
}
