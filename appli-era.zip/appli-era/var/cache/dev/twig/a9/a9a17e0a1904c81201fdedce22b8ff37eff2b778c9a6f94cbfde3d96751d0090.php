<?php

/* ::menu.html.twig */
class __TwigTemplate_8027702464701bf7898432c080876c6997ae4b0a021e45f124b2312f84150ef2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e71fe61286cd1bea68ac64f0ee7b2d58cfc11797a16887a70176a9cd169b3f99 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e71fe61286cd1bea68ac64f0ee7b2d58cfc11797a16887a70176a9cd169b3f99->enter($__internal_e71fe61286cd1bea68ac64f0ee7b2d58cfc11797a16887a70176a9cd169b3f99_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::menu.html.twig"));

        $__internal_c2cc6023ef2b6c5a78738d84cbf877dfa3d5dbc83be945fb976077b083cdcb93 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c2cc6023ef2b6c5a78738d84cbf877dfa3d5dbc83be945fb976077b083cdcb93->enter($__internal_c2cc6023ef2b6c5a78738d84cbf877dfa3d5dbc83be945fb976077b083cdcb93_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::menu.html.twig"));

        
        $__internal_e71fe61286cd1bea68ac64f0ee7b2d58cfc11797a16887a70176a9cd169b3f99->leave($__internal_e71fe61286cd1bea68ac64f0ee7b2d58cfc11797a16887a70176a9cd169b3f99_prof);

        
        $__internal_c2cc6023ef2b6c5a78738d84cbf877dfa3d5dbc83be945fb976077b083cdcb93->leave($__internal_c2cc6023ef2b6c5a78738d84cbf877dfa3d5dbc83be945fb976077b083cdcb93_prof);

    }

    public function getTemplateName()
    {
        return "::menu.html.twig";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "::menu.html.twig", "C:\\wamp64\\www\\appli-era\\app/Resources\\views/menu.html.twig");
    }
}
