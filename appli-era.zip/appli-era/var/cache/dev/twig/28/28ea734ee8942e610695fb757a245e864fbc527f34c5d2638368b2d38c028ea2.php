<?php

/* admin/user/index.html.twig */
class __TwigTemplate_302d977680c41fce574837180c0fb7a4d3afc00a6589ff55000d31dede70d257 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("admin/base_admin.html.twig", "admin/user/index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "admin/base_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b099602b1cc0992d183dda1c6a954f5be4fd194fdc4d294208c7e89756f4882d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b099602b1cc0992d183dda1c6a954f5be4fd194fdc4d294208c7e89756f4882d->enter($__internal_b099602b1cc0992d183dda1c6a954f5be4fd194fdc4d294208c7e89756f4882d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/user/index.html.twig"));

        $__internal_e52659c7041f1d09a72a1f0633bf377e821406ab9a44ec550dfe72ac35dfe48f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e52659c7041f1d09a72a1f0633bf377e821406ab9a44ec550dfe72ac35dfe48f->enter($__internal_e52659c7041f1d09a72a1f0633bf377e821406ab9a44ec550dfe72ac35dfe48f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/user/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b099602b1cc0992d183dda1c6a954f5be4fd194fdc4d294208c7e89756f4882d->leave($__internal_b099602b1cc0992d183dda1c6a954f5be4fd194fdc4d294208c7e89756f4882d_prof);

        
        $__internal_e52659c7041f1d09a72a1f0633bf377e821406ab9a44ec550dfe72ac35dfe48f->leave($__internal_e52659c7041f1d09a72a1f0633bf377e821406ab9a44ec550dfe72ac35dfe48f_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_45aede779af07bc70b62273980856cd10f87536bee7cc1416a3addbf3479190e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_45aede779af07bc70b62273980856cd10f87536bee7cc1416a3addbf3479190e->enter($__internal_45aede779af07bc70b62273980856cd10f87536bee7cc1416a3addbf3479190e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_dd7de46e664bd7c1870d3fc6771c506176107b9a7b7ee696b82619c8da806c63 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dd7de46e664bd7c1870d3fc6771c506176107b9a7b7ee696b82619c8da806c63->enter($__internal_dd7de46e664bd7c1870d3fc6771c506176107b9a7b7ee696b82619c8da806c63_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
    <ul class=\"list-inline\">
        <li>
            <a class=\"btn btn-xs btn-success\" href=\"";
        // line 7
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_admin_user_create");
        echo "\">
                <span class=\"fa fa-plus\"></span>
                Créer
            </a>
        </li>
    </ul>
    <div class=\"panel panel-red margin-bottom-20\">
        <div class=\"panel-heading\">
            <h3 class=\"panel-title\"><i class=\"fa fa-user\"></i> LISTE DES UTILISATEURS</h3>
        </div>
        <div class=\"panel-body\">
            <table class=\"table table-hover\">
           <!--
            <thead>
                <tr>
                    <th>#</th>
                    <th>Civilité</th>
                    <th>Nom</th>
                    <th>Prénom</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Adresse</th>
                    <th>Code postal</th>
                    <th>Ville</th>
                    <th colspan=\"2\" class=\"sm\"></th>
                </tr>
            </thead>
            -->
            <tbody>
                ";
        // line 36
        $context["_token"] = $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderCsrfToken("USER_DELETE");
        // line 37
        echo "                ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["users"] ?? $this->getContext($context, "users")));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["user"]) {
            // line 38
            echo "                    <tr>
                        <td>";
            // line 39
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "id", array()), "html", null, true);
            echo "</td>
                        <td>";
            // line 40
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "civility", array()), "html", null, true);
            echo "</td>
                        <td>";
            // line 41
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "firstName", array()), "html", null, true);
            echo "</td>
                        <td>";
            // line 42
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "lastName", array()), "html", null, true);
            echo "</td>
                        <td>";
            // line 43
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "email", array()), "html", null, true);
            echo "</td>
                        <td>";
            // line 44
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "role", array()), "html", null, true);
            echo "</td>
                        <td>";
            // line 45
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "addressStreet", array()), "html", null, true);
            echo "</td>
                        <td>";
            // line 46
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "addressPostalCode", array()), "html", null, true);
            echo "</td>
                        <td>";
            // line 47
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "addressCity", array()), "html", null, true);
            echo "</td>

                        <td class=\"sm\">
                            <a class=\"btn btn-xs btn-warning\" href=\"";
            // line 50
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_admin_user_update", array("id" => $this->getAttribute($context["user"], "id", array()))), "html", null, true);
            echo "\">
                                <span class=\"fa fa-pencil\"></span>
                                Modifier
                            </a>
                        </td>
                        <td class=\"sm\">
                            <a class=\"btn btn-xs btn-danger\" href=\"";
            // line 56
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_admin_user_delete", array("id" => $this->getAttribute($context["user"], "id", array()), "_token" => ($context["_token"] ?? $this->getContext($context, "_token")))), "html", null, true);
            echo "\">
                                <span class=\"fa fa-trash-o\"></span>
                                Supprimer
                            </a>
                        </td>
                    </tr>
                ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 63
            echo "                    <tr>
                        <td colspan=\"100%\">
                            <p class=\"alert alert-info\">Aucun utilisateur trouvé.</p>
                        </td>
                    </tr>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['user'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 69
        echo "            </tbody>
        </table>
        </div>
    </div>
";
        
        $__internal_dd7de46e664bd7c1870d3fc6771c506176107b9a7b7ee696b82619c8da806c63->leave($__internal_dd7de46e664bd7c1870d3fc6771c506176107b9a7b7ee696b82619c8da806c63_prof);

        
        $__internal_45aede779af07bc70b62273980856cd10f87536bee7cc1416a3addbf3479190e->leave($__internal_45aede779af07bc70b62273980856cd10f87536bee7cc1416a3addbf3479190e_prof);

    }

    public function getTemplateName()
    {
        return "admin/user/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  167 => 69,  156 => 63,  144 => 56,  135 => 50,  129 => 47,  125 => 46,  121 => 45,  117 => 44,  113 => 43,  109 => 42,  105 => 41,  101 => 40,  97 => 39,  94 => 38,  88 => 37,  86 => 36,  54 => 7,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'admin/base_admin.html.twig' %}

{% block body %}

    <ul class=\"list-inline\">
        <li>
            <a class=\"btn btn-xs btn-success\" href=\"{{ path('app_admin_user_create') }}\">
                <span class=\"fa fa-plus\"></span>
                Créer
            </a>
        </li>
    </ul>
    <div class=\"panel panel-red margin-bottom-20\">
        <div class=\"panel-heading\">
            <h3 class=\"panel-title\"><i class=\"fa fa-user\"></i> LISTE DES UTILISATEURS</h3>
        </div>
        <div class=\"panel-body\">
            <table class=\"table table-hover\">
           <!--
            <thead>
                <tr>
                    <th>#</th>
                    <th>Civilité</th>
                    <th>Nom</th>
                    <th>Prénom</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Adresse</th>
                    <th>Code postal</th>
                    <th>Ville</th>
                    <th colspan=\"2\" class=\"sm\"></th>
                </tr>
            </thead>
            -->
            <tbody>
                {% set _token = csrf_token('USER_DELETE') %}
                {% for user in users %}
                    <tr>
                        <td>{{ user.id }}</td>
                        <td>{{ user.civility}}</td>
                        <td>{{ user.firstName}}</td>
                        <td>{{ user.lastName }}</td>
                        <td>{{ user.email }}</td>
                        <td>{{ user.role }}</td>
                        <td>{{ user.addressStreet }}</td>
                        <td>{{ user.addressPostalCode }}</td>
                        <td>{{ user.addressCity }}</td>

                        <td class=\"sm\">
                            <a class=\"btn btn-xs btn-warning\" href=\"{{ path('app_admin_user_update',{id:user.id}) }}\">
                                <span class=\"fa fa-pencil\"></span>
                                Modifier
                            </a>
                        </td>
                        <td class=\"sm\">
                            <a class=\"btn btn-xs btn-danger\" href=\"{{ path('app_admin_user_delete',{id:user.id,_token:_token}) }}\">
                                <span class=\"fa fa-trash-o\"></span>
                                Supprimer
                            </a>
                        </td>
                    </tr>
                {% else %}
                    <tr>
                        <td colspan=\"100%\">
                            <p class=\"alert alert-info\">Aucun utilisateur trouvé.</p>
                        </td>
                    </tr>
                {% endfor %}
            </tbody>
        </table>
        </div>
    </div>
{% endblock %}
", "admin/user/index.html.twig", "C:\\wamp64\\www\\appli-era\\app\\Resources\\views\\admin\\user\\index.html.twig");
    }
}
