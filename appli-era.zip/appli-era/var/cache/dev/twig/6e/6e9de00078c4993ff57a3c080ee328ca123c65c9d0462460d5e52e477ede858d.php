<?php

/* @Framework/Form/hidden_row.html.php */
class __TwigTemplate_c6b29fdb34b2ae741a02c62ef09a0660ef07dc2dc26ca52bccb62100c7d7df5b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0d80137f95c481c41a0704871716a54f419a94473f86191049f3b48b5724a834 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0d80137f95c481c41a0704871716a54f419a94473f86191049f3b48b5724a834->enter($__internal_0d80137f95c481c41a0704871716a54f419a94473f86191049f3b48b5724a834_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        $__internal_2ada2375086db5d1a6328a3470cdd21381930caab66e4561ccec0897fd067475 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2ada2375086db5d1a6328a3470cdd21381930caab66e4561ccec0897fd067475->enter($__internal_2ada2375086db5d1a6328a3470cdd21381930caab66e4561ccec0897fd067475_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->widget(\$form) ?>
";
        
        $__internal_0d80137f95c481c41a0704871716a54f419a94473f86191049f3b48b5724a834->leave($__internal_0d80137f95c481c41a0704871716a54f419a94473f86191049f3b48b5724a834_prof);

        
        $__internal_2ada2375086db5d1a6328a3470cdd21381930caab66e4561ccec0897fd067475->leave($__internal_2ada2375086db5d1a6328a3470cdd21381930caab66e4561ccec0897fd067475_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->widget(\$form) ?>
", "@Framework/Form/hidden_row.html.php", "C:\\wamp64\\www\\appli-era\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\hidden_row.html.php");
    }
}
