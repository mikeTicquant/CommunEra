<?php

/* :default:register.html.twig */
class __TwigTemplate_9ee6d39e0685f1d9306c1111f7f3258ca1dbe79a555b423d9b7a8796fb2f1d33 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":default:register.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_66be3c142ea7a2cd3d303286e120ff70e3f49b30deeb1620580350bdfb26b4e5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_66be3c142ea7a2cd3d303286e120ff70e3f49b30deeb1620580350bdfb26b4e5->enter($__internal_66be3c142ea7a2cd3d303286e120ff70e3f49b30deeb1620580350bdfb26b4e5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":default:register.html.twig"));

        $__internal_6d7daf038f0d83c68038cafd0f3bb95a5b5127ea3ecff8d9b983309e8ff002b7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6d7daf038f0d83c68038cafd0f3bb95a5b5127ea3ecff8d9b983309e8ff002b7->enter($__internal_6d7daf038f0d83c68038cafd0f3bb95a5b5127ea3ecff8d9b983309e8ff002b7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":default:register.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_66be3c142ea7a2cd3d303286e120ff70e3f49b30deeb1620580350bdfb26b4e5->leave($__internal_66be3c142ea7a2cd3d303286e120ff70e3f49b30deeb1620580350bdfb26b4e5_prof);

        
        $__internal_6d7daf038f0d83c68038cafd0f3bb95a5b5127ea3ecff8d9b983309e8ff002b7->leave($__internal_6d7daf038f0d83c68038cafd0f3bb95a5b5127ea3ecff8d9b983309e8ff002b7_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_400d0209eca4ae5f294780ca4446877d041022ab32ac9b88ce25e493f1e171db = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_400d0209eca4ae5f294780ca4446877d041022ab32ac9b88ce25e493f1e171db->enter($__internal_400d0209eca4ae5f294780ca4446877d041022ab32ac9b88ce25e493f1e171db_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_e452a7f82a472ce89ec64dc2a4b74cfa65f7253d5307808fef1e034e80281fae = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e452a7f82a472ce89ec64dc2a4b74cfa65f7253d5307808fef1e034e80281fae->enter($__internal_e452a7f82a472ce89ec64dc2a4b74cfa65f7253d5307808fef1e034e80281fae_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "<div class=\"page-register\">

    <div class=\"container content\">
        <div class=\"row\">
            <div class=\"col-md-8 col-md-offset-2\">


                    <fieldset>
                    <div>
                        <div class=\"headline\"><h2>Bienvenue sur PROSPEC-FLY</h2></div>
                        <p>Déjà inscrit? Cliquez sur <a href=\"";
        // line 13
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("login");
        echo "\" class=\"color-blue\">Se connecter</a> pour vous connecter à votre compte.</p>
                    </div>
                        <h3>Vos coordonnées personnelles</h3>
                    </fieldset>

                    <fieldset>
                        ";
        // line 19
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start', array("attr" => array("novalidate" => "novalidate")));
        echo "
                        ";
        // line 20
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "civility", array()), 'row');
        echo "
                        ";
        // line 21
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "first_name", array()), 'row');
        echo "
                        ";
        // line 22
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "last_name", array()), 'row');
        echo "
                        ";
        // line 23
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "email", array()), 'row');
        echo "
                        ";
        // line 24
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "job", array()), 'row');
        echo "
                        ";
        // line 25
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "role", array()), 'row');
        echo "
                        ";
        // line 26
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "address_street", array()), 'row');
        echo "
                        ";
        // line 27
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "address_postal_code", array()), 'row');
        echo "
                        ";
        // line 28
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "address_city", array()), 'row');
        echo "
                        ";
        // line 29
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "rawPassword", array()), 'row');
        echo "
                        ";
        // line 30
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "photoFile", array()), 'row');
        echo "
                        <hr>
                        <h3>Votre entreprise</h3>

                        ";
        // line 34
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["formBusiness"] ?? $this->getContext($context, "formBusiness")), 'row');
        echo "

                    </fieldset>
                    <button class=\"btn-u\" type=\"submit\">S'inscrie</button>
                    ";
        // line 38
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        echo "

            </div>
        </div>
    </div>

</div>
";
        
        $__internal_e452a7f82a472ce89ec64dc2a4b74cfa65f7253d5307808fef1e034e80281fae->leave($__internal_e452a7f82a472ce89ec64dc2a4b74cfa65f7253d5307808fef1e034e80281fae_prof);

        
        $__internal_400d0209eca4ae5f294780ca4446877d041022ab32ac9b88ce25e493f1e171db->leave($__internal_400d0209eca4ae5f294780ca4446877d041022ab32ac9b88ce25e493f1e171db_prof);

    }

    public function getTemplateName()
    {
        return ":default:register.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  128 => 38,  121 => 34,  114 => 30,  110 => 29,  106 => 28,  102 => 27,  98 => 26,  94 => 25,  90 => 24,  86 => 23,  82 => 22,  78 => 21,  74 => 20,  70 => 19,  61 => 13,  49 => 3,  40 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block body %}
<div class=\"page-register\">

    <div class=\"container content\">
        <div class=\"row\">
            <div class=\"col-md-8 col-md-offset-2\">


                    <fieldset>
                    <div>
                        <div class=\"headline\"><h2>Bienvenue sur PROSPEC-FLY</h2></div>
                        <p>Déjà inscrit? Cliquez sur <a href=\"{{ path(\"login\") }}\" class=\"color-blue\">Se connecter</a> pour vous connecter à votre compte.</p>
                    </div>
                        <h3>Vos coordonnées personnelles</h3>
                    </fieldset>

                    <fieldset>
                        {{ form_start(form,{attr:{novalidate:'novalidate'}}) }}
                        {{ form_row(form.civility) }}
                        {{ form_row(form.first_name) }}
                        {{ form_row(form.last_name) }}
                        {{ form_row(form.email) }}
                        {{ form_row(form.job) }}
                        {{ form_row(form.role) }}
                        {{ form_row(form.address_street) }}
                        {{ form_row(form.address_postal_code) }}
                        {{ form_row(form.address_city) }}
                        {{ form_row(form.rawPassword) }}
                        {{ form_row(form.photoFile) }}
                        <hr>
                        <h3>Votre entreprise</h3>

                        {{ form_row(formBusiness) }}

                    </fieldset>
                    <button class=\"btn-u\" type=\"submit\">S'inscrie</button>
                    {{ form_end(form) }}

            </div>
        </div>
    </div>

</div>
{% endblock %}
", ":default:register.html.twig", "C:\\wamp64\\www\\appli-era\\app/Resources\\views/default/register.html.twig");
    }
}
