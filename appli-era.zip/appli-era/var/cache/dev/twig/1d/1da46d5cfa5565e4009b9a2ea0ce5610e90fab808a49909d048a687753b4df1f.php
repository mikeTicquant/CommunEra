<?php

/* @Framework/Form/choice_options.html.php */
class __TwigTemplate_249942dc1bd6a1fa3960de53da2e6bf496c8faf802bdcd909d0f5790bcd286db extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fcb8ea0252d0fee1ff8eb0dc908f8ca315aac4408ea52c5e71ad25c4987f9a35 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fcb8ea0252d0fee1ff8eb0dc908f8ca315aac4408ea52c5e71ad25c4987f9a35->enter($__internal_fcb8ea0252d0fee1ff8eb0dc908f8ca315aac4408ea52c5e71ad25c4987f9a35_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        $__internal_fa6814f6ce02e3c20c8185e0ec8b701b0ae2a35f73872ae86e98f39dda6117fc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fa6814f6ce02e3c20c8185e0ec8b701b0ae2a35f73872ae86e98f39dda6117fc->enter($__internal_fa6814f6ce02e3c20c8185e0ec8b701b0ae2a35f73872ae86e98f39dda6117fc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
        
        $__internal_fcb8ea0252d0fee1ff8eb0dc908f8ca315aac4408ea52c5e71ad25c4987f9a35->leave($__internal_fcb8ea0252d0fee1ff8eb0dc908f8ca315aac4408ea52c5e71ad25c4987f9a35_prof);

        
        $__internal_fa6814f6ce02e3c20c8185e0ec8b701b0ae2a35f73872ae86e98f39dda6117fc->leave($__internal_fa6814f6ce02e3c20c8185e0ec8b701b0ae2a35f73872ae86e98f39dda6117fc_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_options.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
", "@Framework/Form/choice_options.html.php", "C:\\wamp64\\www\\appli-era\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\choice_options.html.php");
    }
}
