<?php

/* user/profile.html.twig */
class __TwigTemplate_41b7af6e6cf33319d05749f9d06a151d345f38d4e5cd5c1eff19fb28424c711a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "user/profile.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8e3492fc9d6458a05adc5bfd3f90b0188d88f328c9ca981425d15daa9488513e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8e3492fc9d6458a05adc5bfd3f90b0188d88f328c9ca981425d15daa9488513e->enter($__internal_8e3492fc9d6458a05adc5bfd3f90b0188d88f328c9ca981425d15daa9488513e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/profile.html.twig"));

        $__internal_b134d68072856bf9453c8b66c7e47316fbaabe834c8dea7d0b21812444551883 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b134d68072856bf9453c8b66c7e47316fbaabe834c8dea7d0b21812444551883->enter($__internal_b134d68072856bf9453c8b66c7e47316fbaabe834c8dea7d0b21812444551883_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/profile.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8e3492fc9d6458a05adc5bfd3f90b0188d88f328c9ca981425d15daa9488513e->leave($__internal_8e3492fc9d6458a05adc5bfd3f90b0188d88f328c9ca981425d15daa9488513e_prof);

        
        $__internal_b134d68072856bf9453c8b66c7e47316fbaabe834c8dea7d0b21812444551883->leave($__internal_b134d68072856bf9453c8b66c7e47316fbaabe834c8dea7d0b21812444551883_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_e594ca792b4667bd3f72c40a519d54c23427208ef7f20954016e6c093a726c80 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e594ca792b4667bd3f72c40a519d54c23427208ef7f20954016e6c093a726c80->enter($__internal_e594ca792b4667bd3f72c40a519d54c23427208ef7f20954016e6c093a726c80_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_409733f072ec267e357df8b2ca5c546b1c8bb85b213488498d25997afddf5fca = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_409733f072ec267e357df8b2ca5c546b1c8bb85b213488498d25997afddf5fca->enter($__internal_409733f072ec267e357df8b2ca5c546b1c8bb85b213488498d25997afddf5fca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "
    <div class=\"container content profile\">
        <div class=\"row\">
            <!--Left Sidebar-->
            <div class=\"col-md-3 md-margin-bottom-40\">

                ";
        // line 11
        $context["filename"] = (($this->getAttribute($this->getAttribute(($context["app"] ?? null), "user", array(), "any", false, true), "photo", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute($this->getAttribute(($context["app"] ?? null), "user", array(), "any", false, true), "photo", array()), "img32-md.jpg")) : ("img32-md.jpg"));
        // line 12
        echo "                ";
        $context["url"] = ((($context["globalUserPhotoUri"] ?? $this->getContext($context, "globalUserPhotoUri")) . "/") . ($context["filename"] ?? $this->getContext($context, "filename")));
        // line 13
        echo "                <img class=\"img-thumbnail\" id=\"photo\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl(($context["url"] ?? $this->getContext($context, "url"))), "html", null, true);
        echo "\"/>
                <br><br>
                <ul class=\"list-group sidebar-nav-v1 margin-bottom-40\" id=\"sidebar-nav-1\">
                    <li class=\"list-group-item active\">
                        <a href=\"#\"><i class=\"fa fa-bar-chart-o\"></i> Tableau de bord</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"";
        // line 20
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_profil");
        echo "\">
                            <i class=\"fa fa-user\"></i> Profil
                        </a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"";
        // line 25
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_addreseau");
        echo "\">
                            <i class=\"fa fa-building-o\"></i> Entreprise
                        </a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"";
        // line 30
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_affiliate");
        echo "\">
                            <i class=\"fa fa-flag-o\"></i> Code d'affialition
                        </a>
                    </li>

                    <li class=\"list-group-item\">
                        <a href=\"#\"><i class=\"fa fa-cog\"></i> Settings</a>
                    </li>
                </ul>

            </div>
            <!--End Left Sidebar-->

            <!-- Profile Content -->
            <div class=\"col-md-9\">
                <div class=\"profile-body margin-bottom-20\">
                    <div class=\"tab-v1\">
                        <ul class=\"nav nav-justified nav-tabs\">
                            <li class=\"active\"><a data-toggle=\"tab\" href=\"#myprofile\">Mon Profil</a></li>
                            <li><a data-toggle=\"tab\" href=\"#profile\">Modifier Profil</a></li>
                            <li><a data-toggle=\"tab\" href=\"#passwordTab\">Changer Password</a></li>
                            <li><a data-toggle=\"tab\" href=\"#settings\">Notifications Settings</a></li>
                        </ul>
                        <div class=\"tab-content\">
                            <div id=\"myprofile\" class=\"profile-edit tab-pane fade in active\">


                                ";
        // line 57
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["users"] ?? $this->getContext($context, "users")));
        foreach ($context['_seq'] as $context["_key"] => $context["user"]) {
            // line 58
            echo "                                <dl class=\"dl-horizontal\">

                                    <dt><strong>Adresse e-mail </strong></dt>
                                    <dd>";
            // line 61
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "email", array()), "html", null, true);
            echo "</dd>
                                    <hr>

                                    <dt><strong>Civilité </strong></dt>
                                    <dd>";
            // line 65
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "civility", array()), "html", null, true);
            echo "</dd>
                                    <hr>

                                    <dt><strong>Nom </strong></dt>
                                    <dd>";
            // line 69
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "firstName", array()), "html", null, true);
            echo "</dd>
                                    <hr>

                                    <dt><strong>Prénom </strong></dt>
                                    <dd>";
            // line 73
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "lastName", array()), "html", null, true);
            echo "</dd>
                                    <hr>

                                    <dt><strong>Adresse personnelle </strong></dt>
                                    <dd>";
            // line 77
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "addressStreet", array()), "html", null, true);
            echo "</dd>
                                    <hr>

                                    <dt><strong>Ville </strong></dt>
                                    <dd>";
            // line 81
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "addressCity", array()), "html", null, true);
            echo "</dd>
                                    <hr>

                                    <dt><strong>Code postal </strong></dt>
                                    <dd>";
            // line 85
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "addressPostalCode", array()), "html", null, true);
            echo "</dd>
                                    <hr>

                                    <dt><strong>Type de comptes </strong></dt>
                                    <dd>";
            // line 89
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "role", array()), "html", null, true);
            echo "</dd>
                                    <hr>

                                    <dt><strong>Poste </strong></dt>
                                    <dd>";
            // line 93
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "job", array()), "html", null, true);
            echo "</dd>
                                    <hr>
                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['user'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 96
        echo "                                </dl>
                            </div>

                            <div id=\"profile\" class=\"profile-edit tab-pane\">
                                <h2 class=\"heading-md\">Mes coordonnées :</h2>
                                ";
        // line 101
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["formDetails"] ?? $this->getContext($context, "formDetails")), 'form_start', array("attr" => array("novalidate" => "novalidate")));
        echo "
                                ";
        // line 102
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["formDetails"] ?? $this->getContext($context, "formDetails")), 'form');
        echo "

                                <button type=\"submit\" class=\"btn-u\">Valider les modifications</button>
                                <button type=\"button\" class=\"btn-u btn-u-default\">Annuler</button>
                                ";
        // line 106
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["formDetails"] ?? $this->getContext($context, "formDetails")), 'form_end');
        echo "
                            </div>


                            <div id=\"passwordTab\" class=\"profile-edit tab-pane fade\">
                                <h2 class=\"heading-md\">Gestion de sécurité</h2>
                                <p>Modifier mon mot de passe.</p>
                                <br>
                                <form class=\"sky-form\" id=\"sky-form4\" action=\"#\">
                                    <dl class=\"dl-horizontal\">
                                        <dt>Username</dt>
                                        <dd>
                                            <section>
                                                <label class=\"input\">
                                                    <i class=\"icon-append fa fa-user\"></i>
                                                    <input type=\"text\" placeholder=\"Username\" name=\"username\">
                                                    <b class=\"tooltip tooltip-bottom-right\">Needed to enter the website</b>
                                                </label>
                                            </section>
                                        </dd>
                                        <dt>Adresse Email</dt>
                                        <dd>
                                            <section>
                                                <label class=\"input\">
                                                    <i class=\"icon-append fa fa-envelope\"></i>
                                                    <input type=\"email\" placeholder=\"Email address\" name=\"email\">
                                                    <b class=\"tooltip tooltip-bottom-right\">Needed to verify your account</b>
                                                </label>
                                            </section>
                                        </dd>
                                        <dt>Entrer votre mot de passe</dt>
                                        <dd>
                                            <section>
                                                <label class=\"input\">
                                                    <i class=\"icon-append fa fa-lock\"></i>
                                                    <input type=\"password\" id=\"password\" name=\"password\" placeholder=\"Password\">
                                                    <b class=\"tooltip tooltip-bottom-right\">Don't forget your password</b>
                                                </label>
                                            </section>
                                        </dd>
                                        <dt>Confirmer Mot de passe</dt>
                                        <dd>
                                            <section>
                                                <label class=\"input\">
                                                    <i class=\"icon-append fa fa-lock\"></i>
                                                    <input type=\"password\" name=\"passwordConfirm\" placeholder=\"Confirm password\">
                                                    <b class=\"tooltip tooltip-bottom-right\">Don't forget your password</b>
                                                </label>
                                            </section>
                                        </dd>
                                    </dl>

                                    <br>

                                    <button class=\"btn-u\" type=\"submit\">Valider les modifications</button>
                                    <button type=\"button\" class=\"btn-u btn-u-default\">Annuler</button>
                                </form>
                            </div>


                            <div id=\"settings\" class=\"profile-edit tab-pane fade\">
                                <h2 class=\"heading-md\">Gestion des Notifications.</h2>

                                <br>
                                <form class=\"sky-form\" id=\"sky-form3\" action=\"#\">
                                    <label class=\"toggle\"><input type=\"checkbox\" checked=\"\" name=\"checkbox-toggle-1\"><i class=\"no-rounded\"></i></label>
                                    <hr>
                                    <label class=\"toggle\"><input type=\"checkbox\" checked=\"\" name=\"checkbox-toggle-1\"><i class=\"no-rounded\"></i>Send me email notification when a user comments on my blog</label>
                                    <hr>
                                    <label class=\"toggle\"><input type=\"checkbox\" checked=\"\" name=\"checkbox-toggle-1\"><i class=\"no-rounded\"></i>Send me email notification for the latest update</label>
                                    <hr>
                                    <label class=\"toggle\"><input type=\"checkbox\" checked=\"\" name=\"checkbox-toggle-1\"><i class=\"no-rounded\"></i>Send me email notification when a user sends me message</label>
                                    <hr>
                                    <label class=\"toggle\"><input type=\"checkbox\" checked=\"\" name=\"checkbox-toggle-1\"><i class=\"no-rounded\"></i>Receive our monthly newsletter</label>
                                    <hr>
                                    <button class=\"btn-u\" type=\"submit\">Enregistrer les modification</button>
                                    <button type=\"button\" class=\"btn-u btn-u-default\">Annuler</button>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Profile Content -->
        </div><!--/end row-->
    </div>


";
        
        $__internal_409733f072ec267e357df8b2ca5c546b1c8bb85b213488498d25997afddf5fca->leave($__internal_409733f072ec267e357df8b2ca5c546b1c8bb85b213488498d25997afddf5fca_prof);

        
        $__internal_e594ca792b4667bd3f72c40a519d54c23427208ef7f20954016e6c093a726c80->leave($__internal_e594ca792b4667bd3f72c40a519d54c23427208ef7f20954016e6c093a726c80_prof);

    }

    public function getTemplateName()
    {
        return "user/profile.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  211 => 106,  204 => 102,  200 => 101,  193 => 96,  184 => 93,  177 => 89,  170 => 85,  163 => 81,  156 => 77,  149 => 73,  142 => 69,  135 => 65,  128 => 61,  123 => 58,  119 => 57,  89 => 30,  81 => 25,  73 => 20,  62 => 13,  59 => 12,  57 => 11,  49 => 5,  40 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}


{% block body %}

    <div class=\"container content profile\">
        <div class=\"row\">
            <!--Left Sidebar-->
            <div class=\"col-md-3 md-margin-bottom-40\">

                {% set filename = app.user.photo|default('img32-md.jpg') %}
                {% set url = globalUserPhotoUri ~ '/' ~ filename %}
                <img class=\"img-thumbnail\" id=\"photo\" src=\"{{ asset(url) }}\"/>
                <br><br>
                <ul class=\"list-group sidebar-nav-v1 margin-bottom-40\" id=\"sidebar-nav-1\">
                    <li class=\"list-group-item active\">
                        <a href=\"#\"><i class=\"fa fa-bar-chart-o\"></i> Tableau de bord</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"{{ path('app_user_user_profil') }}\">
                            <i class=\"fa fa-user\"></i> Profil
                        </a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"{{ path('app_user_user_addreseau') }}\">
                            <i class=\"fa fa-building-o\"></i> Entreprise
                        </a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"{{ path('app_user_user_affiliate') }}\">
                            <i class=\"fa fa-flag-o\"></i> Code d'affialition
                        </a>
                    </li>

                    <li class=\"list-group-item\">
                        <a href=\"#\"><i class=\"fa fa-cog\"></i> Settings</a>
                    </li>
                </ul>

            </div>
            <!--End Left Sidebar-->

            <!-- Profile Content -->
            <div class=\"col-md-9\">
                <div class=\"profile-body margin-bottom-20\">
                    <div class=\"tab-v1\">
                        <ul class=\"nav nav-justified nav-tabs\">
                            <li class=\"active\"><a data-toggle=\"tab\" href=\"#myprofile\">Mon Profil</a></li>
                            <li><a data-toggle=\"tab\" href=\"#profile\">Modifier Profil</a></li>
                            <li><a data-toggle=\"tab\" href=\"#passwordTab\">Changer Password</a></li>
                            <li><a data-toggle=\"tab\" href=\"#settings\">Notifications Settings</a></li>
                        </ul>
                        <div class=\"tab-content\">
                            <div id=\"myprofile\" class=\"profile-edit tab-pane fade in active\">


                                {% for user in users %}
                                <dl class=\"dl-horizontal\">

                                    <dt><strong>Adresse e-mail </strong></dt>
                                    <dd>{{ user.email }}</dd>
                                    <hr>

                                    <dt><strong>Civilité </strong></dt>
                                    <dd>{{ user.civility }}</dd>
                                    <hr>

                                    <dt><strong>Nom </strong></dt>
                                    <dd>{{ user.firstName }}</dd>
                                    <hr>

                                    <dt><strong>Prénom </strong></dt>
                                    <dd>{{ user.lastName }}</dd>
                                    <hr>

                                    <dt><strong>Adresse personnelle </strong></dt>
                                    <dd>{{ user.addressStreet }}</dd>
                                    <hr>

                                    <dt><strong>Ville </strong></dt>
                                    <dd>{{ user.addressCity }}</dd>
                                    <hr>

                                    <dt><strong>Code postal </strong></dt>
                                    <dd>{{ user.addressPostalCode }}</dd>
                                    <hr>

                                    <dt><strong>Type de comptes </strong></dt>
                                    <dd>{{ user.role }}</dd>
                                    <hr>

                                    <dt><strong>Poste </strong></dt>
                                    <dd>{{ user.job }}</dd>
                                    <hr>
                                    {% endfor %}
                                </dl>
                            </div>

                            <div id=\"profile\" class=\"profile-edit tab-pane\">
                                <h2 class=\"heading-md\">Mes coordonnées :</h2>
                                {{ form_start(formDetails,{attr:{novalidate:'novalidate'}}) }}
                                {{ form(formDetails) }}

                                <button type=\"submit\" class=\"btn-u\">Valider les modifications</button>
                                <button type=\"button\" class=\"btn-u btn-u-default\">Annuler</button>
                                {{ form_end(formDetails) }}
                            </div>


                            <div id=\"passwordTab\" class=\"profile-edit tab-pane fade\">
                                <h2 class=\"heading-md\">Gestion de sécurité</h2>
                                <p>Modifier mon mot de passe.</p>
                                <br>
                                <form class=\"sky-form\" id=\"sky-form4\" action=\"#\">
                                    <dl class=\"dl-horizontal\">
                                        <dt>Username</dt>
                                        <dd>
                                            <section>
                                                <label class=\"input\">
                                                    <i class=\"icon-append fa fa-user\"></i>
                                                    <input type=\"text\" placeholder=\"Username\" name=\"username\">
                                                    <b class=\"tooltip tooltip-bottom-right\">Needed to enter the website</b>
                                                </label>
                                            </section>
                                        </dd>
                                        <dt>Adresse Email</dt>
                                        <dd>
                                            <section>
                                                <label class=\"input\">
                                                    <i class=\"icon-append fa fa-envelope\"></i>
                                                    <input type=\"email\" placeholder=\"Email address\" name=\"email\">
                                                    <b class=\"tooltip tooltip-bottom-right\">Needed to verify your account</b>
                                                </label>
                                            </section>
                                        </dd>
                                        <dt>Entrer votre mot de passe</dt>
                                        <dd>
                                            <section>
                                                <label class=\"input\">
                                                    <i class=\"icon-append fa fa-lock\"></i>
                                                    <input type=\"password\" id=\"password\" name=\"password\" placeholder=\"Password\">
                                                    <b class=\"tooltip tooltip-bottom-right\">Don't forget your password</b>
                                                </label>
                                            </section>
                                        </dd>
                                        <dt>Confirmer Mot de passe</dt>
                                        <dd>
                                            <section>
                                                <label class=\"input\">
                                                    <i class=\"icon-append fa fa-lock\"></i>
                                                    <input type=\"password\" name=\"passwordConfirm\" placeholder=\"Confirm password\">
                                                    <b class=\"tooltip tooltip-bottom-right\">Don't forget your password</b>
                                                </label>
                                            </section>
                                        </dd>
                                    </dl>

                                    <br>

                                    <button class=\"btn-u\" type=\"submit\">Valider les modifications</button>
                                    <button type=\"button\" class=\"btn-u btn-u-default\">Annuler</button>
                                </form>
                            </div>


                            <div id=\"settings\" class=\"profile-edit tab-pane fade\">
                                <h2 class=\"heading-md\">Gestion des Notifications.</h2>

                                <br>
                                <form class=\"sky-form\" id=\"sky-form3\" action=\"#\">
                                    <label class=\"toggle\"><input type=\"checkbox\" checked=\"\" name=\"checkbox-toggle-1\"><i class=\"no-rounded\"></i></label>
                                    <hr>
                                    <label class=\"toggle\"><input type=\"checkbox\" checked=\"\" name=\"checkbox-toggle-1\"><i class=\"no-rounded\"></i>Send me email notification when a user comments on my blog</label>
                                    <hr>
                                    <label class=\"toggle\"><input type=\"checkbox\" checked=\"\" name=\"checkbox-toggle-1\"><i class=\"no-rounded\"></i>Send me email notification for the latest update</label>
                                    <hr>
                                    <label class=\"toggle\"><input type=\"checkbox\" checked=\"\" name=\"checkbox-toggle-1\"><i class=\"no-rounded\"></i>Send me email notification when a user sends me message</label>
                                    <hr>
                                    <label class=\"toggle\"><input type=\"checkbox\" checked=\"\" name=\"checkbox-toggle-1\"><i class=\"no-rounded\"></i>Receive our monthly newsletter</label>
                                    <hr>
                                    <button class=\"btn-u\" type=\"submit\">Enregistrer les modification</button>
                                    <button type=\"button\" class=\"btn-u btn-u-default\">Annuler</button>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Profile Content -->
        </div><!--/end row-->
    </div>


{% endblock %}

", "user/profile.html.twig", "C:\\wamp64\\www\\appli-era\\app\\Resources\\views\\user\\profile.html.twig");
    }
}
