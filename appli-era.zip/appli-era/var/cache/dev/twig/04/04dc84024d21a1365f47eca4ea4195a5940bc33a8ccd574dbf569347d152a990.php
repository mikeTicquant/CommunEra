<?php

/* @Framework/Form/collection_widget.html.php */
class __TwigTemplate_0468f05df4181cc993fdbbb1cec4990b280077f600dc89689db138ed15838f93 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b2d0185c1354891bec0b0abb71782bc37368c65d4d2ddd6c463150f461dff68a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b2d0185c1354891bec0b0abb71782bc37368c65d4d2ddd6c463150f461dff68a->enter($__internal_b2d0185c1354891bec0b0abb71782bc37368c65d4d2ddd6c463150f461dff68a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        $__internal_eb74552df778725ceb285e20f4c9963d126810cb1fc9df5201b42096ad87fefe = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eb74552df778725ceb285e20f4c9963d126810cb1fc9df5201b42096ad87fefe->enter($__internal_eb74552df778725ceb285e20f4c9963d126810cb1fc9df5201b42096ad87fefe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        // line 1
        echo "<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
";
        
        $__internal_b2d0185c1354891bec0b0abb71782bc37368c65d4d2ddd6c463150f461dff68a->leave($__internal_b2d0185c1354891bec0b0abb71782bc37368c65d4d2ddd6c463150f461dff68a_prof);

        
        $__internal_eb74552df778725ceb285e20f4c9963d126810cb1fc9df5201b42096ad87fefe->leave($__internal_eb74552df778725ceb285e20f4c9963d126810cb1fc9df5201b42096ad87fefe_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/collection_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
", "@Framework/Form/collection_widget.html.php", "C:\\wamp64\\www\\appli-era\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\collection_widget.html.php");
    }
}
