<?php

/* :default:index.html.twig */
class __TwigTemplate_080ffa078d122b74807f95d5ee5c001273a51e53222171438d50d0d6c52d296b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f1bdb2ad55f0d5c25fcfa66f21142bbb78467305e9e69abf4d515199645d66eb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f1bdb2ad55f0d5c25fcfa66f21142bbb78467305e9e69abf4d515199645d66eb->enter($__internal_f1bdb2ad55f0d5c25fcfa66f21142bbb78467305e9e69abf4d515199645d66eb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":default:index.html.twig"));

        $__internal_4e78069554f4a97fd9283c41ad726dee9d0cfae7d1b2af057d6e4c18a12a961e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4e78069554f4a97fd9283c41ad726dee9d0cfae7d1b2af057d6e4c18a12a961e->enter($__internal_4e78069554f4a97fd9283c41ad726dee9d0cfae7d1b2af057d6e4c18a12a961e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":default:index.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<!--[if IE 8]> <html lang=\"en\" class=\"ie8\"> <![endif]-->
<!--[if IE 9]> <html lang=\"en\" class=\"ie9\"> <![endif]-->
<!--[if !IE]><!--> <html lang=\"en\"> <!--<![endif]-->
<head>
\t<title>Applicatoin gestion de prospection</title>

\t<!-- Meta -->
\t<meta charset=\"utf-8\">
\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
\t<meta name=\"description\" content=\"\">
\t<meta name=\"author\" content=\"\">

\t<!-- Favicon -->
\t<link rel=\"shortcut icon\" href=\"favicon.ico\">

\t<!-- Web Fonts -->
\t<link rel=\"stylesheet\" href=\"//fonts.googleapis.com/css?family=Open+Sans:400,300,600&amp;subset=cyrillic,latin\">

\t<!-- CSS Global Compulsory -->
\t<link rel=\"stylesheet\" href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/bootstrap/css/bootstrap.min.css"), "html", null, true);
        echo "\">
\t<link rel=\"stylesheet\" href=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/style.css"), "html", null, true);
        echo "\">

\t<!-- CSS Header and Footer -->
\t<link rel=\"stylesheet\" href=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/headers/header-v6.css"), "html", null, true);
        echo "\">
\t<link rel=\"stylesheet\" href=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/footers/footer-v6.css"), "html", null, true);
        echo "\">

\t<!-- CSS Implementing Plugins -->
\t<link rel=\"stylesheet\" href=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/animate.css"), "html", null, true);
        echo "\">
\t<link rel=\"stylesheet\" href=\"";
        // line 30
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/line-icons/line-icons.css"), "html", null, true);
        echo "\">
\t<link rel=\"stylesheet\" href=\"";
        // line 31
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/font-awesome/css/font-awesome.min.css"), "html", null, true);
        echo "\">
\t<link rel=\"stylesheet\" href=\"";
        // line 32
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/sliding-panel/style.css"), "html", null, true);
        echo "\">
\t<link rel=\"stylesheet\" href=\"";
        // line 33
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/owl-carousel/owl-carousel/owl.carousel.css"), "html", null, true);
        echo "\">
\t<link rel=\"stylesheet\" href=\"";
        // line 34
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/cube-portfolio/cubeportfolio/css/cubeportfolio.min.css"), "html", null, true);
        echo "\">

\t<!-- CSS Theme -->
\t<link rel=\"stylesheet\" href=\"";
        // line 37
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/theme-colors/default.css"), "html", null, true);
        echo "\" id=\"style_color\">
\t<link rel=\"stylesheet\" href=\"";
        // line 38
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/theme-skins/dark.css"), "html", null, true);
        echo "\">

\t<!-- CSS Customization -->
\t<link rel=\"stylesheet\" href=\"";
        // line 41
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/custom.css"), "html", null, true);
        echo "\">
</head>

<body class=\"header-fixed header-fixed-space promo-padding-top sliding-panel-ini sliding-panel-flag-right\">
\t<div class=\"wrapper\">
\t\t<!--=== Header v6 ===-->
\t\t<div class=\"header-v6 header-classic-white header-sticky\">
\t\t\t<!-- Navbar -->
\t\t\t<div class=\"navbar mega-menu\" role=\"navigation\">
\t\t\t\t<div class=\"container\">
\t\t\t\t\t<!-- Brand and toggle get grouped for better mobile display -->
\t\t\t\t\t<div class=\"menu-container\">
\t\t\t\t\t\t<button type=\"button\" class=\"navbar-toggle sliding-panel__btn sliding-panel__btn--dark\">
\t\t\t\t\t\t\t<span class=\"sr-only\">Toggle navigation</span>
\t\t\t\t\t\t\t<span class=\"icon-bar\"></span>
\t\t\t\t\t\t\t<span class=\"icon-bar\"></span>
\t\t\t\t\t\t\t<span class=\"icon-bar\"></span>
\t\t\t\t\t\t</button>

\t\t\t\t\t\t<!-- Navbar Brand -->
\t\t\t\t\t\t<div class=\"navbar-brand\">
\t\t\t\t\t\t\t<a href=\"index.html\">
\t\t\t\t\t\t\t<h1>PROSPEC</h1>
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<!-- ENd Navbar Brand -->

\t\t\t\t\t\t<!-- Header Inner Right -->
\t\t\t\t\t\t<div class=\"header-inner-right\">
\t\t\t\t\t\t\t<ul class=\"menu-icons-list\">

\t\t\t\t\t\t\t\t<li class=\"menu-icons\">
\t\t\t\t\t\t\t\t\t<i class=\"menu-icons-style search search-close search-btn fa fa-search\"></i>
\t\t\t\t\t\t\t\t\t<div class=\"search-open\">
\t\t\t\t\t\t\t\t\t\t<input type=\"text\" class=\"animated fadeIn form-control\" placeholder=\"Rechercher ...\">
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<!-- End Header Inner Right -->
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<!-- End Navbar -->
\t\t</div>
\t\t<!--=== End Header v6 ===-->

\t\t<!-- Promo Block -->
\t\t<div class=\"promo-bg-pattern-v1-dark promo-bg-fixed content-xlg parallaxBg\">
\t\t\t<div class=\"container text-center\" data-start=\"opacity: 1;\" data-320=\"opacity: 0;\">
\t\t\t\t<div class=\"margin-bottom-20\">
\t\t\t\t\t<a class=\"promo-video-icon-wrap color-light rounded-x animated fadeInUp wow cbp-lightbox\" data-wow-duration=\"2s\" data-wow-delay=\".5s\" data-title=\"Video Presentation\" href=\"https://player.vimeo.com/video/58363288?&rel=0&autoplay=1\">
\t\t\t\t\t\t<i class=\"promo-video-icon icon-control-play\"></i>
\t\t\t\t\t</a>
\t\t\t\t\t<div id=\"cbp-lightbox\" class=\"dp-none\"></div>
\t\t\t\t</div>

\t\t\t\t<span class=\"promo-text-v1 color-light margin-bottom-10 animated fadeInUp wow\" data-wow-duration=\"1.5s\" data-wow-delay=\"1s\">
\t\t\t\t\tApplication Prospec
\t\t\t\t</span>

\t\t\t\t<h2 class=\"promo-text-v2 color-light animated fadeInUp wow margin-bottom-20\" data-wow-duration=\"1.5s\" data-wow-delay=\"1.5s\">Gestion des prospections</h2>

\t\t\t\t<div class=\"animated fadeInUp wow\" data-wow-duration=\"1.2s\" data-wow-delay=\"2s\">
\t\t\t\t\t<a href=\"";
        // line 105
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_signup");
        echo "\" class=\"btn-u btn-brd btn-brd-width-2 btn-brd-hover btn-u-light btn-u-block rounded-4x margin-right-10\">Inscription</a>
\t\t\t\t\t<a href=\"";
        // line 106
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("login");
        echo "\" class=\"btn-u btn-brd btn-brd-width-2 btn-brd-hover btn-u-light btn-u-block rounded-4x margin-right-10\">Connexion</a>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t\t<!-- End Promo Block -->








\t</div><!--/wrapper-->

\t<!-- Sliding Panel -->
\t<div class=\"sliding-panel bg-color-darker\">
\t\t<div class=\"sliding-panel-inner sliding-panel-scrollable fullscreen\">
\t\t\t<ul class=\"sliding-navigation\">
\t\t\t\t<li><a href=\"index.html\">Home</a></li>
\t\t\t\t<li><a href=\"page_about3.html\">Abour Us</a></li>
\t\t\t\t<li><a href=\"page_services.html\">Services</a></li>
\t\t\t\t<li><a href=\"page_profile.html\">Profile</a></li>
\t\t\t\t<li><a href=\"blog_large_right_sidebar1.html\">Blog</a></li>
\t\t\t\t<li><a href=\"portfolio_3_columns_grid_text.html\">Our Work</a></li>
\t\t\t\t<li><a href=\"page_contact1.html\">Contact Us</a></li>
\t\t\t</ul>

\t\t\t<h4>Contacts</h4>
\t\t\t<address>
\t\t\t\t58, Lorem Lis Street, Central Ave<br>
\t\t\t\tNew York, US<br><br>
\t\t\t\tPhone: 938 334 6049<br>
\t\t\t\tFax: 938 334 6050<br><br>
\t\t\t\tEmail: <a href=\"mailto:#\">info@htmlstream.com</a><br>
\t\t\t</address>

\t\t\t<ul class=\"list-inline social-icons-v1 social-icons-v1--dark\">
\t\t\t\t<li><a href=\"#\"><i class=\"fa fa-twitter\"></i></a></li>
\t\t\t\t<li><a href=\"#\"><i class=\"fa fa-facebook\"></i></a></li>
\t\t\t\t<li><a href=\"#\"><i class=\"fa fa-google-plus\"></i></a></li>
\t\t\t\t<li><a href=\"#\"><i class=\"fa fa-linkedin\"></i></a></li>
\t\t\t</ul>
\t\t</div>

\t\t<a href=\"javascript:void(0);\" class=\"sliding-panel__close\">Close</a>
\t</div>
\t<!-- End Sliding Panel -->


\t<!-- JS Global Compulsory -->
\t<script src=\"";
        // line 157
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/jquery/jquery.min.js"), "html", null, true);
        echo "\"></script>
\t<script src=\"";
        // line 158
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/jquery/jquery-migrate.min.js"), "html", null, true);
        echo "\"></script>
\t<script src=\"";
        // line 159
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/bootstrap/js/bootstrap.min.js"), "html", null, true);
        echo "\"></script>
\t<!-- JS Implementing Plugins -->
\t<script src=\"";
        // line 161
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/back-to-top.js"), "html", null, true);
        echo "\"></script>
\t<script src=\"";
        // line 162
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/smoothScroll.js"), "html", null, true);
        echo "\"></script>
\t<script src=\"";
        // line 163
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/jquery.parallax.js"), "html", null, true);
        echo "\"></script>
\t<script src=\"";
        // line 164
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/counter/waypoints.min.js"), "html", null, true);
        echo "\"></script>
\t<script src=\"";
        // line 165
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/counter/jquery.counterup.min.js"), "html", null, true);
        echo "\"></script>
\t<script src=\"";
        // line 166
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/skrollr/skrollr-ini.js"), "html", null, true);
        echo "\"></script>
\t<script src=\"";
        // line 167
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/wow-animations/js/wow.min.js"), "html", null, true);
        echo "\"></script>
\t<script src=\"";
        // line 168
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/backstretch/backstretch-ini.js"), "html", null, true);
        echo "\"></script>
\t<script src=\"";
        // line 169
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/sliding-panel/jquery.sliding-panel.js"), "html", null, true);
        echo "\"></script>
\t<script src=\"";
        // line 170
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/owl-carousel/owl-carousel/owl.carousel.js"), "html", null, true);
        echo "\"></script>
\t<script src=\"";
        // line 171
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/cube-portfolio/cubeportfolio/js/jquery.cubeportfolio.min.js"), "html", null, true);
        echo "\"></script>
\t<!-- JS Page Level -->
\t<script src=\"";
        // line 173
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/js/app.js"), "html", null, true);
        echo "\"></script>
\t<script src=\"";
        // line 174
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/js/plugins/style-switcher.js"), "html", null, true);
        echo "\"></script>
\t<script src=\"";
        // line 175
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/js/plugins/owl-carousel.js"), "html", null, true);
        echo "\"></script>
\t<script src=\"";
        // line 176
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/js/plugins/cube-portfolio/masonry-v1.js"), "html", null, true);
        echo "\"></script>
\t<!-- JS Customization -->
\t<script src=\"";
        // line 178
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/js/custom.js"), "html", null, true);
        echo "\"></script>
\t<!-- JS Initialization -->
\t<script type=\"text/javascript\">
\t\tjQuery(document).ready(function() {
\t\t\tApp.init();
\t\t\tApp.initCounter();
\t\t\tApp.initParallaxBg();
\t\t\tOwlCarousel.initOwlCarousel();
\t\t\tStyleSwitcher.initStyleSwitcher();
\t\t\tnew WOW().init();
\t\t\t\$('#cbp-lightbox').cubeportfolio({}); // For popup video on the promo block
\t\t});
\t</script>
\t<!--[if lt IE 9]>
\t\t<script src=\"assets/plugins/respond.js\"></script>
\t\t<script src=\"assets/plugins/html5shiv.js\"></script>
\t\t<script src=\"assets/plugins/placeholder-IE-fixes.js\"></script>
\t<![endif]-->
</body>
</html>
";
        
        $__internal_f1bdb2ad55f0d5c25fcfa66f21142bbb78467305e9e69abf4d515199645d66eb->leave($__internal_f1bdb2ad55f0d5c25fcfa66f21142bbb78467305e9e69abf4d515199645d66eb_prof);

        
        $__internal_4e78069554f4a97fd9283c41ad726dee9d0cfae7d1b2af057d6e4c18a12a961e->leave($__internal_4e78069554f4a97fd9283c41ad726dee9d0cfae7d1b2af057d6e4c18a12a961e_prof);

    }

    public function getTemplateName()
    {
        return ":default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  303 => 178,  298 => 176,  294 => 175,  290 => 174,  286 => 173,  281 => 171,  277 => 170,  273 => 169,  269 => 168,  265 => 167,  261 => 166,  257 => 165,  253 => 164,  249 => 163,  245 => 162,  241 => 161,  236 => 159,  232 => 158,  228 => 157,  174 => 106,  170 => 105,  103 => 41,  97 => 38,  93 => 37,  87 => 34,  83 => 33,  79 => 32,  75 => 31,  71 => 30,  67 => 29,  61 => 26,  57 => 25,  51 => 22,  47 => 21,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<!--[if IE 8]> <html lang=\"en\" class=\"ie8\"> <![endif]-->
<!--[if IE 9]> <html lang=\"en\" class=\"ie9\"> <![endif]-->
<!--[if !IE]><!--> <html lang=\"en\"> <!--<![endif]-->
<head>
\t<title>Applicatoin gestion de prospection</title>

\t<!-- Meta -->
\t<meta charset=\"utf-8\">
\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
\t<meta name=\"description\" content=\"\">
\t<meta name=\"author\" content=\"\">

\t<!-- Favicon -->
\t<link rel=\"shortcut icon\" href=\"favicon.ico\">

\t<!-- Web Fonts -->
\t<link rel=\"stylesheet\" href=\"//fonts.googleapis.com/css?family=Open+Sans:400,300,600&amp;subset=cyrillic,latin\">

\t<!-- CSS Global Compulsory -->
\t<link rel=\"stylesheet\" href=\"{{ asset ('assets/plugins/bootstrap/css/bootstrap.min.css')}}\">
\t<link rel=\"stylesheet\" href=\"{{ asset('assets/css/style.css') }}\">

\t<!-- CSS Header and Footer -->
\t<link rel=\"stylesheet\" href=\"{{ asset('assets/css/headers/header-v6.css') }}\">
\t<link rel=\"stylesheet\" href=\"{{ asset('assets/css/footers/footer-v6.css') }}\">

\t<!-- CSS Implementing Plugins -->
\t<link rel=\"stylesheet\" href=\"{{ asset('assets/plugins/animate.css') }}\">
\t<link rel=\"stylesheet\" href=\"{{ asset('assets/plugins/line-icons/line-icons.css') }}\">
\t<link rel=\"stylesheet\" href=\"{{ asset('assets/plugins/font-awesome/css/font-awesome.min.css') }}\">
\t<link rel=\"stylesheet\" href=\"{{ asset('assets/plugins/sliding-panel/style.css') }}\">
\t<link rel=\"stylesheet\" href=\"{{ asset('assets/plugins/owl-carousel/owl-carousel/owl.carousel.css') }}\">
\t<link rel=\"stylesheet\" href=\"{{ asset('assets/plugins/cube-portfolio/cubeportfolio/css/cubeportfolio.min.css') }}\">

\t<!-- CSS Theme -->
\t<link rel=\"stylesheet\" href=\"{{ asset('assets/css/theme-colors/default.css') }}\" id=\"style_color\">
\t<link rel=\"stylesheet\" href=\"{{ asset('assets/css/theme-skins/dark.css') }}\">

\t<!-- CSS Customization -->
\t<link rel=\"stylesheet\" href=\"{{ asset('assets/css/custom.css') }}\">
</head>

<body class=\"header-fixed header-fixed-space promo-padding-top sliding-panel-ini sliding-panel-flag-right\">
\t<div class=\"wrapper\">
\t\t<!--=== Header v6 ===-->
\t\t<div class=\"header-v6 header-classic-white header-sticky\">
\t\t\t<!-- Navbar -->
\t\t\t<div class=\"navbar mega-menu\" role=\"navigation\">
\t\t\t\t<div class=\"container\">
\t\t\t\t\t<!-- Brand and toggle get grouped for better mobile display -->
\t\t\t\t\t<div class=\"menu-container\">
\t\t\t\t\t\t<button type=\"button\" class=\"navbar-toggle sliding-panel__btn sliding-panel__btn--dark\">
\t\t\t\t\t\t\t<span class=\"sr-only\">Toggle navigation</span>
\t\t\t\t\t\t\t<span class=\"icon-bar\"></span>
\t\t\t\t\t\t\t<span class=\"icon-bar\"></span>
\t\t\t\t\t\t\t<span class=\"icon-bar\"></span>
\t\t\t\t\t\t</button>

\t\t\t\t\t\t<!-- Navbar Brand -->
\t\t\t\t\t\t<div class=\"navbar-brand\">
\t\t\t\t\t\t\t<a href=\"index.html\">
\t\t\t\t\t\t\t<h1>PROSPEC</h1>
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<!-- ENd Navbar Brand -->

\t\t\t\t\t\t<!-- Header Inner Right -->
\t\t\t\t\t\t<div class=\"header-inner-right\">
\t\t\t\t\t\t\t<ul class=\"menu-icons-list\">

\t\t\t\t\t\t\t\t<li class=\"menu-icons\">
\t\t\t\t\t\t\t\t\t<i class=\"menu-icons-style search search-close search-btn fa fa-search\"></i>
\t\t\t\t\t\t\t\t\t<div class=\"search-open\">
\t\t\t\t\t\t\t\t\t\t<input type=\"text\" class=\"animated fadeIn form-control\" placeholder=\"Rechercher ...\">
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<!-- End Header Inner Right -->
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<!-- End Navbar -->
\t\t</div>
\t\t<!--=== End Header v6 ===-->

\t\t<!-- Promo Block -->
\t\t<div class=\"promo-bg-pattern-v1-dark promo-bg-fixed content-xlg parallaxBg\">
\t\t\t<div class=\"container text-center\" data-start=\"opacity: 1;\" data-320=\"opacity: 0;\">
\t\t\t\t<div class=\"margin-bottom-20\">
\t\t\t\t\t<a class=\"promo-video-icon-wrap color-light rounded-x animated fadeInUp wow cbp-lightbox\" data-wow-duration=\"2s\" data-wow-delay=\".5s\" data-title=\"Video Presentation\" href=\"https://player.vimeo.com/video/58363288?&rel=0&autoplay=1\">
\t\t\t\t\t\t<i class=\"promo-video-icon icon-control-play\"></i>
\t\t\t\t\t</a>
\t\t\t\t\t<div id=\"cbp-lightbox\" class=\"dp-none\"></div>
\t\t\t\t</div>

\t\t\t\t<span class=\"promo-text-v1 color-light margin-bottom-10 animated fadeInUp wow\" data-wow-duration=\"1.5s\" data-wow-delay=\"1s\">
\t\t\t\t\tApplication Prospec
\t\t\t\t</span>

\t\t\t\t<h2 class=\"promo-text-v2 color-light animated fadeInUp wow margin-bottom-20\" data-wow-duration=\"1.5s\" data-wow-delay=\"1.5s\">Gestion des prospections</h2>

\t\t\t\t<div class=\"animated fadeInUp wow\" data-wow-duration=\"1.2s\" data-wow-delay=\"2s\">
\t\t\t\t\t<a href=\"{{ path('app_user_user_signup') }}\" class=\"btn-u btn-brd btn-brd-width-2 btn-brd-hover btn-u-light btn-u-block rounded-4x margin-right-10\">Inscription</a>
\t\t\t\t\t<a href=\"{{ path('login') }}\" class=\"btn-u btn-brd btn-brd-width-2 btn-brd-hover btn-u-light btn-u-block rounded-4x margin-right-10\">Connexion</a>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t\t<!-- End Promo Block -->








\t</div><!--/wrapper-->

\t<!-- Sliding Panel -->
\t<div class=\"sliding-panel bg-color-darker\">
\t\t<div class=\"sliding-panel-inner sliding-panel-scrollable fullscreen\">
\t\t\t<ul class=\"sliding-navigation\">
\t\t\t\t<li><a href=\"index.html\">Home</a></li>
\t\t\t\t<li><a href=\"page_about3.html\">Abour Us</a></li>
\t\t\t\t<li><a href=\"page_services.html\">Services</a></li>
\t\t\t\t<li><a href=\"page_profile.html\">Profile</a></li>
\t\t\t\t<li><a href=\"blog_large_right_sidebar1.html\">Blog</a></li>
\t\t\t\t<li><a href=\"portfolio_3_columns_grid_text.html\">Our Work</a></li>
\t\t\t\t<li><a href=\"page_contact1.html\">Contact Us</a></li>
\t\t\t</ul>

\t\t\t<h4>Contacts</h4>
\t\t\t<address>
\t\t\t\t58, Lorem Lis Street, Central Ave<br>
\t\t\t\tNew York, US<br><br>
\t\t\t\tPhone: 938 334 6049<br>
\t\t\t\tFax: 938 334 6050<br><br>
\t\t\t\tEmail: <a href=\"mailto:#\">info@htmlstream.com</a><br>
\t\t\t</address>

\t\t\t<ul class=\"list-inline social-icons-v1 social-icons-v1--dark\">
\t\t\t\t<li><a href=\"#\"><i class=\"fa fa-twitter\"></i></a></li>
\t\t\t\t<li><a href=\"#\"><i class=\"fa fa-facebook\"></i></a></li>
\t\t\t\t<li><a href=\"#\"><i class=\"fa fa-google-plus\"></i></a></li>
\t\t\t\t<li><a href=\"#\"><i class=\"fa fa-linkedin\"></i></a></li>
\t\t\t</ul>
\t\t</div>

\t\t<a href=\"javascript:void(0);\" class=\"sliding-panel__close\">Close</a>
\t</div>
\t<!-- End Sliding Panel -->


\t<!-- JS Global Compulsory -->
\t<script src=\"{{ asset('assets/plugins/jquery/jquery.min.js') }}\"></script>
\t<script src=\"{{ asset('assets/plugins/jquery/jquery-migrate.min.js') }}\"></script>
\t<script src=\"{{ asset('assets/plugins/bootstrap/js/bootstrap.min.js') }}\"></script>
\t<!-- JS Implementing Plugins -->
\t<script src=\"{{ asset('assets/plugins/back-to-top.js') }}\"></script>
\t<script src=\"{{ asset('assets/plugins/smoothScroll.js') }}\"></script>
\t<script src=\"{{ asset('assets/plugins/jquery.parallax.js') }}\"></script>
\t<script src=\"{{ asset('assets/plugins/counter/waypoints.min.js') }}\"></script>
\t<script src=\"{{ asset('assets/plugins/counter/jquery.counterup.min.js') }}\"></script>
\t<script src=\"{{ asset('assets/plugins/skrollr/skrollr-ini.js') }}\"></script>
\t<script src=\"{{ asset('assets/plugins/wow-animations/js/wow.min.js') }}\"></script>
\t<script src=\"{{ asset('assets/plugins/backstretch/backstretch-ini.js') }}\"></script>
\t<script src=\"{{ asset('assets/plugins/sliding-panel/jquery.sliding-panel.js') }}\"></script>
\t<script src=\"{{ asset('assets/plugins/owl-carousel/owl-carousel/owl.carousel.js') }}\"></script>
\t<script src=\"{{ asset('assets/plugins/cube-portfolio/cubeportfolio/js/jquery.cubeportfolio.min.js') }}\"></script>
\t<!-- JS Page Level -->
\t<script src=\"{{ asset('assets/js/app.js') }}\"></script>
\t<script src=\"{{ asset('assets/js/plugins/style-switcher.js') }}\"></script>
\t<script src=\"{{ asset('assets/js/plugins/owl-carousel.js') }}\"></script>
\t<script src=\"{{ asset('assets/js/plugins/cube-portfolio/masonry-v1.js') }}\"></script>
\t<!-- JS Customization -->
\t<script src=\"{{ asset('assets/js/custom.js') }}\"></script>
\t<!-- JS Initialization -->
\t<script type=\"text/javascript\">
\t\tjQuery(document).ready(function() {
\t\t\tApp.init();
\t\t\tApp.initCounter();
\t\t\tApp.initParallaxBg();
\t\t\tOwlCarousel.initOwlCarousel();
\t\t\tStyleSwitcher.initStyleSwitcher();
\t\t\tnew WOW().init();
\t\t\t\$('#cbp-lightbox').cubeportfolio({}); // For popup video on the promo block
\t\t});
\t</script>
\t<!--[if lt IE 9]>
\t\t<script src=\"assets/plugins/respond.js\"></script>
\t\t<script src=\"assets/plugins/html5shiv.js\"></script>
\t\t<script src=\"assets/plugins/placeholder-IE-fixes.js\"></script>
\t<![endif]-->
</body>
</html>
", ":default:index.html.twig", "C:\\wamp64\\www\\appli-era\\app/Resources\\views/default/index.html.twig");
    }
}
