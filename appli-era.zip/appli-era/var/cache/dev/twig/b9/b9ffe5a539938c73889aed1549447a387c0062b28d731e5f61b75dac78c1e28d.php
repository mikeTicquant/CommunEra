<?php

/* @WebProfiler/Profiler/open.html.twig */
class __TwigTemplate_bd10c2abe5b5e1b13993b0591b40fba4991f810e60d1e52175abd1e7d94b5f06 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/base.html.twig", "@WebProfiler/Profiler/open.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4bdcc39bcdd8909b682a7cd8cceafa05e3457cfeb30d3224a9377dbb7197e4cc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4bdcc39bcdd8909b682a7cd8cceafa05e3457cfeb30d3224a9377dbb7197e4cc->enter($__internal_4bdcc39bcdd8909b682a7cd8cceafa05e3457cfeb30d3224a9377dbb7197e4cc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/open.html.twig"));

        $__internal_710b1f4ee5f9adb821c3eddb04378ecd338ede2414abc40b789efbbe9cf8b1fd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_710b1f4ee5f9adb821c3eddb04378ecd338ede2414abc40b789efbbe9cf8b1fd->enter($__internal_710b1f4ee5f9adb821c3eddb04378ecd338ede2414abc40b789efbbe9cf8b1fd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/open.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4bdcc39bcdd8909b682a7cd8cceafa05e3457cfeb30d3224a9377dbb7197e4cc->leave($__internal_4bdcc39bcdd8909b682a7cd8cceafa05e3457cfeb30d3224a9377dbb7197e4cc_prof);

        
        $__internal_710b1f4ee5f9adb821c3eddb04378ecd338ede2414abc40b789efbbe9cf8b1fd->leave($__internal_710b1f4ee5f9adb821c3eddb04378ecd338ede2414abc40b789efbbe9cf8b1fd_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_fd2244ba79ccf0247a9c3328cbee2e2b16e005f221b5f3d7945babc0d8c2199c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fd2244ba79ccf0247a9c3328cbee2e2b16e005f221b5f3d7945babc0d8c2199c->enter($__internal_fd2244ba79ccf0247a9c3328cbee2e2b16e005f221b5f3d7945babc0d8c2199c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_5b598a432fe401eeb7293b70cf60631cf12b01d2c65f4e7a2c1359a068fe9bb8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5b598a432fe401eeb7293b70cf60631cf12b01d2c65f4e7a2c1359a068fe9bb8->enter($__internal_5b598a432fe401eeb7293b70cf60631cf12b01d2c65f4e7a2c1359a068fe9bb8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <style>
        ";
        // line 5
        echo twig_include($this->env, $context, "@WebProfiler/Profiler/open.css.twig");
        echo "
    </style>
";
        
        $__internal_5b598a432fe401eeb7293b70cf60631cf12b01d2c65f4e7a2c1359a068fe9bb8->leave($__internal_5b598a432fe401eeb7293b70cf60631cf12b01d2c65f4e7a2c1359a068fe9bb8_prof);

        
        $__internal_fd2244ba79ccf0247a9c3328cbee2e2b16e005f221b5f3d7945babc0d8c2199c->leave($__internal_fd2244ba79ccf0247a9c3328cbee2e2b16e005f221b5f3d7945babc0d8c2199c_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_18c62fb8172aba76f2781d443dc899c2fbe9dd85291837560f9101edf7007b91 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_18c62fb8172aba76f2781d443dc899c2fbe9dd85291837560f9101edf7007b91->enter($__internal_18c62fb8172aba76f2781d443dc899c2fbe9dd85291837560f9101edf7007b91_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_e1cbb79686acfea7adc0cba1ce84236667f9f4a64a5480ac36e64dadf5ead6ff = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e1cbb79686acfea7adc0cba1ce84236667f9f4a64a5480ac36e64dadf5ead6ff->enter($__internal_e1cbb79686acfea7adc0cba1ce84236667f9f4a64a5480ac36e64dadf5ead6ff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "<div class=\"header\">
    <h1>";
        // line 11
        echo twig_escape_filter($this->env, ($context["file"] ?? $this->getContext($context, "file")), "html", null, true);
        echo " <small>line ";
        echo twig_escape_filter($this->env, ($context["line"] ?? $this->getContext($context, "line")), "html", null, true);
        echo "</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/";
        // line 12
        echo twig_escape_filter($this->env, twig_constant("Symfony\\Component\\HttpKernel\\Kernel::VERSION"), "html", null, true);
        echo "/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    ";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\CodeExtension')->fileExcerpt(($context["filename"] ?? $this->getContext($context, "filename")), ($context["line"] ?? $this->getContext($context, "line")),  -1);
        echo "
</div>
";
        
        $__internal_e1cbb79686acfea7adc0cba1ce84236667f9f4a64a5480ac36e64dadf5ead6ff->leave($__internal_e1cbb79686acfea7adc0cba1ce84236667f9f4a64a5480ac36e64dadf5ead6ff_prof);

        
        $__internal_18c62fb8172aba76f2781d443dc899c2fbe9dd85291837560f9101edf7007b91->leave($__internal_18c62fb8172aba76f2781d443dc899c2fbe9dd85291837560f9101edf7007b91_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/open.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 15,  84 => 12,  78 => 11,  75 => 10,  66 => 9,  53 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/base.html.twig' %}

{% block head %}
    <style>
        {{ include('@WebProfiler/Profiler/open.css.twig') }}
    </style>
{% endblock %}

{% block body %}
<div class=\"header\">
    <h1>{{ file }} <small>line {{ line }}</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/{{ constant('Symfony\\\\Component\\\\HttpKernel\\\\Kernel::VERSION') }}/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    {{ filename|file_excerpt(line, -1) }}
</div>
{% endblock %}
", "@WebProfiler/Profiler/open.html.twig", "C:\\wamp64\\www\\appli-era\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\open.html.twig");
    }
}
