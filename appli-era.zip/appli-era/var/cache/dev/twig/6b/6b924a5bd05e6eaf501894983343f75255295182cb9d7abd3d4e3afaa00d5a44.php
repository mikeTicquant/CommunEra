<?php

/* :agence:index.html.twig */
class __TwigTemplate_8d54fee3ea904d179b9e3fa2af2534d1ba3b77b56d186d3a5cf3214d7f9c4192 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":agence:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a390ff9f94bdf0895da564f277d12252f58df65b0df2bdeebdbeee8e5632ffc1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a390ff9f94bdf0895da564f277d12252f58df65b0df2bdeebdbeee8e5632ffc1->enter($__internal_a390ff9f94bdf0895da564f277d12252f58df65b0df2bdeebdbeee8e5632ffc1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":agence:index.html.twig"));

        $__internal_c252597ae2eca0937864de25384b2b81520db1e41950742ac309c8ff907d64c2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c252597ae2eca0937864de25384b2b81520db1e41950742ac309c8ff907d64c2->enter($__internal_c252597ae2eca0937864de25384b2b81520db1e41950742ac309c8ff907d64c2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":agence:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a390ff9f94bdf0895da564f277d12252f58df65b0df2bdeebdbeee8e5632ffc1->leave($__internal_a390ff9f94bdf0895da564f277d12252f58df65b0df2bdeebdbeee8e5632ffc1_prof);

        
        $__internal_c252597ae2eca0937864de25384b2b81520db1e41950742ac309c8ff907d64c2->leave($__internal_c252597ae2eca0937864de25384b2b81520db1e41950742ac309c8ff907d64c2_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_e2ad7041b958eac937fa5949afa3c3f9a7f4a0b65744ae143c333268067dd80b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e2ad7041b958eac937fa5949afa3c3f9a7f4a0b65744ae143c333268067dd80b->enter($__internal_e2ad7041b958eac937fa5949afa3c3f9a7f4a0b65744ae143c333268067dd80b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_1f8f664ab452aba80673f5731b033f5bca92a956a0da11d131008065e78fa139 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1f8f664ab452aba80673f5731b033f5bca92a956a0da11d131008065e78fa139->enter($__internal_1f8f664ab452aba80673f5731b033f5bca92a956a0da11d131008065e78fa139_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    <h1>Espace Agence</h1>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
";
        
        $__internal_1f8f664ab452aba80673f5731b033f5bca92a956a0da11d131008065e78fa139->leave($__internal_1f8f664ab452aba80673f5731b033f5bca92a956a0da11d131008065e78fa139_prof);

        
        $__internal_e2ad7041b958eac937fa5949afa3c3f9a7f4a0b65744ae143c333268067dd80b->leave($__internal_e2ad7041b958eac937fa5949afa3c3f9a7f4a0b65744ae143c333268067dd80b_prof);

    }

    public function getTemplateName()
    {
        return ":agence:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 3,  40 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block body %}
    <h1>Espace Agence</h1>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
{% endblock %}", ":agence:index.html.twig", "C:\\wamp64\\www\\appli-era\\app/Resources\\views/agence/index.html.twig");
    }
}
