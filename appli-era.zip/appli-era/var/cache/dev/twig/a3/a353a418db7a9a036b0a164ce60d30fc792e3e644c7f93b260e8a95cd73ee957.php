<?php

/* @Framework/Form/attributes.html.php */
class __TwigTemplate_dac9ff7ddf7198b493c34af17936e9afbb8864a3abc7b78b7530e7bb051c0f28 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ff26f6742966fd744704452e5eb62294fe760714202432327dc52bad51b6d613 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ff26f6742966fd744704452e5eb62294fe760714202432327dc52bad51b6d613->enter($__internal_ff26f6742966fd744704452e5eb62294fe760714202432327dc52bad51b6d613_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/attributes.html.php"));

        $__internal_6eea99ed3949e8eab112a08bfd7dfffdbaaa42c6eae278ab46c092e20c3443bf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6eea99ed3949e8eab112a08bfd7dfffdbaaa42c6eae278ab46c092e20c3443bf->enter($__internal_6eea99ed3949e8eab112a08bfd7dfffdbaaa42c6eae278ab46c092e20c3443bf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
";
        
        $__internal_ff26f6742966fd744704452e5eb62294fe760714202432327dc52bad51b6d613->leave($__internal_ff26f6742966fd744704452e5eb62294fe760714202432327dc52bad51b6d613_prof);

        
        $__internal_6eea99ed3949e8eab112a08bfd7dfffdbaaa42c6eae278ab46c092e20c3443bf->leave($__internal_6eea99ed3949e8eab112a08bfd7dfffdbaaa42c6eae278ab46c092e20c3443bf_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
", "@Framework/Form/attributes.html.php", "C:\\wamp64\\www\\appli-era\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\attributes.html.php");
    }
}
