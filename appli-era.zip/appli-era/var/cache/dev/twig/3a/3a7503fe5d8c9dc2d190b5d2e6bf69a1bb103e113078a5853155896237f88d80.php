<?php

/* :user/reseau:addreseau.html.twig */
class __TwigTemplate_588d05036cc8cdc0d55286bd430a4efd18098ee430881da45482ae520f1e97b1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("base.html.twig", ":user/reseau:addreseau.html.twig", 3);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5dc6d9fea11ee322684e1259fb94a7b4604d7079a1b95b0bbb4700cc4ceee226 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5dc6d9fea11ee322684e1259fb94a7b4604d7079a1b95b0bbb4700cc4ceee226->enter($__internal_5dc6d9fea11ee322684e1259fb94a7b4604d7079a1b95b0bbb4700cc4ceee226_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":user/reseau:addreseau.html.twig"));

        $__internal_7f8b5f6c3ba156f7c46289b1670e9e6160c05f545d406762839734fe649a332f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7f8b5f6c3ba156f7c46289b1670e9e6160c05f545d406762839734fe649a332f->enter($__internal_7f8b5f6c3ba156f7c46289b1670e9e6160c05f545d406762839734fe649a332f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":user/reseau:addreseau.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5dc6d9fea11ee322684e1259fb94a7b4604d7079a1b95b0bbb4700cc4ceee226->leave($__internal_5dc6d9fea11ee322684e1259fb94a7b4604d7079a1b95b0bbb4700cc4ceee226_prof);

        
        $__internal_7f8b5f6c3ba156f7c46289b1670e9e6160c05f545d406762839734fe649a332f->leave($__internal_7f8b5f6c3ba156f7c46289b1670e9e6160c05f545d406762839734fe649a332f_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_110873773085b618b6ab7d9217a1fa3bfa4dd107e4a83612ef0a4dbd3103bc57 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_110873773085b618b6ab7d9217a1fa3bfa4dd107e4a83612ef0a4dbd3103bc57->enter($__internal_110873773085b618b6ab7d9217a1fa3bfa4dd107e4a83612ef0a4dbd3103bc57_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_e37106f286bea952e552a4acf2242891c014aa8e2989411ea1c5febb7cb79928 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e37106f286bea952e552a4acf2242891c014aa8e2989411ea1c5febb7cb79928->enter($__internal_e37106f286bea952e552a4acf2242891c014aa8e2989411ea1c5febb7cb79928_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "

    <div class=\"container content profile\">
        <div class=\"row\">
            <!--Left Sidebar-->
            <div class=\"col-md-3 md-margin-bottom-40\">

                ";
        // line 12
        $context["filename"] = (($this->getAttribute($this->getAttribute(($context["app"] ?? null), "user", array(), "any", false, true), "photo", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute($this->getAttribute(($context["app"] ?? null), "user", array(), "any", false, true), "photo", array()), "img32-md.jpg")) : ("img32-md.jpg"));
        // line 13
        echo "                ";
        $context["url"] = ((($context["globalUserPhotoUri"] ?? $this->getContext($context, "globalUserPhotoUri")) . "/") . ($context["filename"] ?? $this->getContext($context, "filename")));
        // line 14
        echo "                <img class=\"img-thumbnail\" id=\"photo\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl(($context["url"] ?? $this->getContext($context, "url"))), "html", null, true);
        echo "\"/>
                <br><br>
                <ul class=\"list-group sidebar-nav-v1 margin-bottom-40\" id=\"sidebar-nav-1\">
                    <li class=\"list-group-item active\">
                        <a href=\"#\"><i class=\"fa fa-bar-chart-o\"></i> Tableau de bord</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"";
        // line 21
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_profil");
        echo "\"><i class=\"fa fa-user\"></i> Profil</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"";
        // line 24
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_addreseau");
        echo "\"><i class=\"fa fa-group\"></i> Code d'affiliation</a>
                    </li>
        <!--            <li class=\"list-group-item\">
                        <a href=\"";
        // line 27
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_addreseau");
        echo "\"><i class=\"fa fa-group\"></i> Reseau</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"";
        // line 30
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_addcda");
        echo "\"><i class=\"fa fa-group\"></i> Cda</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"";
        // line 33
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_addgagence");
        echo "\"><i class=\"fa fa-group\"></i> Groupe Agence</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"";
        // line 36
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_addreseau");
        echo "\"><i class=\"fa fa-group\"></i> Agence</a>
                    </li>

                    <li class=\"list-group-item\">
                        <a href=\"#\"><i class=\"fa fa-cog\"></i> Settings</a>
                    </li>

                    -->
                </ul>

            </div>
            <!--End Left Sidebar-->

            <!-- Profile Content -->
            <div class=\"col-md-9\">
                <div class=\"profile-body margin-bottom-20\">

                    <h2 class=\"heading-md\">Code d'affiliation</h2>
                    <br>
<!--
                        <dl class=\"dl-horizontal\">
                            <dt></dt>
                            <dd>
                                ";
        // line 59
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start', array("attr" => array("novalidate" => "novalidate")));
        echo "
                                <section>

                                    <label class=\"input\">

                                        ";
        // line 64
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        echo "

                                    </label>
                                </section>
                                <section>
                                    <br>
                                    <button class=\"btn-u\" type=\"submit\">Ajouter le code d'affiliation</button>
                                    <button type=\"button\" class=\"btn-u btn-u-default\">Annuler</button>
                                    ";
        // line 72
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        echo "
                                </section>
                            </dd>

                        </dl>
-->

                    <p>Vous etes ?</p>


                    <select>
                        <option value=\"1\" >Président du cda</option>
                        <option value=\"2\" >Responsable groupe d'agence</option>
                        <option value=\"3\" >Directeur d'agence</option>
                    </select>

                </div>

            </div>
        </div>
        <!-- End Profile Content -->
    </div><!--/end row-->


";
        
        $__internal_e37106f286bea952e552a4acf2242891c014aa8e2989411ea1c5febb7cb79928->leave($__internal_e37106f286bea952e552a4acf2242891c014aa8e2989411ea1c5febb7cb79928_prof);

        
        $__internal_110873773085b618b6ab7d9217a1fa3bfa4dd107e4a83612ef0a4dbd3103bc57->leave($__internal_110873773085b618b6ab7d9217a1fa3bfa4dd107e4a83612ef0a4dbd3103bc57_prof);

    }

    public function getTemplateName()
    {
        return ":user/reseau:addreseau.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  149 => 72,  138 => 64,  130 => 59,  104 => 36,  98 => 33,  92 => 30,  86 => 27,  80 => 24,  74 => 21,  63 => 14,  60 => 13,  58 => 12,  49 => 5,  40 => 4,  11 => 3,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("

{% extends 'base.html.twig' %}
{% block body %}


    <div class=\"container content profile\">
        <div class=\"row\">
            <!--Left Sidebar-->
            <div class=\"col-md-3 md-margin-bottom-40\">

                {% set filename = app.user.photo|default('img32-md.jpg') %}
                {% set url = globalUserPhotoUri ~ '/' ~ filename %}
                <img class=\"img-thumbnail\" id=\"photo\" src=\"{{ asset(url) }}\"/>
                <br><br>
                <ul class=\"list-group sidebar-nav-v1 margin-bottom-40\" id=\"sidebar-nav-1\">
                    <li class=\"list-group-item active\">
                        <a href=\"#\"><i class=\"fa fa-bar-chart-o\"></i> Tableau de bord</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"{{ path('app_user_user_profil') }}\"><i class=\"fa fa-user\"></i> Profil</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"{{ path('app_user_user_addreseau') }}\"><i class=\"fa fa-group\"></i> Code d'affiliation</a>
                    </li>
        <!--            <li class=\"list-group-item\">
                        <a href=\"{{ path('app_user_user_addreseau') }}\"><i class=\"fa fa-group\"></i> Reseau</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"{{ path('app_user_user_addcda') }}\"><i class=\"fa fa-group\"></i> Cda</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"{{ path('app_user_user_addgagence') }}\"><i class=\"fa fa-group\"></i> Groupe Agence</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"{{ path('app_user_user_addreseau') }}\"><i class=\"fa fa-group\"></i> Agence</a>
                    </li>

                    <li class=\"list-group-item\">
                        <a href=\"#\"><i class=\"fa fa-cog\"></i> Settings</a>
                    </li>

                    -->
                </ul>

            </div>
            <!--End Left Sidebar-->

            <!-- Profile Content -->
            <div class=\"col-md-9\">
                <div class=\"profile-body margin-bottom-20\">

                    <h2 class=\"heading-md\">Code d'affiliation</h2>
                    <br>
<!--
                        <dl class=\"dl-horizontal\">
                            <dt></dt>
                            <dd>
                                {{ form_start(form,{attr:{novalidate:'novalidate'}}) }}
                                <section>

                                    <label class=\"input\">

                                        {{ form_widget(form) }}

                                    </label>
                                </section>
                                <section>
                                    <br>
                                    <button class=\"btn-u\" type=\"submit\">Ajouter le code d'affiliation</button>
                                    <button type=\"button\" class=\"btn-u btn-u-default\">Annuler</button>
                                    {{ form_end(form) }}
                                </section>
                            </dd>

                        </dl>
-->

                    <p>Vous etes ?</p>


                    <select>
                        <option value=\"1\" >Président du cda</option>
                        <option value=\"2\" >Responsable groupe d'agence</option>
                        <option value=\"3\" >Directeur d'agence</option>
                    </select>

                </div>

            </div>
        </div>
        <!-- End Profile Content -->
    </div><!--/end row-->


{% endblock %}", ":user/reseau:addreseau.html.twig", "C:\\wamp64\\www\\appli-era\\app/Resources\\views/user/reseau/addreseau.html.twig");
    }
}
