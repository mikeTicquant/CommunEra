<?php

/* base.html.twig */
class __TwigTemplate_76ecb4b6eab5e517c7c918daf5462c70d04063a7d433480cdc8b6304e972c54f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'stylesheet' => array($this, 'block_stylesheet'),
            'navbar' => array($this, 'block_navbar'),
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
            'javascript' => array($this, 'block_javascript'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ff43e6b463f264f85717312ea2786a93fdc632b5c3382b2d7a9453c400f05fc6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ff43e6b463f264f85717312ea2786a93fdc632b5c3382b2d7a9453c400f05fc6->enter($__internal_ff43e6b463f264f85717312ea2786a93fdc632b5c3382b2d7a9453c400f05fc6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_0f151ceaf468c98d84bed240819833e88ee6a710cb479d18171b7955272844da = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0f151ceaf468c98d84bed240819833e88ee6a710cb479d18171b7955272844da->enter($__internal_0f151ceaf468c98d84bed240819833e88ee6a710cb479d18171b7955272844da_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<!--[if IE 8]> <html lang=\"en\" class=\"ie8\"> <![endif]-->
<!--[if IE 9]> <html lang=\"en\" class=\"ie9\"> <![endif]-->
<!--[if !IE]><!--> <html lang=\"en\"> <!--<![endif]-->
<head>
\t<title>Gestion des prospections</title>

\t<!-- Meta -->
\t<meta charset=\"utf-8\">
\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
\t<meta name=\"description\" content=\"\">
\t<meta name=\"author\" content=\"\">

\t";
        // line 14
        $this->displayBlock('stylesheet', $context, $blocks);
        // line 50
        echo "</head>

<body class=\"\">
\t<div class=\"wrapper\">
\t\t";
        // line 54
        $this->displayBlock('navbar', $context, $blocks);
        // line 57
        echo "
\t\t<!--=== Content Part ===-->
\t\t<div class=\"container content margin-top-20\">
\t\t\t<div class=\"row\">

                    ";
        // line 62
        echo twig_include($this->env, $context, "_flash.html.twig");
        echo "
\t\t\t\t";
        // line 63
        $this->displayBlock('body', $context, $blocks);
        // line 66
        echo "\t\t\t</div>
\t\t</div><!--/container-->
\t\t<!--=== End Content Part ===-->

\t\t<!--=== Footer Version 1 ===-->
\t\t";
        // line 71
        $this->displayBlock('footer', $context, $blocks);
        // line 74
        echo "\t\t<!--=== End Footer Version 1 ===-->
\t</div>


";
        // line 78
        $this->displayBlock('javascript', $context, $blocks);
        // line 104
        echo "</body>
</html>
";
        
        $__internal_ff43e6b463f264f85717312ea2786a93fdc632b5c3382b2d7a9453c400f05fc6->leave($__internal_ff43e6b463f264f85717312ea2786a93fdc632b5c3382b2d7a9453c400f05fc6_prof);

        
        $__internal_0f151ceaf468c98d84bed240819833e88ee6a710cb479d18171b7955272844da->leave($__internal_0f151ceaf468c98d84bed240819833e88ee6a710cb479d18171b7955272844da_prof);

    }

    // line 14
    public function block_stylesheet($context, array $blocks = array())
    {
        $__internal_c11afbe78df7fa665d157a0094f32c5b0ff3d3c4dac5ce1b64cb4d8ef21cd075 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c11afbe78df7fa665d157a0094f32c5b0ff3d3c4dac5ce1b64cb4d8ef21cd075->enter($__internal_c11afbe78df7fa665d157a0094f32c5b0ff3d3c4dac5ce1b64cb4d8ef21cd075_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheet"));

        $__internal_f0f5a28affb0885423c5aa491600ed36bc30b1267453bf46bfe3dfb0b176fc33 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f0f5a28affb0885423c5aa491600ed36bc30b1267453bf46bfe3dfb0b176fc33->enter($__internal_f0f5a28affb0885423c5aa491600ed36bc30b1267453bf46bfe3dfb0b176fc33_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheet"));

        // line 15
        echo "\t\t<!-- Favicon -->
\t\t<link rel=\"shortcut icon\" href=\"favicon.ico\">

\t\t<!-- Web Fonts -->
\t\t<link rel='stylesheet' type='text/css' href='//fonts.googleapis.com/css?family=Open+Sans:400,300,600&amp;subset=cyrillic,latin'>

\t\t<!-- CSS Global Compulsory -->
\t\t<link rel=\"stylesheet\" href=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/bootstrap/css/bootstrap.min.css"), "html", null, true);
        echo "\">
\t\t<link rel=\"stylesheet\" href=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/style.css"), "html", null, true);
        echo "\">


\t\t<!-- CSS Header and Footer -->
\t\t<link rel=\"stylesheet\" href=\"";
        // line 27
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/headers/header-default.css"), "html", null, true);
        echo "\">
\t\t<link rel=\"stylesheet\" href=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/footers/footer-v1.css"), "html", null, true);
        echo "\">

\t\t<!-- CSS Implementing Plugins -->
\t\t<link rel=\"stylesheet\" href=\"";
        // line 31
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/animate.css"), "html", null, true);
        echo "\">
\t\t<link rel=\"stylesheet\" href=\"";
        // line 32
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/line-icons/line-icons.css"), "html", null, true);
        echo "\">
\t\t<link rel=\"stylesheet\" href=\"";
        // line 33
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/font-awesome/css/font-awesome.min.css"), "html", null, true);
        echo "\">
\t\t<link rel=\"stylesheet\" href=\"";
        // line 34
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/scrollbar/css/jquery.mCustomScrollbar.css"), "html", null, true);
        echo "\">
\t\t<link rel=\"stylesheet\" href=\"";
        // line 35
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/sky-forms-pro/skyforms/css/sky-forms.css"), "html", null, true);
        echo "\">
\t\t<link rel=\"stylesheet\" href=\"";
        // line 36
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/sky-forms-pro/skyforms/custom/custom-sky-forms.css"), "html", null, true);
        echo "\">

\t\t<!-- CSS Page Style -->
\t\t<link rel=\"stylesheet\" href=\"";
        // line 39
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/pages/page_log_reg_v1.css"), "html", null, true);
        echo "\">
\t\t<link rel=\"stylesheet\" href=\"";
        // line 40
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/pages/profile.css"), "html", null, true);
        echo "\">

\t\t<!-- CSS Theme -->
\t\t<link rel=\"stylesheet\" href=\"";
        // line 43
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/theme-colors/default.css"), "html", null, true);
        echo "\" id=\"style_color\">
\t\t<link rel=\"stylesheet\" href=\"";
        // line 44
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/theme-skins/dark.css"), "html", null, true);
        echo "\">
\t\t<link rel=\"stylesheet\" href=\"";
        // line 45
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/blocks.css"), "html", null, true);
        echo "\">

\t\t<!-- CSS Customization -->
\t\t<link rel=\"stylesheet\" href=\"";
        // line 48
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/custom.css"), "html", null, true);
        echo "\">
\t";
        
        $__internal_f0f5a28affb0885423c5aa491600ed36bc30b1267453bf46bfe3dfb0b176fc33->leave($__internal_f0f5a28affb0885423c5aa491600ed36bc30b1267453bf46bfe3dfb0b176fc33_prof);

        
        $__internal_c11afbe78df7fa665d157a0094f32c5b0ff3d3c4dac5ce1b64cb4d8ef21cd075->leave($__internal_c11afbe78df7fa665d157a0094f32c5b0ff3d3c4dac5ce1b64cb4d8ef21cd075_prof);

    }

    // line 54
    public function block_navbar($context, array $blocks = array())
    {
        $__internal_c75554e231a51105cc3eee050ee493cd24b4a04ce05b752a3d4ed8e7ab0321b1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c75554e231a51105cc3eee050ee493cd24b4a04ce05b752a3d4ed8e7ab0321b1->enter($__internal_c75554e231a51105cc3eee050ee493cd24b4a04ce05b752a3d4ed8e7ab0321b1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "navbar"));

        $__internal_8774a2ba7ec38875a8fb017cba6af51763762169946c3842da9f3bc99d2769f4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8774a2ba7ec38875a8fb017cba6af51763762169946c3842da9f3bc99d2769f4->enter($__internal_8774a2ba7ec38875a8fb017cba6af51763762169946c3842da9f3bc99d2769f4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "navbar"));

        // line 55
        echo "\t\t\t";
        $this->loadTemplate("_nav.html.twig", "base.html.twig", 55)->display($context);
        // line 56
        echo "\t\t";
        
        $__internal_8774a2ba7ec38875a8fb017cba6af51763762169946c3842da9f3bc99d2769f4->leave($__internal_8774a2ba7ec38875a8fb017cba6af51763762169946c3842da9f3bc99d2769f4_prof);

        
        $__internal_c75554e231a51105cc3eee050ee493cd24b4a04ce05b752a3d4ed8e7ab0321b1->leave($__internal_c75554e231a51105cc3eee050ee493cd24b4a04ce05b752a3d4ed8e7ab0321b1_prof);

    }

    // line 63
    public function block_body($context, array $blocks = array())
    {
        $__internal_fb5bc73c23e4144ddf1e38ccabd9cdb7c3416274cdf3ba9da2e3ee6ba91855b8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fb5bc73c23e4144ddf1e38ccabd9cdb7c3416274cdf3ba9da2e3ee6ba91855b8->enter($__internal_fb5bc73c23e4144ddf1e38ccabd9cdb7c3416274cdf3ba9da2e3ee6ba91855b8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_f044bca1043366abae0241537c9473edc94588219e211c5175089fcb9deddb34 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f044bca1043366abae0241537c9473edc94588219e211c5175089fcb9deddb34->enter($__internal_f044bca1043366abae0241537c9473edc94588219e211c5175089fcb9deddb34_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 64
        echo "
\t\t\t\t";
        
        $__internal_f044bca1043366abae0241537c9473edc94588219e211c5175089fcb9deddb34->leave($__internal_f044bca1043366abae0241537c9473edc94588219e211c5175089fcb9deddb34_prof);

        
        $__internal_fb5bc73c23e4144ddf1e38ccabd9cdb7c3416274cdf3ba9da2e3ee6ba91855b8->leave($__internal_fb5bc73c23e4144ddf1e38ccabd9cdb7c3416274cdf3ba9da2e3ee6ba91855b8_prof);

    }

    // line 71
    public function block_footer($context, array $blocks = array())
    {
        $__internal_5dc53b4ebc3a6b73925a3e133d65ce44bf058a5ee4415f4121d0967a2e5de31c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5dc53b4ebc3a6b73925a3e133d65ce44bf058a5ee4415f4121d0967a2e5de31c->enter($__internal_5dc53b4ebc3a6b73925a3e133d65ce44bf058a5ee4415f4121d0967a2e5de31c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        $__internal_58ac62dd8054bbac00f8f5bd87e861f31f800fdb288c8074520d7bb638f0fd3d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_58ac62dd8054bbac00f8f5bd87e861f31f800fdb288c8074520d7bb638f0fd3d->enter($__internal_58ac62dd8054bbac00f8f5bd87e861f31f800fdb288c8074520d7bb638f0fd3d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        // line 72
        echo "\t\t\t";
        $this->loadTemplate("_footer.html.twig", "base.html.twig", 72)->display($context);
        // line 73
        echo "\t\t";
        
        $__internal_58ac62dd8054bbac00f8f5bd87e861f31f800fdb288c8074520d7bb638f0fd3d->leave($__internal_58ac62dd8054bbac00f8f5bd87e861f31f800fdb288c8074520d7bb638f0fd3d_prof);

        
        $__internal_5dc53b4ebc3a6b73925a3e133d65ce44bf058a5ee4415f4121d0967a2e5de31c->leave($__internal_5dc53b4ebc3a6b73925a3e133d65ce44bf058a5ee4415f4121d0967a2e5de31c_prof);

    }

    // line 78
    public function block_javascript($context, array $blocks = array())
    {
        $__internal_07ea16cd3cfb386c08b399059c8990aa4869e79cc600f98bc73f8a64e367abda = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_07ea16cd3cfb386c08b399059c8990aa4869e79cc600f98bc73f8a64e367abda->enter($__internal_07ea16cd3cfb386c08b399059c8990aa4869e79cc600f98bc73f8a64e367abda_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascript"));

        $__internal_84cccb66dc8ea2dc3eba97ebfe6eddc28a2f13f4f7feee93be85bb218f1840e0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_84cccb66dc8ea2dc3eba97ebfe6eddc28a2f13f4f7feee93be85bb218f1840e0->enter($__internal_84cccb66dc8ea2dc3eba97ebfe6eddc28a2f13f4f7feee93be85bb218f1840e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascript"));

        // line 79
        echo "
\t<!-- JS Global Compulsory -->
\t<script type=\"text/javascript\" src=\"";
        // line 81
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/jquery/jquery.min.js"), "html", null, true);
        echo "\"></script>
\t<script type=\"text/javascript\" src=\"";
        // line 82
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/jquery/jquery-migrate.min.js"), "html", null, true);
        echo "\"></script>
\t<script type=\"text/javascript\" src=\"";
        // line 83
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/bootstrap/js/bootstrap.min.js"), "html", null, true);
        echo "\"></script>
\t<!-- JS Implementing Plugins -->
\t<script type=\"text/javascript\" src=\"";
        // line 85
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/back-to-top.js"), "html", null, true);
        echo "\"></script>
\t<script type=\"text/javascript\" src=\"";
        // line 86
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/smoothScroll.js"), "html", null, true);
        echo "\"></script>
\t<!-- JS Customization -->
\t<script type=\"text/javascript\" src=\"";
        // line 88
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/js/custom.js"), "html", null, true);
        echo "\"></script>
\t<!-- JS Page Level -->
\t<script type=\"text/javascript\" src=\"";
        // line 90
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl(""), "html", null, true);
        echo "\"></script>
\t<script type=\"text/javascript\" src=\"assets/js/plugins/style-switcher.js\"></script>
\t<script type=\"text/javascript\">
        jQuery(document).ready(function() {
            App.init();
            StyleSwitcher.initStyleSwitcher();
        });
\t</script>
\t<!--[if lt IE 9]>
\t<script src=\"assets/plugins/respond.js\"></script>
\t<script src=\"assets/plugins/html5shiv.js\"></script>
\t<script src=\"assets/plugins/placeholder-IE-fixes.js\"></script>
\t<![endif]-->
";
        
        $__internal_84cccb66dc8ea2dc3eba97ebfe6eddc28a2f13f4f7feee93be85bb218f1840e0->leave($__internal_84cccb66dc8ea2dc3eba97ebfe6eddc28a2f13f4f7feee93be85bb218f1840e0_prof);

        
        $__internal_07ea16cd3cfb386c08b399059c8990aa4869e79cc600f98bc73f8a64e367abda->leave($__internal_07ea16cd3cfb386c08b399059c8990aa4869e79cc600f98bc73f8a64e367abda_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  302 => 90,  297 => 88,  292 => 86,  288 => 85,  283 => 83,  279 => 82,  275 => 81,  271 => 79,  262 => 78,  252 => 73,  249 => 72,  240 => 71,  229 => 64,  220 => 63,  210 => 56,  207 => 55,  198 => 54,  186 => 48,  180 => 45,  176 => 44,  172 => 43,  166 => 40,  162 => 39,  156 => 36,  152 => 35,  148 => 34,  144 => 33,  140 => 32,  136 => 31,  130 => 28,  126 => 27,  119 => 23,  115 => 22,  106 => 15,  97 => 14,  85 => 104,  83 => 78,  77 => 74,  75 => 71,  68 => 66,  66 => 63,  62 => 62,  55 => 57,  53 => 54,  47 => 50,  45 => 14,  30 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<!--[if IE 8]> <html lang=\"en\" class=\"ie8\"> <![endif]-->
<!--[if IE 9]> <html lang=\"en\" class=\"ie9\"> <![endif]-->
<!--[if !IE]><!--> <html lang=\"en\"> <!--<![endif]-->
<head>
\t<title>Gestion des prospections</title>

\t<!-- Meta -->
\t<meta charset=\"utf-8\">
\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
\t<meta name=\"description\" content=\"\">
\t<meta name=\"author\" content=\"\">

\t{% block stylesheet %}
\t\t<!-- Favicon -->
\t\t<link rel=\"shortcut icon\" href=\"favicon.ico\">

\t\t<!-- Web Fonts -->
\t\t<link rel='stylesheet' type='text/css' href='//fonts.googleapis.com/css?family=Open+Sans:400,300,600&amp;subset=cyrillic,latin'>

\t\t<!-- CSS Global Compulsory -->
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/plugins/bootstrap/css/bootstrap.min.css') }}\">
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/css/style.css') }}\">


\t\t<!-- CSS Header and Footer -->
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/css/headers/header-default.css') }}\">
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/css/footers/footer-v1.css') }}\">

\t\t<!-- CSS Implementing Plugins -->
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/plugins/animate.css') }}\">
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/plugins/line-icons/line-icons.css') }}\">
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/plugins/font-awesome/css/font-awesome.min.css') }}\">
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/plugins/scrollbar/css/jquery.mCustomScrollbar.css') }}\">
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/plugins/sky-forms-pro/skyforms/css/sky-forms.css') }}\">
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/plugins/sky-forms-pro/skyforms/custom/custom-sky-forms.css') }}\">

\t\t<!-- CSS Page Style -->
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/css/pages/page_log_reg_v1.css') }}\">
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/css/pages/profile.css') }}\">

\t\t<!-- CSS Theme -->
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/css/theme-colors/default.css') }}\" id=\"style_color\">
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/css/theme-skins/dark.css') }}\">
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/css/blocks.css') }}\">

\t\t<!-- CSS Customization -->
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/css/custom.css') }}\">
\t{% endblock %}
</head>

<body class=\"\">
\t<div class=\"wrapper\">
\t\t{% block navbar %}
\t\t\t{% include('_nav.html.twig') %}
\t\t{% endblock %}

\t\t<!--=== Content Part ===-->
\t\t<div class=\"container content margin-top-20\">
\t\t\t<div class=\"row\">

                    {{ include('_flash.html.twig') }}
\t\t\t\t{% block body %}

\t\t\t\t{% endblock %}
\t\t\t</div>
\t\t</div><!--/container-->
\t\t<!--=== End Content Part ===-->

\t\t<!--=== Footer Version 1 ===-->
\t\t{% block footer %}
\t\t\t{% include('_footer.html.twig') %}
\t\t{% endblock %}
\t\t<!--=== End Footer Version 1 ===-->
\t</div>


{% block javascript %}

\t<!-- JS Global Compulsory -->
\t<script type=\"text/javascript\" src=\"{{ asset('assets/plugins/jquery/jquery.min.js') }}\"></script>
\t<script type=\"text/javascript\" src=\"{{ asset('assets/plugins/jquery/jquery-migrate.min.js') }}\"></script>
\t<script type=\"text/javascript\" src=\"{{ asset('assets/plugins/bootstrap/js/bootstrap.min.js') }}\"></script>
\t<!-- JS Implementing Plugins -->
\t<script type=\"text/javascript\" src=\"{{ asset('assets/plugins/back-to-top.js') }}\"></script>
\t<script type=\"text/javascript\" src=\"{{ asset('assets/plugins/smoothScroll.js') }}\"></script>
\t<!-- JS Customization -->
\t<script type=\"text/javascript\" src=\"{{ asset('assets/js/custom.js') }}\"></script>
\t<!-- JS Page Level -->
\t<script type=\"text/javascript\" src=\"{{ asset('') }}\"></script>
\t<script type=\"text/javascript\" src=\"assets/js/plugins/style-switcher.js\"></script>
\t<script type=\"text/javascript\">
        jQuery(document).ready(function() {
            App.init();
            StyleSwitcher.initStyleSwitcher();
        });
\t</script>
\t<!--[if lt IE 9]>
\t<script src=\"assets/plugins/respond.js\"></script>
\t<script src=\"assets/plugins/html5shiv.js\"></script>
\t<script src=\"assets/plugins/placeholder-IE-fixes.js\"></script>
\t<![endif]-->
{% endblock %}
</body>
</html>
", "base.html.twig", "C:\\wamp64\\www\\appli-era\\app\\Resources\\views\\base.html.twig");
    }
}
