<?php

/* :admin/user:create.html.twig */
class __TwigTemplate_bdd5a6c92b9d6e590b0787d96ebd751b1ea25db53705bd50f557f1a8111feffa extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":admin/user:create.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5bf973e29d06195c4004dfe16928196058a219c47d2dcfbae44918878a40d1c4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5bf973e29d06195c4004dfe16928196058a219c47d2dcfbae44918878a40d1c4->enter($__internal_5bf973e29d06195c4004dfe16928196058a219c47d2dcfbae44918878a40d1c4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":admin/user:create.html.twig"));

        $__internal_38d30e4f3dc64ce8f993d7f96a5e13a8a616fd92e5285f7dcb4b1f4b1ab0ac78 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_38d30e4f3dc64ce8f993d7f96a5e13a8a616fd92e5285f7dcb4b1f4b1ab0ac78->enter($__internal_38d30e4f3dc64ce8f993d7f96a5e13a8a616fd92e5285f7dcb4b1f4b1ab0ac78_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":admin/user:create.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5bf973e29d06195c4004dfe16928196058a219c47d2dcfbae44918878a40d1c4->leave($__internal_5bf973e29d06195c4004dfe16928196058a219c47d2dcfbae44918878a40d1c4_prof);

        
        $__internal_38d30e4f3dc64ce8f993d7f96a5e13a8a616fd92e5285f7dcb4b1f4b1ab0ac78->leave($__internal_38d30e4f3dc64ce8f993d7f96a5e13a8a616fd92e5285f7dcb4b1f4b1ab0ac78_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_dd198a0f6da7513d182424e92b5129bb21bc7d3a87726faa79dd9770a90014fa = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dd198a0f6da7513d182424e92b5129bb21bc7d3a87726faa79dd9770a90014fa->enter($__internal_dd198a0f6da7513d182424e92b5129bb21bc7d3a87726faa79dd9770a90014fa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_c1c72ebb2064d89f730935a6c709e3b1029171b2bcf9a96817c2d68f1b00c4ad = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c1c72ebb2064d89f730935a6c709e3b1029171b2bcf9a96817c2d68f1b00c4ad->enter($__internal_c1c72ebb2064d89f730935a6c709e3b1029171b2bcf9a96817c2d68f1b00c4ad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1 class=\"text-center text-uppercase\">";
        echo (($this->getAttribute(($context["goat"] ?? $this->getContext($context, "goat")), "id", array())) ? ("Modifier une chèvre") : ("Créer une chèvre"));
        echo "</h1>
    <div class=\"row\">
        <div class=\"col-xs-12 col-md-6 col-md-offset-3\">
            ";
        // line 7
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start', array("attr" => array("novalidate" => "novalidate")));
        echo "
            ";
        // line 8
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        echo "
            <button class=\"btn btn-block ";
        // line 9
        echo (($this->getAttribute(($context["goat"] ?? $this->getContext($context, "goat")), "id", array())) ? ("btn-warning") : ("btn-success"));
        echo "\" type=\"submit\">
                ";
        // line 10
        echo (($this->getAttribute(($context["goat"] ?? $this->getContext($context, "goat")), "id", array())) ? ("Modifier") : ("Créer"));
        echo "
            </button>
            ";
        // line 12
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        echo "
        </div>
    </div>
";
        
        $__internal_c1c72ebb2064d89f730935a6c709e3b1029171b2bcf9a96817c2d68f1b00c4ad->leave($__internal_c1c72ebb2064d89f730935a6c709e3b1029171b2bcf9a96817c2d68f1b00c4ad_prof);

        
        $__internal_dd198a0f6da7513d182424e92b5129bb21bc7d3a87726faa79dd9770a90014fa->leave($__internal_dd198a0f6da7513d182424e92b5129bb21bc7d3a87726faa79dd9770a90014fa_prof);

    }

    public function getTemplateName()
    {
        return ":admin/user:create.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 12,  68 => 10,  64 => 9,  60 => 8,  56 => 7,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <h1 class=\"text-center text-uppercase\">{{ goat.id ? 'Modifier une chèvre' : 'Créer une chèvre' }}</h1>
    <div class=\"row\">
        <div class=\"col-xs-12 col-md-6 col-md-offset-3\">
            {{ form_start(form,{attr:{novalidate:'novalidate'}}) }}
            {{ form_widget(form) }}
            <button class=\"btn btn-block {{ goat.id ? 'btn-warning' : 'btn-success' }}\" type=\"submit\">
                {{ goat.id ? 'Modifier' : 'Créer' }}
            </button>
            {{ form_end(form) }}
        </div>
    </div>
{% endblock %}
", ":admin/user:create.html.twig", "C:\\wamp64\\www\\appli-era\\app/Resources\\views/admin/user/create.html.twig");
    }
}
