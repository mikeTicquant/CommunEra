<?php

/* WebProfilerBundle:Collector:router.html.twig */
class __TwigTemplate_4e60a21b9f9abb1c8179ac1ee78bb1d1e6bcfe8114974a74ab2d5e0a66993d76 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "WebProfilerBundle:Collector:router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6009da9f8dfd4d62e712948448c6a8854d44117c8482f4a4800583cab50fbc46 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6009da9f8dfd4d62e712948448c6a8854d44117c8482f4a4800583cab50fbc46->enter($__internal_6009da9f8dfd4d62e712948448c6a8854d44117c8482f4a4800583cab50fbc46_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:router.html.twig"));

        $__internal_c53f947fd8b9334c4def873ba5b765bf708a7378184878eca449ce7de17c2e33 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c53f947fd8b9334c4def873ba5b765bf708a7378184878eca449ce7de17c2e33->enter($__internal_c53f947fd8b9334c4def873ba5b765bf708a7378184878eca449ce7de17c2e33_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6009da9f8dfd4d62e712948448c6a8854d44117c8482f4a4800583cab50fbc46->leave($__internal_6009da9f8dfd4d62e712948448c6a8854d44117c8482f4a4800583cab50fbc46_prof);

        
        $__internal_c53f947fd8b9334c4def873ba5b765bf708a7378184878eca449ce7de17c2e33->leave($__internal_c53f947fd8b9334c4def873ba5b765bf708a7378184878eca449ce7de17c2e33_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_2206e1b219b35f5b6f383f1d3a484519b169fef46be559987217ca00747b46e5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2206e1b219b35f5b6f383f1d3a484519b169fef46be559987217ca00747b46e5->enter($__internal_2206e1b219b35f5b6f383f1d3a484519b169fef46be559987217ca00747b46e5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_8afd6ab7a33cfd3892769bb92dd99c897c83562210fbb3d50c50c9e984ec9c30 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8afd6ab7a33cfd3892769bb92dd99c897c83562210fbb3d50c50c9e984ec9c30->enter($__internal_8afd6ab7a33cfd3892769bb92dd99c897c83562210fbb3d50c50c9e984ec9c30_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_8afd6ab7a33cfd3892769bb92dd99c897c83562210fbb3d50c50c9e984ec9c30->leave($__internal_8afd6ab7a33cfd3892769bb92dd99c897c83562210fbb3d50c50c9e984ec9c30_prof);

        
        $__internal_2206e1b219b35f5b6f383f1d3a484519b169fef46be559987217ca00747b46e5->leave($__internal_2206e1b219b35f5b6f383f1d3a484519b169fef46be559987217ca00747b46e5_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_782a6e4aa977781f44450236340b39f652f7de872a52000d648e19fa39af4e7d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_782a6e4aa977781f44450236340b39f652f7de872a52000d648e19fa39af4e7d->enter($__internal_782a6e4aa977781f44450236340b39f652f7de872a52000d648e19fa39af4e7d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_f2aa492faab112c60133d49acaeccae4d92f45251a1fdf7e4111da8e6125f7b1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f2aa492faab112c60133d49acaeccae4d92f45251a1fdf7e4111da8e6125f7b1->enter($__internal_f2aa492faab112c60133d49acaeccae4d92f45251a1fdf7e4111da8e6125f7b1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_f2aa492faab112c60133d49acaeccae4d92f45251a1fdf7e4111da8e6125f7b1->leave($__internal_f2aa492faab112c60133d49acaeccae4d92f45251a1fdf7e4111da8e6125f7b1_prof);

        
        $__internal_782a6e4aa977781f44450236340b39f652f7de872a52000d648e19fa39af4e7d->leave($__internal_782a6e4aa977781f44450236340b39f652f7de872a52000d648e19fa39af4e7d_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_875625bf710b2f3f629e06d0daebcda4b338c3ef46a186ec545e41c72b122234 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_875625bf710b2f3f629e06d0daebcda4b338c3ef46a186ec545e41c72b122234->enter($__internal_875625bf710b2f3f629e06d0daebcda4b338c3ef46a186ec545e41c72b122234_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_707f2763133e18c12587fc13df0140bed32512257f2e1ccbc821f7340047cf32 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_707f2763133e18c12587fc13df0140bed32512257f2e1ccbc821f7340047cf32->enter($__internal_707f2763133e18c12587fc13df0140bed32512257f2e1ccbc821f7340047cf32_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_707f2763133e18c12587fc13df0140bed32512257f2e1ccbc821f7340047cf32->leave($__internal_707f2763133e18c12587fc13df0140bed32512257f2e1ccbc821f7340047cf32_prof);

        
        $__internal_875625bf710b2f3f629e06d0daebcda4b338c3ef46a186ec545e41c72b122234->leave($__internal_875625bf710b2f3f629e06d0daebcda4b338c3ef46a186ec545e41c72b122234_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Collector:router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "WebProfilerBundle:Collector:router.html.twig", "C:\\wamp64\\www\\appli-era\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}
