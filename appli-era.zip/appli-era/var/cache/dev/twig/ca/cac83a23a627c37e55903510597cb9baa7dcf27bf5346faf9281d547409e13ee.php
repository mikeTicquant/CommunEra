<?php

/* :cda:index.html.twig */
class __TwigTemplate_fbff13f49aa2d3fb13944757fe1848313d0206825e62abbb6ce2a911868df067 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":cda:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_de019114321dbb02281c04953353577b8606881785ebd71f052e248311c30f7a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_de019114321dbb02281c04953353577b8606881785ebd71f052e248311c30f7a->enter($__internal_de019114321dbb02281c04953353577b8606881785ebd71f052e248311c30f7a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":cda:index.html.twig"));

        $__internal_00fa22e83e64689977a7aa6d19bc46ac0747e79c842ed85867ca34e7cdafef61 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_00fa22e83e64689977a7aa6d19bc46ac0747e79c842ed85867ca34e7cdafef61->enter($__internal_00fa22e83e64689977a7aa6d19bc46ac0747e79c842ed85867ca34e7cdafef61_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":cda:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_de019114321dbb02281c04953353577b8606881785ebd71f052e248311c30f7a->leave($__internal_de019114321dbb02281c04953353577b8606881785ebd71f052e248311c30f7a_prof);

        
        $__internal_00fa22e83e64689977a7aa6d19bc46ac0747e79c842ed85867ca34e7cdafef61->leave($__internal_00fa22e83e64689977a7aa6d19bc46ac0747e79c842ed85867ca34e7cdafef61_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_601cc8038ce5ee83e004d5e2cb6c6ca91e65c5d266ca7a1b0219ec32f43cee7d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_601cc8038ce5ee83e004d5e2cb6c6ca91e65c5d266ca7a1b0219ec32f43cee7d->enter($__internal_601cc8038ce5ee83e004d5e2cb6c6ca91e65c5d266ca7a1b0219ec32f43cee7d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_c03f096057dedc2b1866275eb2490606f742278df7b1f2b9b917a8a756428ee0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c03f096057dedc2b1866275eb2490606f742278df7b1f2b9b917a8a756428ee0->enter($__internal_c03f096057dedc2b1866275eb2490606f742278df7b1f2b9b917a8a756428ee0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    <h1>Espace Cda</h1>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
";
        
        $__internal_c03f096057dedc2b1866275eb2490606f742278df7b1f2b9b917a8a756428ee0->leave($__internal_c03f096057dedc2b1866275eb2490606f742278df7b1f2b9b917a8a756428ee0_prof);

        
        $__internal_601cc8038ce5ee83e004d5e2cb6c6ca91e65c5d266ca7a1b0219ec32f43cee7d->leave($__internal_601cc8038ce5ee83e004d5e2cb6c6ca91e65c5d266ca7a1b0219ec32f43cee7d_prof);

    }

    public function getTemplateName()
    {
        return ":cda:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 3,  40 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block body %}
    <h1>Espace Cda</h1>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
{% endblock %}", ":cda:index.html.twig", "C:\\wamp64\\www\\appli-era\\app/Resources\\views/cda/index.html.twig");
    }
}
