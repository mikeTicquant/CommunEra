<?php

/* user/reseau/addreseau.html.twig */
class __TwigTemplate_e4892ef9a74a267d2b6e1f7081ce670ed6088ff114a6b98964612947e0e442a5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("base.html.twig", "user/reseau/addreseau.html.twig", 3);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cf4ff38511ec0518ba453930768659c34b6e62abdb0f2bde53d94d13af1c00a5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cf4ff38511ec0518ba453930768659c34b6e62abdb0f2bde53d94d13af1c00a5->enter($__internal_cf4ff38511ec0518ba453930768659c34b6e62abdb0f2bde53d94d13af1c00a5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/reseau/addreseau.html.twig"));

        $__internal_5ad0d571013f62993db71f6e8e59d7056849fbd9f80342a3431892fb2bcda82b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5ad0d571013f62993db71f6e8e59d7056849fbd9f80342a3431892fb2bcda82b->enter($__internal_5ad0d571013f62993db71f6e8e59d7056849fbd9f80342a3431892fb2bcda82b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/reseau/addreseau.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_cf4ff38511ec0518ba453930768659c34b6e62abdb0f2bde53d94d13af1c00a5->leave($__internal_cf4ff38511ec0518ba453930768659c34b6e62abdb0f2bde53d94d13af1c00a5_prof);

        
        $__internal_5ad0d571013f62993db71f6e8e59d7056849fbd9f80342a3431892fb2bcda82b->leave($__internal_5ad0d571013f62993db71f6e8e59d7056849fbd9f80342a3431892fb2bcda82b_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_78387648fae78b0621241a68410b66f88d7cb4400a9830feae55fa22565a53ec = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_78387648fae78b0621241a68410b66f88d7cb4400a9830feae55fa22565a53ec->enter($__internal_78387648fae78b0621241a68410b66f88d7cb4400a9830feae55fa22565a53ec_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_a12605b5db6d874557307693403af3c9ad487047d438d53cea4d489ff80f0bc5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a12605b5db6d874557307693403af3c9ad487047d438d53cea4d489ff80f0bc5->enter($__internal_a12605b5db6d874557307693403af3c9ad487047d438d53cea4d489ff80f0bc5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "

    <div class=\"container content profile\">
        <div class=\"row\">
            <!--Left Sidebar-->

            <div class=\"col-md-3 md-margin-bottom-40\">

                ";
        // line 13
        $context["filename"] = (($this->getAttribute($this->getAttribute(($context["app"] ?? null), "user", array(), "any", false, true), "photo", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute($this->getAttribute(($context["app"] ?? null), "user", array(), "any", false, true), "photo", array()), "img32-md.jpg")) : ("img32-md.jpg"));
        // line 14
        echo "                ";
        $context["url"] = ((($context["globalUserPhotoUri"] ?? $this->getContext($context, "globalUserPhotoUri")) . "/") . ($context["filename"] ?? $this->getContext($context, "filename")));
        // line 15
        echo "                <img class=\"img-thumbnail\" id=\"photo\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl(($context["url"] ?? $this->getContext($context, "url"))), "html", null, true);
        echo "\"/>
                <br><br>
                <ul class=\"list-group sidebar-nav-v1 margin-bottom-40\" id=\"sidebar-nav-1\">
                    <li class=\"list-group-item active\">
                        <a href=\"#\"><i class=\"fa fa-bar-chart-o\"></i> Tableau de bord</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"";
        // line 22
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_profil");
        echo "\">
                            <i class=\"fa fa-user\"></i> Profil
                        </a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"";
        // line 27
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_profil");
        echo "\">
                            <i class=\"fa fa-building-o\"></i> Entreprise
                        </a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"";
        // line 32
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_affiliate");
        echo "\">
                            <i class=\"fa fa-flag-o\"></i> Code d'affialition
                        </a>
                    </li>


                    <li class=\"list-group-item\">
                        <a href=\"#\"><i class=\"fa fa-cog\"></i> Settings</a>
                    </li>
                </ul>

            </div>
            <!--End Left Sidebar-->

            <!-- Profile Content -->
            <div class=\"col-md-9\">
                <div class=\"profile-body margin-bottom-20\">

                    <h2 class=\"heading-md\">Code d'affiliation</h2>
                    <br>

                        <dl class=\"dl-horizontal\">
                            <dt></dt>
                            <dd>
                                ";
        // line 56
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start', array("attr" => array("novalidate" => "novalidate")));
        echo "
                                <section>

                                    <label class=\"input\">

                                        ";
        // line 61
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        echo "

                                    </label>
                                </section>
                                <section>
                                    <br>
                                    <button class=\"btn-u\" type=\"submit\">Ajouter le code d'affiliation</button>
                                    <button type=\"button\" class=\"btn-u btn-u-default\">Annuler</button>
                                    ";
        // line 69
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        echo "
                                </section>
                            </dd>

                        </dl>



                </div>

            </div>
        </div>
        <!-- End Profile Content -->
    </div><!--/end row-->


";
        
        $__internal_a12605b5db6d874557307693403af3c9ad487047d438d53cea4d489ff80f0bc5->leave($__internal_a12605b5db6d874557307693403af3c9ad487047d438d53cea4d489ff80f0bc5_prof);

        
        $__internal_78387648fae78b0621241a68410b66f88d7cb4400a9830feae55fa22565a53ec->leave($__internal_78387648fae78b0621241a68410b66f88d7cb4400a9830feae55fa22565a53ec_prof);

    }

    public function getTemplateName()
    {
        return "user/reseau/addreseau.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  137 => 69,  126 => 61,  118 => 56,  91 => 32,  83 => 27,  75 => 22,  64 => 15,  61 => 14,  59 => 13,  49 => 5,  40 => 4,  11 => 3,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("

{% extends 'base.html.twig' %}
{% block body %}


    <div class=\"container content profile\">
        <div class=\"row\">
            <!--Left Sidebar-->

            <div class=\"col-md-3 md-margin-bottom-40\">

                {% set filename = app.user.photo|default('img32-md.jpg') %}
                {% set url = globalUserPhotoUri ~ '/' ~ filename %}
                <img class=\"img-thumbnail\" id=\"photo\" src=\"{{ asset(url) }}\"/>
                <br><br>
                <ul class=\"list-group sidebar-nav-v1 margin-bottom-40\" id=\"sidebar-nav-1\">
                    <li class=\"list-group-item active\">
                        <a href=\"#\"><i class=\"fa fa-bar-chart-o\"></i> Tableau de bord</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"{{ path('app_user_user_profil') }}\">
                            <i class=\"fa fa-user\"></i> Profil
                        </a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"{{ path('app_user_user_profil') }}\">
                            <i class=\"fa fa-building-o\"></i> Entreprise
                        </a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"{{ path('app_user_user_affiliate') }}\">
                            <i class=\"fa fa-flag-o\"></i> Code d'affialition
                        </a>
                    </li>


                    <li class=\"list-group-item\">
                        <a href=\"#\"><i class=\"fa fa-cog\"></i> Settings</a>
                    </li>
                </ul>

            </div>
            <!--End Left Sidebar-->

            <!-- Profile Content -->
            <div class=\"col-md-9\">
                <div class=\"profile-body margin-bottom-20\">

                    <h2 class=\"heading-md\">Code d'affiliation</h2>
                    <br>

                        <dl class=\"dl-horizontal\">
                            <dt></dt>
                            <dd>
                                {{ form_start(form,{attr:{novalidate:'novalidate'}}) }}
                                <section>

                                    <label class=\"input\">

                                        {{ form_widget(form) }}

                                    </label>
                                </section>
                                <section>
                                    <br>
                                    <button class=\"btn-u\" type=\"submit\">Ajouter le code d'affiliation</button>
                                    <button type=\"button\" class=\"btn-u btn-u-default\">Annuler</button>
                                    {{ form_end(form) }}
                                </section>
                            </dd>

                        </dl>



                </div>

            </div>
        </div>
        <!-- End Profile Content -->
    </div><!--/end row-->


{% endblock %}", "user/reseau/addreseau.html.twig", "C:\\wamp64\\www\\appli-era\\app\\Resources\\views\\user\\reseau\\addreseau.html.twig");
    }
}
