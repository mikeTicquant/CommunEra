<?php

/* admin/base_admin.html.twig */
class __TwigTemplate_bcbe52c449b279d331733ba545e0677feea9f2a59a8007cf1881f67eb797f6bf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'stylesheet' => array($this, 'block_stylesheet'),
            'body' => array($this, 'block_body'),
            'javascript' => array($this, 'block_javascript'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1d8dd74ed06643885b2adb9d2d8c3f3ca8f02d00f940da4edc5455300cc31e05 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1d8dd74ed06643885b2adb9d2d8c3f3ca8f02d00f940da4edc5455300cc31e05->enter($__internal_1d8dd74ed06643885b2adb9d2d8c3f3ca8f02d00f940da4edc5455300cc31e05_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/base_admin.html.twig"));

        $__internal_673b8bb4969df1d39724c437c8e6822f62559f05c2c4bf44b1ec949257f7e918 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_673b8bb4969df1d39724c437c8e6822f62559f05c2c4bf44b1ec949257f7e918->enter($__internal_673b8bb4969df1d39724c437c8e6822f62559f05c2c4bf44b1ec949257f7e918_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/base_admin.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<!--[if IE 8]> <html lang=\"en\" class=\"ie8\"> <![endif]-->
<!--[if IE 9]> <html lang=\"en\" class=\"ie9\"> <![endif]-->
<!--[if !IE]><!--> <html lang=\"en\"> <!--<![endif]-->
<head>
\t<title>Gestion des prospections</title>

\t<!-- Meta -->
\t<meta charset=\"utf-8\">
\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
\t<meta name=\"description\" content=\"\">
\t<meta name=\"author\" content=\"\">

    ";
        // line 14
        $this->displayBlock('stylesheet', $context, $blocks);
        // line 51
        echo "</head>

<body class=\"header-fixed\">
\t<div class=\"wrapper\">

\t";
        // line 56
        echo twig_include($this->env, $context, "admin/_nav_admin.html.twig");
        echo "

\t<!--=== Content Part ===-->
\t<div class=\"container content margin-top-20\">
\t\t<div class=\"row\">

            ";
        // line 62
        echo twig_include($this->env, $context, "_flash.html.twig");
        echo "
            ";
        // line 63
        $this->displayBlock('body', $context, $blocks);
        // line 66
        echo "\t\t</div>
\t</div><!--/container-->
\t<!--=== End Content Part ===-->


";
        // line 71
        echo twig_include($this->env, $context, "admin/_footer_admin.html.twig");
        echo "
</div><!--/wrapper-->

";
        // line 74
        $this->displayBlock('javascript', $context, $blocks);
        // line 100
        echo "</body>
</html>
";
        
        $__internal_1d8dd74ed06643885b2adb9d2d8c3f3ca8f02d00f940da4edc5455300cc31e05->leave($__internal_1d8dd74ed06643885b2adb9d2d8c3f3ca8f02d00f940da4edc5455300cc31e05_prof);

        
        $__internal_673b8bb4969df1d39724c437c8e6822f62559f05c2c4bf44b1ec949257f7e918->leave($__internal_673b8bb4969df1d39724c437c8e6822f62559f05c2c4bf44b1ec949257f7e918_prof);

    }

    // line 14
    public function block_stylesheet($context, array $blocks = array())
    {
        $__internal_d32990e07ffd909dd5485d35d6c9e5596a450f87543e5a5e175345e4854c53c0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d32990e07ffd909dd5485d35d6c9e5596a450f87543e5a5e175345e4854c53c0->enter($__internal_d32990e07ffd909dd5485d35d6c9e5596a450f87543e5a5e175345e4854c53c0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheet"));

        $__internal_85f0a36cdc48b4384092405d5820198509e88b5479c25a39974e8e21c58f216d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_85f0a36cdc48b4384092405d5820198509e88b5479c25a39974e8e21c58f216d->enter($__internal_85f0a36cdc48b4384092405d5820198509e88b5479c25a39974e8e21c58f216d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheet"));

        // line 15
        echo "\t\t<!-- Favicon -->
\t\t<link rel=\"shortcut icon\" href=\"favicon.ico\">


\t\t<!-- Web Fonts -->
\t\t<link rel='stylesheet' type='text/css' href='//fonts.googleapis.com/css?family=Open+Sans:400,300,600&amp;subset=cyrillic,latin'>

\t\t<!-- CSS Global Compulsory -->
\t\t<link rel=\"stylesheet\" href=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/bootstrap/css/bootstrap.min.css"), "html", null, true);
        echo "\">
\t\t<link rel=\"stylesheet\" href=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/style.css"), "html", null, true);
        echo "\">


\t\t<!-- CSS Header and Footer -->
\t\t<link rel=\"stylesheet\" href=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/headers/header-v3.css"), "html", null, true);
        echo "\">
\t\t<link rel=\"stylesheet\" href=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/footers/footer-v1.css"), "html", null, true);
        echo "\">

\t\t<!-- CSS Implementing Plugins -->
\t\t<link rel=\"stylesheet\" href=\"";
        // line 32
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/animate.css"), "html", null, true);
        echo "\">
\t\t<link rel=\"stylesheet\" href=\"";
        // line 33
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/line-icons/line-icons.css"), "html", null, true);
        echo "\">
\t\t<link rel=\"stylesheet\" href=\"";
        // line 34
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/font-awesome/css/font-awesome.min.css"), "html", null, true);
        echo "\">
\t\t<link rel=\"stylesheet\" href=\"";
        // line 35
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/scrollbar/css/jquery.mCustomScrollbar.css"), "html", null, true);
        echo "\">
\t\t<link rel=\"stylesheet\" href=\"";
        // line 36
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/sky-forms-pro/skyforms/css/sky-forms.css"), "html", null, true);
        echo "\">
\t\t<link rel=\"stylesheet\" href=\"";
        // line 37
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/sky-forms-pro/skyforms/custom/custom-sky-forms.css"), "html", null, true);
        echo "\">

\t\t<!-- CSS Page Style -->
\t\t<link rel=\"stylesheet\" href=\"";
        // line 40
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/pages/page_log_reg_v1.css"), "html", null, true);
        echo "\">
\t\t<link rel=\"stylesheet\" href=\"";
        // line 41
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/pages/profile.css"), "html", null, true);
        echo "\">

\t\t<!-- CSS Theme -->
\t\t<link rel=\"stylesheet\" href=\"";
        // line 44
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/theme-colors/default.css"), "html", null, true);
        echo "\" id=\"style_color\">
\t\t<link rel=\"stylesheet\" href=\"";
        // line 45
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/theme-skins/dark.css"), "html", null, true);
        echo "\">
\t\t<link rel=\"stylesheet\" href=\"";
        // line 46
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/blocks.css"), "html", null, true);
        echo "\">

\t\t<!-- CSS Customization -->
\t\t<link rel=\"stylesheet\" href=\"";
        // line 49
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/custom.css"), "html", null, true);
        echo "\">
    ";
        
        $__internal_85f0a36cdc48b4384092405d5820198509e88b5479c25a39974e8e21c58f216d->leave($__internal_85f0a36cdc48b4384092405d5820198509e88b5479c25a39974e8e21c58f216d_prof);

        
        $__internal_d32990e07ffd909dd5485d35d6c9e5596a450f87543e5a5e175345e4854c53c0->leave($__internal_d32990e07ffd909dd5485d35d6c9e5596a450f87543e5a5e175345e4854c53c0_prof);

    }

    // line 63
    public function block_body($context, array $blocks = array())
    {
        $__internal_ddb310cffef0fba36da1ee778d055e66ebbf561250252d194126ed2ad93d48ac = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ddb310cffef0fba36da1ee778d055e66ebbf561250252d194126ed2ad93d48ac->enter($__internal_ddb310cffef0fba36da1ee778d055e66ebbf561250252d194126ed2ad93d48ac_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_6608ec183d409adeab97eea8ccef72d16093461f85df40503972ab7a75cb9b53 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6608ec183d409adeab97eea8ccef72d16093461f85df40503972ab7a75cb9b53->enter($__internal_6608ec183d409adeab97eea8ccef72d16093461f85df40503972ab7a75cb9b53_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 64
        echo "
            ";
        
        $__internal_6608ec183d409adeab97eea8ccef72d16093461f85df40503972ab7a75cb9b53->leave($__internal_6608ec183d409adeab97eea8ccef72d16093461f85df40503972ab7a75cb9b53_prof);

        
        $__internal_ddb310cffef0fba36da1ee778d055e66ebbf561250252d194126ed2ad93d48ac->leave($__internal_ddb310cffef0fba36da1ee778d055e66ebbf561250252d194126ed2ad93d48ac_prof);

    }

    // line 74
    public function block_javascript($context, array $blocks = array())
    {
        $__internal_6abfad59bfa0b521dd43c6b3a0154b83b9bfdff99b40b0df98957d5e4ecba823 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6abfad59bfa0b521dd43c6b3a0154b83b9bfdff99b40b0df98957d5e4ecba823->enter($__internal_6abfad59bfa0b521dd43c6b3a0154b83b9bfdff99b40b0df98957d5e4ecba823_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascript"));

        $__internal_8b1cd65a2c052fc1346657ac22f14e9dcbd948d692980f947c3de70dec4be744 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8b1cd65a2c052fc1346657ac22f14e9dcbd948d692980f947c3de70dec4be744->enter($__internal_8b1cd65a2c052fc1346657ac22f14e9dcbd948d692980f947c3de70dec4be744_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascript"));

        // line 75
        echo "
\t<!-- JS Global Compulsory -->
\t<script type=\"text/javascript\" src=\"";
        // line 77
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/jquery/jquery.min.js"), "html", null, true);
        echo "\"></script>
\t<script type=\"text/javascript\" src=\"";
        // line 78
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/jquery/jquery-migrate.min.js"), "html", null, true);
        echo "\"></script>
\t<script type=\"text/javascript\" src=\"";
        // line 79
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/bootstrap/js/bootstrap.min.js"), "html", null, true);
        echo "\"></script>
\t<!-- JS Implementing Plugins -->
\t<script type=\"text/javascript\" src=\"";
        // line 81
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/back-to-top.js"), "html", null, true);
        echo "\"></script>
\t<script type=\"text/javascript\" src=\"";
        // line 82
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/smoothScroll.js"), "html", null, true);
        echo "\"></script>
\t<!-- JS Customization -->
\t<script type=\"text/javascript\" src=\"";
        // line 84
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/js/custom.js"), "html", null, true);
        echo "\"></script>
\t<!-- JS Page Level -->
\t<script type=\"text/javascript\" src=\"";
        // line 86
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl(""), "html", null, true);
        echo "\"></script>
\t<script type=\"text/javascript\" src=\"assets/js/plugins/style-switcher.js\"></script>
\t<script type=\"text/javascript\">
        jQuery(document).ready(function() {
            App.init();
            StyleSwitcher.initStyleSwitcher();
        });
\t</script>
\t<!--[if lt IE 9]>
\t<script src=\"assets/plugins/respond.js\"></script>
\t<script src=\"assets/plugins/html5shiv.js\"></script>
\t<script src=\"assets/plugins/placeholder-IE-fixes.js\"></script>
\t<![endif]-->
";
        
        $__internal_8b1cd65a2c052fc1346657ac22f14e9dcbd948d692980f947c3de70dec4be744->leave($__internal_8b1cd65a2c052fc1346657ac22f14e9dcbd948d692980f947c3de70dec4be744_prof);

        
        $__internal_6abfad59bfa0b521dd43c6b3a0154b83b9bfdff99b40b0df98957d5e4ecba823->leave($__internal_6abfad59bfa0b521dd43c6b3a0154b83b9bfdff99b40b0df98957d5e4ecba823_prof);

    }

    public function getTemplateName()
    {
        return "admin/base_admin.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  256 => 86,  251 => 84,  246 => 82,  242 => 81,  237 => 79,  233 => 78,  229 => 77,  225 => 75,  216 => 74,  205 => 64,  196 => 63,  184 => 49,  178 => 46,  174 => 45,  170 => 44,  164 => 41,  160 => 40,  154 => 37,  150 => 36,  146 => 35,  142 => 34,  138 => 33,  134 => 32,  128 => 29,  124 => 28,  117 => 24,  113 => 23,  103 => 15,  94 => 14,  82 => 100,  80 => 74,  74 => 71,  67 => 66,  65 => 63,  61 => 62,  52 => 56,  45 => 51,  43 => 14,  28 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<!--[if IE 8]> <html lang=\"en\" class=\"ie8\"> <![endif]-->
<!--[if IE 9]> <html lang=\"en\" class=\"ie9\"> <![endif]-->
<!--[if !IE]><!--> <html lang=\"en\"> <!--<![endif]-->
<head>
\t<title>Gestion des prospections</title>

\t<!-- Meta -->
\t<meta charset=\"utf-8\">
\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
\t<meta name=\"description\" content=\"\">
\t<meta name=\"author\" content=\"\">

    {% block stylesheet %}
\t\t<!-- Favicon -->
\t\t<link rel=\"shortcut icon\" href=\"favicon.ico\">


\t\t<!-- Web Fonts -->
\t\t<link rel='stylesheet' type='text/css' href='//fonts.googleapis.com/css?family=Open+Sans:400,300,600&amp;subset=cyrillic,latin'>

\t\t<!-- CSS Global Compulsory -->
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/plugins/bootstrap/css/bootstrap.min.css') }}\">
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/css/style.css') }}\">


\t\t<!-- CSS Header and Footer -->
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/css/headers/header-v3.css') }}\">
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/css/footers/footer-v1.css') }}\">

\t\t<!-- CSS Implementing Plugins -->
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/plugins/animate.css') }}\">
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/plugins/line-icons/line-icons.css') }}\">
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/plugins/font-awesome/css/font-awesome.min.css') }}\">
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/plugins/scrollbar/css/jquery.mCustomScrollbar.css') }}\">
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/plugins/sky-forms-pro/skyforms/css/sky-forms.css') }}\">
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/plugins/sky-forms-pro/skyforms/custom/custom-sky-forms.css') }}\">

\t\t<!-- CSS Page Style -->
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/css/pages/page_log_reg_v1.css') }}\">
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/css/pages/profile.css') }}\">

\t\t<!-- CSS Theme -->
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/css/theme-colors/default.css') }}\" id=\"style_color\">
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/css/theme-skins/dark.css') }}\">
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/css/blocks.css') }}\">

\t\t<!-- CSS Customization -->
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/css/custom.css') }}\">
    {% endblock %}
</head>

<body class=\"header-fixed\">
\t<div class=\"wrapper\">

\t{{ include('admin/_nav_admin.html.twig') }}

\t<!--=== Content Part ===-->
\t<div class=\"container content margin-top-20\">
\t\t<div class=\"row\">

            {{ include('_flash.html.twig') }}
            {% block body %}

            {% endblock %}
\t\t</div>
\t</div><!--/container-->
\t<!--=== End Content Part ===-->


{{ include('admin/_footer_admin.html.twig') }}
</div><!--/wrapper-->

{% block javascript %}

\t<!-- JS Global Compulsory -->
\t<script type=\"text/javascript\" src=\"{{ asset('assets/plugins/jquery/jquery.min.js') }}\"></script>
\t<script type=\"text/javascript\" src=\"{{ asset('assets/plugins/jquery/jquery-migrate.min.js') }}\"></script>
\t<script type=\"text/javascript\" src=\"{{ asset('assets/plugins/bootstrap/js/bootstrap.min.js') }}\"></script>
\t<!-- JS Implementing Plugins -->
\t<script type=\"text/javascript\" src=\"{{ asset('assets/plugins/back-to-top.js') }}\"></script>
\t<script type=\"text/javascript\" src=\"{{ asset('assets/plugins/smoothScroll.js') }}\"></script>
\t<!-- JS Customization -->
\t<script type=\"text/javascript\" src=\"{{ asset('assets/js/custom.js') }}\"></script>
\t<!-- JS Page Level -->
\t<script type=\"text/javascript\" src=\"{{ asset('') }}\"></script>
\t<script type=\"text/javascript\" src=\"assets/js/plugins/style-switcher.js\"></script>
\t<script type=\"text/javascript\">
        jQuery(document).ready(function() {
            App.init();
            StyleSwitcher.initStyleSwitcher();
        });
\t</script>
\t<!--[if lt IE 9]>
\t<script src=\"assets/plugins/respond.js\"></script>
\t<script src=\"assets/plugins/html5shiv.js\"></script>
\t<script src=\"assets/plugins/placeholder-IE-fixes.js\"></script>
\t<![endif]-->
{% endblock %}
</body>
</html>
", "admin/base_admin.html.twig", "C:\\wamp64\\www\\appli-era\\app\\Resources\\views\\admin\\base_admin.html.twig");
    }
}
