<?php

/* user/affiliate.html.twig */
class __TwigTemplate_841b41d975b76c123214bb076df59e26829ca6ba86a8c96981c0e6e95d0f9428 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "user/affiliate.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_63d0d5d31e4775a7d5cbaa5283027f4fdeba9615559422689c25cc6ed6b70bf4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_63d0d5d31e4775a7d5cbaa5283027f4fdeba9615559422689c25cc6ed6b70bf4->enter($__internal_63d0d5d31e4775a7d5cbaa5283027f4fdeba9615559422689c25cc6ed6b70bf4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/affiliate.html.twig"));

        $__internal_8cb85a1b6dd7a696fcfbd6cac000d8323a6152cfee2648035ed81082400829e6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8cb85a1b6dd7a696fcfbd6cac000d8323a6152cfee2648035ed81082400829e6->enter($__internal_8cb85a1b6dd7a696fcfbd6cac000d8323a6152cfee2648035ed81082400829e6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/affiliate.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_63d0d5d31e4775a7d5cbaa5283027f4fdeba9615559422689c25cc6ed6b70bf4->leave($__internal_63d0d5d31e4775a7d5cbaa5283027f4fdeba9615559422689c25cc6ed6b70bf4_prof);

        
        $__internal_8cb85a1b6dd7a696fcfbd6cac000d8323a6152cfee2648035ed81082400829e6->leave($__internal_8cb85a1b6dd7a696fcfbd6cac000d8323a6152cfee2648035ed81082400829e6_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_5975db0e85d8fcc128ec70970c0621237aa41cfd46f51fed63289c845f3c63dd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5975db0e85d8fcc128ec70970c0621237aa41cfd46f51fed63289c845f3c63dd->enter($__internal_5975db0e85d8fcc128ec70970c0621237aa41cfd46f51fed63289c845f3c63dd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_98b4770f064d1990bbb383e40271aef76e8282375cbe52c6e462e456f29513a1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_98b4770f064d1990bbb383e40271aef76e8282375cbe52c6e462e456f29513a1->enter($__internal_98b4770f064d1990bbb383e40271aef76e8282375cbe52c6e462e456f29513a1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "
    <div class=\"container content profile\">
        <div class=\"row\">
            <!--Left Sidebar-->
            <div class=\"col-md-3 md-margin-bottom-40\">

                ";
        // line 11
        $context["filename"] = (($this->getAttribute($this->getAttribute(($context["app"] ?? null), "user", array(), "any", false, true), "photo", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute($this->getAttribute(($context["app"] ?? null), "user", array(), "any", false, true), "photo", array()), "img32-md.jpg")) : ("img32-md.jpg"));
        // line 12
        echo "                ";
        $context["url"] = ((($context["globalUserPhotoUri"] ?? $this->getContext($context, "globalUserPhotoUri")) . "/") . ($context["filename"] ?? $this->getContext($context, "filename")));
        // line 13
        echo "                <img class=\"img-thumbnail\" id=\"photo\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl(($context["url"] ?? $this->getContext($context, "url"))), "html", null, true);
        echo "\"/>
                <br><br>
                <ul class=\"list-group sidebar-nav-v1 margin-bottom-40\" id=\"sidebar-nav-1\">
                    <li class=\"list-group-item active\">
                        <a href=\"#\"><i class=\"fa fa-bar-chart-o\"></i> Tableau de bord</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"";
        // line 20
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_profil");
        echo "\">
                            <i class=\"fa fa-user\"></i> Profil
                        </a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"";
        // line 25
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_profil");
        echo "\">
                            <i class=\"fa fa-building-o\"></i> Entreprise
                        </a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"";
        // line 30
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_affiliate");
        echo "\">
                            <i class=\"fa fa-flag-o\"></i> Code d'affialition
                        </a>
                    </li>


                    <li class=\"list-group-item\">
                        <a href=\"#\"><i class=\"fa fa-cog\"></i> Settings</a>
                    </li>
                </ul>

            </div>
            <!--End Left Sidebar-->

            <!-- Profile Content -->

            <div class=\"col-md-9\">

            <div class=\"profile-body\">
                <div class=\"tab-v1\">
                    <ul class=\"nav nav-justified nav-tabs\">
                        ";
        // line 51
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_CDA")) {
            // line 52
            echo "                            <li class=\"active\"><a href=\"#liste\">Mon code d'affiliation</a></li>
                            <li><a href=\"";
            // line 53
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_addcda");
            echo "\">Créer un code d'affialition</a></li>
                        ";
        } elseif ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_RESEAU")) {
            // line 55
            echo "                            <li class=\"active\"><a href=\"#liste\">Mon code d'affiliation</a></li>
                            <li><a href=\"";
            // line 56
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_addreseau");
            echo "\">Créer un code d'affialition</a></li>
                        ";
        } elseif ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_NEGOCIATEUR")) {
            // line 58
            echo "                            <li class=\"active\"><a href=\"#liste\">Mon code d'affiliation</a></li>
                        ";
        }
        // line 60
        echo "                    </ul>
                    <div class=\"tab-content\">
                        <div id=\"liste\" class=\"profile-edit tab-pane fade in active no-padding\">
                            <div class=\"table-search-v2\">
                                <div class=\"table-responsive\">
                                    <table class=\"table no-margin\">
                                        <thead>
                                        <tr>
                                            <th style=\"width: 96px;\"></th>
                                            <th>Identité</th>
                                            <th style=\"width: 150px;\">Code d'affiliation</th>
                                            <th class=\"\" style=\"width: 100px;\">Actions</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td>
                                                ";
        // line 77
        $context["filename"] = (($this->getAttribute($this->getAttribute(($context["app"] ?? null), "user", array(), "any", false, true), "photo", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute($this->getAttribute(($context["app"] ?? null), "user", array(), "any", false, true), "photo", array()), "img32-md.jpg")) : ("img32-md.jpg"));
        // line 78
        echo "                                                ";
        $context["url"] = ((($context["globalUserPhotoUri"] ?? $this->getContext($context, "globalUserPhotoUri")) . "/") . ($context["filename"] ?? $this->getContext($context, "filename")));
        // line 79
        echo "                                                <img class=\"rounded-x\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl(($context["url"] ?? $this->getContext($context, "url"))), "html", null, true);
        echo "\" alt=\"\">

                                            </td>
                                            <td>
                                                <h3>";
        // line 83
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "firstname", array()), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "lastname", array()), "html", null, true);
        echo " </h3>
                                                <p> ";
        // line 84
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "job", array()), "html", null, true);
        echo " <br><small>";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "email", array()), "html", null, true);
        echo "</small></p>

                                            </td>
                                            <td>

                                                 ";
        // line 89
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_CDA")) {
            // line 90
            echo "                                                    ";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "cda", array()), "html", null, true);
            echo "
                                                 ";
        } elseif ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_RESEAU")) {
            // line 92
            echo "                                                    ";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "reseau", array()), "html", null, true);
            echo "
                                                 ";
        } elseif ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_GRP_AGENCE")) {
            // line 94
            echo "                                                     ";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "gagence", array()), "html", null, true);
            echo "
                                                 ";
        } elseif ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_AGENCE")) {
            // line 96
            echo "                                                     ";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "agence", array()), "html", null, true);
            echo "
                                                 ";
        } elseif ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_NEGOCIATEUR")) {
            // line 98
            echo "                                                     ";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "negociateur", array()), "html", null, true);
            echo "
                                                 ";
        }
        // line 100
        echo "
                                            </td>
                                            <td class=\"text-right\">
                                                <a href=\"";
        // line 103
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_notification_notification_index");
        echo "\" class=\"btn-u btn-u-blue btn-block btn-u-xs\" style=\"color: white; margin-bottom: 5px;\"><i class=\"fa fa-send fa-fw\"></i> Envoyer le code</a><br>
                                                <a href=\"";
        // line 104
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_profil");
        echo "\" class=\"btn-u btn-u-red btn-block btn-u-xs\" style=\"color: white;\"><i class=\"fa fa-pencil fa-fw\"></i> Modifier</a>                  </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>


                        </div>
                    </div>
                </div>
            </div>

        </div>
        <!-- End Profile Content -->
    </div>
    </div>

            <!-- End Profile Content -->

    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>

";
        
        $__internal_98b4770f064d1990bbb383e40271aef76e8282375cbe52c6e462e456f29513a1->leave($__internal_98b4770f064d1990bbb383e40271aef76e8282375cbe52c6e462e456f29513a1_prof);

        
        $__internal_5975db0e85d8fcc128ec70970c0621237aa41cfd46f51fed63289c845f3c63dd->leave($__internal_5975db0e85d8fcc128ec70970c0621237aa41cfd46f51fed63289c845f3c63dd_prof);

    }

    public function getTemplateName()
    {
        return "user/affiliate.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  224 => 104,  220 => 103,  215 => 100,  209 => 98,  203 => 96,  197 => 94,  191 => 92,  185 => 90,  183 => 89,  173 => 84,  167 => 83,  159 => 79,  156 => 78,  154 => 77,  135 => 60,  131 => 58,  126 => 56,  123 => 55,  118 => 53,  115 => 52,  113 => 51,  89 => 30,  81 => 25,  73 => 20,  62 => 13,  59 => 12,  57 => 11,  49 => 5,  40 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}


{% block body %}

    <div class=\"container content profile\">
        <div class=\"row\">
            <!--Left Sidebar-->
            <div class=\"col-md-3 md-margin-bottom-40\">

                {% set filename = app.user.photo|default('img32-md.jpg') %}
                {% set url = globalUserPhotoUri ~ '/' ~ filename %}
                <img class=\"img-thumbnail\" id=\"photo\" src=\"{{ asset(url) }}\"/>
                <br><br>
                <ul class=\"list-group sidebar-nav-v1 margin-bottom-40\" id=\"sidebar-nav-1\">
                    <li class=\"list-group-item active\">
                        <a href=\"#\"><i class=\"fa fa-bar-chart-o\"></i> Tableau de bord</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"{{ path('app_user_user_profil') }}\">
                            <i class=\"fa fa-user\"></i> Profil
                        </a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"{{ path('app_user_user_profil') }}\">
                            <i class=\"fa fa-building-o\"></i> Entreprise
                        </a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"{{ path('app_user_user_affiliate') }}\">
                            <i class=\"fa fa-flag-o\"></i> Code d'affialition
                        </a>
                    </li>


                    <li class=\"list-group-item\">
                        <a href=\"#\"><i class=\"fa fa-cog\"></i> Settings</a>
                    </li>
                </ul>

            </div>
            <!--End Left Sidebar-->

            <!-- Profile Content -->

            <div class=\"col-md-9\">

            <div class=\"profile-body\">
                <div class=\"tab-v1\">
                    <ul class=\"nav nav-justified nav-tabs\">
                        {% if is_granted('ROLE_CDA') %}
                            <li class=\"active\"><a href=\"#liste\">Mon code d'affiliation</a></li>
                            <li><a href=\"{{ path('app_user_user_addcda') }}\">Créer un code d'affialition</a></li>
                        {% elseif is_granted('ROLE_RESEAU') %}
                            <li class=\"active\"><a href=\"#liste\">Mon code d'affiliation</a></li>
                            <li><a href=\"{{ path('app_user_user_addreseau') }}\">Créer un code d'affialition</a></li>
                        {% elseif is_granted('ROLE_NEGOCIATEUR') %}
                            <li class=\"active\"><a href=\"#liste\">Mon code d'affiliation</a></li>
                        {% endif %}
                    </ul>
                    <div class=\"tab-content\">
                        <div id=\"liste\" class=\"profile-edit tab-pane fade in active no-padding\">
                            <div class=\"table-search-v2\">
                                <div class=\"table-responsive\">
                                    <table class=\"table no-margin\">
                                        <thead>
                                        <tr>
                                            <th style=\"width: 96px;\"></th>
                                            <th>Identité</th>
                                            <th style=\"width: 150px;\">Code d'affiliation</th>
                                            <th class=\"\" style=\"width: 100px;\">Actions</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td>
                                                {% set filename = app.user.photo|default('img32-md.jpg') %}
                                                {% set url = globalUserPhotoUri ~ '/' ~ filename %}
                                                <img class=\"rounded-x\" src=\"{{ asset(url) }}\" alt=\"\">

                                            </td>
                                            <td>
                                                <h3>{{ app.user.firstname }} {{ app.user.lastname }} </h3>
                                                <p> {{ app.user.job }} <br><small>{{ app.user.email }}</small></p>

                                            </td>
                                            <td>

                                                 {% if is_granted('ROLE_CDA') %}
                                                    {{ app.user.cda }}
                                                 {% elseif is_granted('ROLE_RESEAU') %}
                                                    {{ app.user.reseau }}
                                                 {% elseif is_granted('ROLE_GRP_AGENCE') %}
                                                     {{ app.user.gagence }}
                                                 {% elseif is_granted('ROLE_AGENCE') %}
                                                     {{ app.user.agence }}
                                                 {% elseif is_granted('ROLE_NEGOCIATEUR') %}
                                                     {{ app.user.negociateur }}
                                                 {% endif %}

                                            </td>
                                            <td class=\"text-right\">
                                                <a href=\"{{ path(\"app_notification_notification_index\") }}\" class=\"btn-u btn-u-blue btn-block btn-u-xs\" style=\"color: white; margin-bottom: 5px;\"><i class=\"fa fa-send fa-fw\"></i> Envoyer le code</a><br>
                                                <a href=\"{{ path(\"app_user_user_profil\") }}\" class=\"btn-u btn-u-red btn-block btn-u-xs\" style=\"color: white;\"><i class=\"fa fa-pencil fa-fw\"></i> Modifier</a>                  </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>


                        </div>
                    </div>
                </div>
            </div>

        </div>
        <!-- End Profile Content -->
    </div>
    </div>

            <!-- End Profile Content -->

    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>

{% endblock %}

", "user/affiliate.html.twig", "C:\\wamp64\\www\\appli-era\\app\\Resources\\views\\user\\affiliate.html.twig");
    }
}
