<?php

/* TwigBundle:Exception:error.rdf.twig */
class __TwigTemplate_42cff5b1d618a1f1a99ec0c2e1b3fc3d1e8c18aec7b7fd311830e102a1bfeeba extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8b723568c0a315ed1b3575e8a857e807fcac3e1990e30f09c869014787a7615c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8b723568c0a315ed1b3575e8a857e807fcac3e1990e30f09c869014787a7615c->enter($__internal_8b723568c0a315ed1b3575e8a857e807fcac3e1990e30f09c869014787a7615c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        $__internal_a786f210f4f2712befd90c4f827fc223a37817c69e06b9e5164d3c988123102d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a786f210f4f2712befd90c4f827fc223a37817c69e06b9e5164d3c988123102d->enter($__internal_a786f210f4f2712befd90c4f827fc223a37817c69e06b9e5164d3c988123102d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.rdf.twig", 1)->display($context);
        
        $__internal_8b723568c0a315ed1b3575e8a857e807fcac3e1990e30f09c869014787a7615c->leave($__internal_8b723568c0a315ed1b3575e8a857e807fcac3e1990e30f09c869014787a7615c_prof);

        
        $__internal_a786f210f4f2712befd90c4f827fc223a37817c69e06b9e5164d3c988123102d->leave($__internal_a786f210f4f2712befd90c4f827fc223a37817c69e06b9e5164d3c988123102d_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.rdf.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/error.xml.twig' %}
", "TwigBundle:Exception:error.rdf.twig", "C:\\wamp64\\www\\appli-era\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.rdf.twig");
    }
}
