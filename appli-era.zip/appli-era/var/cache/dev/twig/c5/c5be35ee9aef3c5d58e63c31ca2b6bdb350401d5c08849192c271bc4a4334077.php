<?php

/* TwigBundle:Exception:exception.json.twig */
class __TwigTemplate_2e89820d082dacb7436a4f5257153955b82787f5da4deb67f71b751e6bae902c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a96a2f98cb75b63378e3058a94e1c7ad3dcba1c471a78613aafc1b46a6c3cc9a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a96a2f98cb75b63378e3058a94e1c7ad3dcba1c471a78613aafc1b46a6c3cc9a->enter($__internal_a96a2f98cb75b63378e3058a94e1c7ad3dcba1c471a78613aafc1b46a6c3cc9a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.json.twig"));

        $__internal_3ec088ff2986d134a8c370a1913b2a3e3cd6f4e0c4603aaff9ba5d60d2f00a90 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3ec088ff2986d134a8c370a1913b2a3e3cd6f4e0c4603aaff9ba5d60d2f00a90->enter($__internal_3ec088ff2986d134a8c370a1913b2a3e3cd6f4e0c4603aaff9ba5d60d2f00a90_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => ($context["status_code"] ?? $this->getContext($context, "status_code")), "message" => ($context["status_text"] ?? $this->getContext($context, "status_text")), "exception" => $this->getAttribute(($context["exception"] ?? $this->getContext($context, "exception")), "toarray", array()))));
        echo "
";
        
        $__internal_a96a2f98cb75b63378e3058a94e1c7ad3dcba1c471a78613aafc1b46a6c3cc9a->leave($__internal_a96a2f98cb75b63378e3058a94e1c7ad3dcba1c471a78613aafc1b46a6c3cc9a_prof);

        
        $__internal_3ec088ff2986d134a8c370a1913b2a3e3cd6f4e0c4603aaff9ba5d60d2f00a90->leave($__internal_3ec088ff2986d134a8c370a1913b2a3e3cd6f4e0c4603aaff9ba5d60d2f00a90_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ { 'error': { 'code': status_code, 'message': status_text, 'exception': exception.toarray } }|json_encode|raw }}
", "TwigBundle:Exception:exception.json.twig", "C:\\wamp64\\www\\appli-era\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/exception.json.twig");
    }
}
