<?php

/* @Twig/Exception/error.atom.twig */
class __TwigTemplate_821fe71f6b611b36aeb9f4dc4bf6e1b91656da10c9e3660b6a02316e0bcfca30 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b1a468e6d32d7777a87d18066ffa6b9c10b9c2d7dd2c82f0894ae20e5cddf86b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b1a468e6d32d7777a87d18066ffa6b9c10b9c2d7dd2c82f0894ae20e5cddf86b->enter($__internal_b1a468e6d32d7777a87d18066ffa6b9c10b9c2d7dd2c82f0894ae20e5cddf86b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.atom.twig"));

        $__internal_4306ed1c93eec9a3b2eae93b64578d411e6543c6ceb52af92b7454a4e4a4df3d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4306ed1c93eec9a3b2eae93b64578d411e6543c6ceb52af92b7454a4e4a4df3d->enter($__internal_4306ed1c93eec9a3b2eae93b64578d411e6543c6ceb52af92b7454a4e4a4df3d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "@Twig/Exception/error.atom.twig", 1)->display($context);
        
        $__internal_b1a468e6d32d7777a87d18066ffa6b9c10b9c2d7dd2c82f0894ae20e5cddf86b->leave($__internal_b1a468e6d32d7777a87d18066ffa6b9c10b9c2d7dd2c82f0894ae20e5cddf86b_prof);

        
        $__internal_4306ed1c93eec9a3b2eae93b64578d411e6543c6ceb52af92b7454a4e4a4df3d->leave($__internal_4306ed1c93eec9a3b2eae93b64578d411e6543c6ceb52af92b7454a4e4a4df3d_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.atom.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/error.xml.twig' %}
", "@Twig/Exception/error.atom.twig", "C:\\wamp64\\www\\appli-era\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.atom.twig");
    }
}
