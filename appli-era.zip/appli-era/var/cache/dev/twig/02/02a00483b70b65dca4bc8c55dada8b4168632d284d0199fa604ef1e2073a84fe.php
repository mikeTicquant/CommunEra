<?php

/* @Twig/Exception/error.rdf.twig */
class __TwigTemplate_e7540d81a0e2a51f719f2be6c96bcbe60caad8cc1a0ee074d0b04f979bd7d8cb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_15632b5ae4d2166789ace6b16652392ba8ecfe3888e1ca9b73b6c052e571f570 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_15632b5ae4d2166789ace6b16652392ba8ecfe3888e1ca9b73b6c052e571f570->enter($__internal_15632b5ae4d2166789ace6b16652392ba8ecfe3888e1ca9b73b6c052e571f570_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.rdf.twig"));

        $__internal_c100d5d3d04da3d8797efa22ffb682fbfb4173dbecc223399f501548a759a3ec = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c100d5d3d04da3d8797efa22ffb682fbfb4173dbecc223399f501548a759a3ec->enter($__internal_c100d5d3d04da3d8797efa22ffb682fbfb4173dbecc223399f501548a759a3ec_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "@Twig/Exception/error.rdf.twig", 1)->display($context);
        
        $__internal_15632b5ae4d2166789ace6b16652392ba8ecfe3888e1ca9b73b6c052e571f570->leave($__internal_15632b5ae4d2166789ace6b16652392ba8ecfe3888e1ca9b73b6c052e571f570_prof);

        
        $__internal_c100d5d3d04da3d8797efa22ffb682fbfb4173dbecc223399f501548a759a3ec->leave($__internal_c100d5d3d04da3d8797efa22ffb682fbfb4173dbecc223399f501548a759a3ec_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.rdf.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/error.xml.twig' %}
", "@Twig/Exception/error.rdf.twig", "C:\\wamp64\\www\\appli-era\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.rdf.twig");
    }
}
