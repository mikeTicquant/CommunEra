<?php

/* @Framework/Form/container_attributes.html.php */
class __TwigTemplate_54afc722913edc0b9b10153ad5d267b89b6f693962210995e8e8f65daac51f3a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8a17d1b591da95de3820b6a3853beb671c653bb5d6e53c15b609d4f8a4c7c6d3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8a17d1b591da95de3820b6a3853beb671c653bb5d6e53c15b609d4f8a4c7c6d3->enter($__internal_8a17d1b591da95de3820b6a3853beb671c653bb5d6e53c15b609d4f8a4c7c6d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        $__internal_10804a14072fcfee50867244fdb5bb0db138e18b4fd648dad71a16a562a96018 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_10804a14072fcfee50867244fdb5bb0db138e18b4fd648dad71a16a562a96018->enter($__internal_10804a14072fcfee50867244fdb5bb0db138e18b4fd648dad71a16a562a96018_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
";
        
        $__internal_8a17d1b591da95de3820b6a3853beb671c653bb5d6e53c15b609d4f8a4c7c6d3->leave($__internal_8a17d1b591da95de3820b6a3853beb671c653bb5d6e53c15b609d4f8a4c7c6d3_prof);

        
        $__internal_10804a14072fcfee50867244fdb5bb0db138e18b4fd648dad71a16a562a96018->leave($__internal_10804a14072fcfee50867244fdb5bb0db138e18b4fd648dad71a16a562a96018_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
", "@Framework/Form/container_attributes.html.php", "C:\\wamp64\\www\\appli-era\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\container_attributes.html.php");
    }
}
