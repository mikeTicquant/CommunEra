<?php

/* admin/_nav_admin.html.twig */
class __TwigTemplate_cbc92b02afd6be43e56fcbed061d27bb2a8db4f3aaf24672220c06ee394686a8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_15f9306191004326e034956492c4a25575005656dd10d91b3f59813ea1228315 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_15f9306191004326e034956492c4a25575005656dd10d91b3f59813ea1228315->enter($__internal_15f9306191004326e034956492c4a25575005656dd10d91b3f59813ea1228315_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/_nav_admin.html.twig"));

        $__internal_eeff253c94a69e82934597d4e4c589bc9ac54cca272ae27ffdafaed4a92af6ee = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eeff253c94a69e82934597d4e4c589bc9ac54cca272ae27ffdafaed4a92af6ee->enter($__internal_eeff253c94a69e82934597d4e4c589bc9ac54cca272ae27ffdafaed4a92af6ee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/_nav_admin.html.twig"));

        // line 1
        echo "<!--=== Header v3 ===-->
<div class=\"header-v3 header-sticky\">
    <!-- Navbar -->
    <div class=\"navbar navbar-default mega-menu\" role=\"navigation\">
        <div class=\"container\">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class=\"navbar-header\">
                <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-responsive-collapse\">
                    <span class=\"sr-only\">Toggle navigation</span>
                    <span class=\"fa fa-bars\"></span>
                </button>
                <a class=\"navbar-brand\" href=\"#\">
                    <img id=\"logo-header\" src=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/img/logo.JPG"), "html", null, true);
        echo "\" alt=\"Logo\">
                </a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class=\"collapse navbar-collapse mega-menu navbar-responsive-collapse\">
                <div class=\"container\">
                    <ul class=\"nav navbar-nav navbar-left\">



                        <!-- TABLEAU DE BORD -->
                        <li><a href=\"#\">TABLEAU DE BORD</a></li>
                        <!-- End TABLEAU DE BORD -->


                        <!-- ADMINISTRATION -->
                        <li class=\"dropdown mega-menu-fullwidth\">
                            <a href=\"javascript:void(0);\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">
                                Administration
                            </a>
                            <ul class=\"dropdown-menu\">
                                <li>
                                    <div class=\"mega-menu-content disable-icons\">
                                        <div class=\"container\">
                                            <div class=\"row equal-height\">
                                                <div class=\"col-md-3 equal-height-in\">
                                                    <ul class=\"list-unstyled equal-height-list\">
                                                        <li><h3>Utilisateurs</h3></li>

                                                        <!-- Utilisateurs -->
                                                        <li><a href=\"#\"><i class=\"fa fa-fw fa-globe\"></i> Réseaux</a></li>
                                                        <li><a href=\"#\"><i class=\"fa fa-fw fa-building-o\"></i> Cda</a></li>
                                                        <li><a href=\"#\"><i class=\"fa fa-fw fa-trash\"></i> Groupe d'agences</a></li>
                                                        <li><a href=\"#\"><i class=\"fa fa-fw fa-bank\"></i> Agences</a></li>
                                                        <li><a href=\"#\"><i class=\"fa fa-fw fa-user-plus\"></i> Négociateurs</a></li>
                                                        <li><a href=\"#\"><i class=\"fa fa-fw fa-building\"></i> Entreprises</a></li>
                                                        <li><a href=\"";
        // line 50
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_admin_user_index");
        echo "\"><i class=\"fa fa-fw fa-users\"></i> Utilisateurs</a></li>

                                                        <!-- End Utilisateurs -->

                                                    </ul>
                                                </div>
                                                <div class=\"col-md-3 equal-height-in\">
                                                    <ul class=\"list-unstyled equal-height-list\">
                                                        <li><h3>APPLICATION</h3></li>

                                                        <!-- APPLICATION -->
                                                        <li><a href=\"#\"><i class=\"fa fa-fw fa-commenting-o\"></i> Témoignages</a></li>
                                                        <li><a href=\"#\"><i class=\"fa fa-fw fa-cogs\"></i> Paramètres</a></li>
                                                        <!-- End APPLICATION -->

                                                    </ul>
                                                </div>
                                                <div class=\"col-md-3 equal-height-in\">
                                                    <ul class=\"list-unstyled equal-height-list\">
                                                        <li><h3>CONTENU DU SITE</h3></li>

                                                        <!-- CONTENU DU SITE -->
                                                        <li><a href=\"#\"><i class=\"fa fa-image\"></i> Actions</a></li>
                                                        <li><a href=\"#\"><i class=\"fa fa-list-ol\"></i> Catégories</a></li>
                                                        <!-- End CONTENU DU SITE -->
                                                    </ul>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </li>
                        <!-- End ADMINISTRATION -->

                        <!-- NOTIFICATION -->
                        <li><a href=\"#\">NOTIFICATION</a></li>
                        <!-- End NOTIFICATION -->


                    </ul>
                    <ul class=\"nav navbar-nav navbar-right\">

                        <li class=\"dropdown account-dropdown\">
                            <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\">
                                Compte
                            </a>

                            <ul class=\"dropdown-menu\">
                                <li><a href=\"#\"><i class=\"fa fa-cogs fa-fw\"></i> Administration</a></li>
                                <li><a href=\"#\"><i class=\"fa fa-user fa-fw\"></i> Mon profil</a></li>
                                <li><a href=\"";
        // line 102
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("logout");
        echo "\"><i class=\"fa fa-power-off fa-fw\"></i> Déconnexion</a></li>
                            </ul>
                        </li>

                    </ul>

                </div><!--/end container-->
            </div><!--/navbar-collapse-->
        </div>
    </div>
    <!-- End Navbar -->
</div>
<!--=== End Header v3 ===-->";
        
        $__internal_15f9306191004326e034956492c4a25575005656dd10d91b3f59813ea1228315->leave($__internal_15f9306191004326e034956492c4a25575005656dd10d91b3f59813ea1228315_prof);

        
        $__internal_eeff253c94a69e82934597d4e4c589bc9ac54cca272ae27ffdafaed4a92af6ee->leave($__internal_eeff253c94a69e82934597d4e4c589bc9ac54cca272ae27ffdafaed4a92af6ee_prof);

    }

    public function getTemplateName()
    {
        return "admin/_nav_admin.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  134 => 102,  79 => 50,  39 => 13,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!--=== Header v3 ===-->
<div class=\"header-v3 header-sticky\">
    <!-- Navbar -->
    <div class=\"navbar navbar-default mega-menu\" role=\"navigation\">
        <div class=\"container\">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class=\"navbar-header\">
                <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-responsive-collapse\">
                    <span class=\"sr-only\">Toggle navigation</span>
                    <span class=\"fa fa-bars\"></span>
                </button>
                <a class=\"navbar-brand\" href=\"#\">
                    <img id=\"logo-header\" src=\"{{ asset('assets/img/logo.JPG') }}\" alt=\"Logo\">
                </a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class=\"collapse navbar-collapse mega-menu navbar-responsive-collapse\">
                <div class=\"container\">
                    <ul class=\"nav navbar-nav navbar-left\">



                        <!-- TABLEAU DE BORD -->
                        <li><a href=\"#\">TABLEAU DE BORD</a></li>
                        <!-- End TABLEAU DE BORD -->


                        <!-- ADMINISTRATION -->
                        <li class=\"dropdown mega-menu-fullwidth\">
                            <a href=\"javascript:void(0);\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">
                                Administration
                            </a>
                            <ul class=\"dropdown-menu\">
                                <li>
                                    <div class=\"mega-menu-content disable-icons\">
                                        <div class=\"container\">
                                            <div class=\"row equal-height\">
                                                <div class=\"col-md-3 equal-height-in\">
                                                    <ul class=\"list-unstyled equal-height-list\">
                                                        <li><h3>Utilisateurs</h3></li>

                                                        <!-- Utilisateurs -->
                                                        <li><a href=\"#\"><i class=\"fa fa-fw fa-globe\"></i> Réseaux</a></li>
                                                        <li><a href=\"#\"><i class=\"fa fa-fw fa-building-o\"></i> Cda</a></li>
                                                        <li><a href=\"#\"><i class=\"fa fa-fw fa-trash\"></i> Groupe d'agences</a></li>
                                                        <li><a href=\"#\"><i class=\"fa fa-fw fa-bank\"></i> Agences</a></li>
                                                        <li><a href=\"#\"><i class=\"fa fa-fw fa-user-plus\"></i> Négociateurs</a></li>
                                                        <li><a href=\"#\"><i class=\"fa fa-fw fa-building\"></i> Entreprises</a></li>
                                                        <li><a href=\"{{ path('app_admin_user_index') }}\"><i class=\"fa fa-fw fa-users\"></i> Utilisateurs</a></li>

                                                        <!-- End Utilisateurs -->

                                                    </ul>
                                                </div>
                                                <div class=\"col-md-3 equal-height-in\">
                                                    <ul class=\"list-unstyled equal-height-list\">
                                                        <li><h3>APPLICATION</h3></li>

                                                        <!-- APPLICATION -->
                                                        <li><a href=\"#\"><i class=\"fa fa-fw fa-commenting-o\"></i> Témoignages</a></li>
                                                        <li><a href=\"#\"><i class=\"fa fa-fw fa-cogs\"></i> Paramètres</a></li>
                                                        <!-- End APPLICATION -->

                                                    </ul>
                                                </div>
                                                <div class=\"col-md-3 equal-height-in\">
                                                    <ul class=\"list-unstyled equal-height-list\">
                                                        <li><h3>CONTENU DU SITE</h3></li>

                                                        <!-- CONTENU DU SITE -->
                                                        <li><a href=\"#\"><i class=\"fa fa-image\"></i> Actions</a></li>
                                                        <li><a href=\"#\"><i class=\"fa fa-list-ol\"></i> Catégories</a></li>
                                                        <!-- End CONTENU DU SITE -->
                                                    </ul>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </li>
                        <!-- End ADMINISTRATION -->

                        <!-- NOTIFICATION -->
                        <li><a href=\"#\">NOTIFICATION</a></li>
                        <!-- End NOTIFICATION -->


                    </ul>
                    <ul class=\"nav navbar-nav navbar-right\">

                        <li class=\"dropdown account-dropdown\">
                            <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\">
                                Compte
                            </a>

                            <ul class=\"dropdown-menu\">
                                <li><a href=\"#\"><i class=\"fa fa-cogs fa-fw\"></i> Administration</a></li>
                                <li><a href=\"#\"><i class=\"fa fa-user fa-fw\"></i> Mon profil</a></li>
                                <li><a href=\"{{ path('logout') }}\"><i class=\"fa fa-power-off fa-fw\"></i> Déconnexion</a></li>
                            </ul>
                        </li>

                    </ul>

                </div><!--/end container-->
            </div><!--/navbar-collapse-->
        </div>
    </div>
    <!-- End Navbar -->
</div>
<!--=== End Header v3 ===-->", "admin/_nav_admin.html.twig", "C:\\wamp64\\www\\appli-era\\app\\Resources\\views\\admin\\_nav_admin.html.twig");
    }
}
