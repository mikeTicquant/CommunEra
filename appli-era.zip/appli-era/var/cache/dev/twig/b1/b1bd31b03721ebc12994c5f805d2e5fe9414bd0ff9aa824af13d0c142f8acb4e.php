<?php

/* @Framework/Form/url_widget.html.php */
class __TwigTemplate_e3dd3fcec98b9598adbbda2902b15ece9856c667421bac9f24eff70e939156bf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_54882de711bc3ac518990ccdf4b5ab374dbef376f7219461f9a90ef587cd4a91 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_54882de711bc3ac518990ccdf4b5ab374dbef376f7219461f9a90ef587cd4a91->enter($__internal_54882de711bc3ac518990ccdf4b5ab374dbef376f7219461f9a90ef587cd4a91_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/url_widget.html.php"));

        $__internal_bd6ebe66911d6be53a8752cf0eb2213a919fb95b77bd8a193490c475eab17643 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bd6ebe66911d6be53a8752cf0eb2213a919fb95b77bd8a193490c475eab17643->enter($__internal_bd6ebe66911d6be53a8752cf0eb2213a919fb95b77bd8a193490c475eab17643_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/url_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'url')) ?>
";
        
        $__internal_54882de711bc3ac518990ccdf4b5ab374dbef376f7219461f9a90ef587cd4a91->leave($__internal_54882de711bc3ac518990ccdf4b5ab374dbef376f7219461f9a90ef587cd4a91_prof);

        
        $__internal_bd6ebe66911d6be53a8752cf0eb2213a919fb95b77bd8a193490c475eab17643->leave($__internal_bd6ebe66911d6be53a8752cf0eb2213a919fb95b77bd8a193490c475eab17643_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/url_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'url')) ?>
", "@Framework/Form/url_widget.html.php", "C:\\wamp64\\www\\appli-era\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\url_widget.html.php");
    }
}
