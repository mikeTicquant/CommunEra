<?php

/* admin/user/create.html.twig */
class __TwigTemplate_81378aee172cccd897559d262d4db5b4176aaf5b33de8f3563207aa8ceccc231 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("admin/base_admin.html.twig", "admin/user/create.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "admin/base_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d97b2ee406d4e25e262fca794f7193e0c50e352f229b6b6a9a51b9d8a2c4b126 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d97b2ee406d4e25e262fca794f7193e0c50e352f229b6b6a9a51b9d8a2c4b126->enter($__internal_d97b2ee406d4e25e262fca794f7193e0c50e352f229b6b6a9a51b9d8a2c4b126_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/user/create.html.twig"));

        $__internal_186a331c17a19424aa5797d343ff5009bc20ad9b70a0d08bf537801ff27dfa29 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_186a331c17a19424aa5797d343ff5009bc20ad9b70a0d08bf537801ff27dfa29->enter($__internal_186a331c17a19424aa5797d343ff5009bc20ad9b70a0d08bf537801ff27dfa29_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/user/create.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d97b2ee406d4e25e262fca794f7193e0c50e352f229b6b6a9a51b9d8a2c4b126->leave($__internal_d97b2ee406d4e25e262fca794f7193e0c50e352f229b6b6a9a51b9d8a2c4b126_prof);

        
        $__internal_186a331c17a19424aa5797d343ff5009bc20ad9b70a0d08bf537801ff27dfa29->leave($__internal_186a331c17a19424aa5797d343ff5009bc20ad9b70a0d08bf537801ff27dfa29_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_adecc41ef365c1e003aac16dc6f42f054d2c7090c4eb9b500f23b52a6a0704b9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_adecc41ef365c1e003aac16dc6f42f054d2c7090c4eb9b500f23b52a6a0704b9->enter($__internal_adecc41ef365c1e003aac16dc6f42f054d2c7090c4eb9b500f23b52a6a0704b9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_0ddaefcaf1cbab74296f50e11bb100ac7cf5a7d4c90948d04dff2b86aafa16d4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0ddaefcaf1cbab74296f50e11bb100ac7cf5a7d4c90948d04dff2b86aafa16d4->enter($__internal_0ddaefcaf1cbab74296f50e11bb100ac7cf5a7d4c90948d04dff2b86aafa16d4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1 class=\"text-center text-uppercase\">";
        echo (($this->getAttribute(($context["user"] ?? $this->getContext($context, "user")), "id", array())) ? ("Modifier un utilisateur") : ("Créer un utilisateur"));
        echo "</h1>
    <div class=\"row\">
        <div class=\"col-xs-12 col-md-6 col-md-offset-3\">
            ";
        // line 7
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start', array("attr" => array("novalidate" => "novalidate")));
        echo "
            ";
        // line 8
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        echo "
            <button class=\"btn btn-block ";
        // line 9
        echo (($this->getAttribute(($context["user"] ?? $this->getContext($context, "user")), "id", array())) ? ("btn-warning") : ("btn-success"));
        echo "\" type=\"submit\">
                ";
        // line 10
        echo (($this->getAttribute(($context["user"] ?? $this->getContext($context, "user")), "id", array())) ? ("Modifier") : ("Créer"));
        echo "
            </button>
            ";
        // line 12
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        echo "
        </div>
    </div>
";
        
        $__internal_0ddaefcaf1cbab74296f50e11bb100ac7cf5a7d4c90948d04dff2b86aafa16d4->leave($__internal_0ddaefcaf1cbab74296f50e11bb100ac7cf5a7d4c90948d04dff2b86aafa16d4_prof);

        
        $__internal_adecc41ef365c1e003aac16dc6f42f054d2c7090c4eb9b500f23b52a6a0704b9->leave($__internal_adecc41ef365c1e003aac16dc6f42f054d2c7090c4eb9b500f23b52a6a0704b9_prof);

    }

    public function getTemplateName()
    {
        return "admin/user/create.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 12,  68 => 10,  64 => 9,  60 => 8,  56 => 7,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'admin/base_admin.html.twig' %}

{% block body %}
    <h1 class=\"text-center text-uppercase\">{{ user.id ? 'Modifier un utilisateur' : 'Créer un utilisateur' }}</h1>
    <div class=\"row\">
        <div class=\"col-xs-12 col-md-6 col-md-offset-3\">
            {{ form_start(form,{attr:{novalidate:'novalidate'}}) }}
            {{ form_widget(form) }}
            <button class=\"btn btn-block {{ user.id ? 'btn-warning' : 'btn-success' }}\" type=\"submit\">
                {{ user.id ? 'Modifier' : 'Créer' }}
            </button>
            {{ form_end(form) }}
        </div>
    </div>
{% endblock %}
", "admin/user/create.html.twig", "C:\\wamp64\\www\\appli-era\\app\\Resources\\views\\admin\\user\\create.html.twig");
    }
}
