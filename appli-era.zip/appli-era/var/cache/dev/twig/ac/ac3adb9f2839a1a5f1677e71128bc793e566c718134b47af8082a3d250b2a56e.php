<?php

/* :user:profile.html.twig */
class __TwigTemplate_0d245fb777a2f2b82fb6c1dbbfd2eb465e877d6ee5186e8d19724add785e4647 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":user:profile.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dc37faaebcf721f314d82d22ed86769e16c2682986936d0055edd208321524cf = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dc37faaebcf721f314d82d22ed86769e16c2682986936d0055edd208321524cf->enter($__internal_dc37faaebcf721f314d82d22ed86769e16c2682986936d0055edd208321524cf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":user:profile.html.twig"));

        $__internal_8ddf0c2b4c63debd26f6ba4ea81e8db5fd427a849c46c3f971855f413e79aea3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8ddf0c2b4c63debd26f6ba4ea81e8db5fd427a849c46c3f971855f413e79aea3->enter($__internal_8ddf0c2b4c63debd26f6ba4ea81e8db5fd427a849c46c3f971855f413e79aea3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":user:profile.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_dc37faaebcf721f314d82d22ed86769e16c2682986936d0055edd208321524cf->leave($__internal_dc37faaebcf721f314d82d22ed86769e16c2682986936d0055edd208321524cf_prof);

        
        $__internal_8ddf0c2b4c63debd26f6ba4ea81e8db5fd427a849c46c3f971855f413e79aea3->leave($__internal_8ddf0c2b4c63debd26f6ba4ea81e8db5fd427a849c46c3f971855f413e79aea3_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_44f4ab68d3f23c21406a6784d4b6de163babcfae14683751522a176e0df0cede = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_44f4ab68d3f23c21406a6784d4b6de163babcfae14683751522a176e0df0cede->enter($__internal_44f4ab68d3f23c21406a6784d4b6de163babcfae14683751522a176e0df0cede_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_7e523d8847fd03a2cba47f0a38256c84716958126b5beb2020c8c163d3abf1cf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7e523d8847fd03a2cba47f0a38256c84716958126b5beb2020c8c163d3abf1cf->enter($__internal_7e523d8847fd03a2cba47f0a38256c84716958126b5beb2020c8c163d3abf1cf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "
    <div class=\"container content profile\">
        <div class=\"row\">
            <!--Left Sidebar-->
            <div class=\"col-md-3 md-margin-bottom-40\">

                ";
        // line 11
        $context["filename"] = (($this->getAttribute($this->getAttribute(($context["app"] ?? null), "user", array(), "any", false, true), "photo", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute($this->getAttribute(($context["app"] ?? null), "user", array(), "any", false, true), "photo", array()), "img32-md.jpg")) : ("img32-md.jpg"));
        // line 12
        echo "                ";
        $context["url"] = ((($context["globalUserPhotoUri"] ?? $this->getContext($context, "globalUserPhotoUri")) . "/") . ($context["filename"] ?? $this->getContext($context, "filename")));
        // line 13
        echo "                <img class=\"img-thumbnail\" id=\"photo\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl(($context["url"] ?? $this->getContext($context, "url"))), "html", null, true);
        echo "\"/>
                <br><br>
                <ul class=\"list-group sidebar-nav-v1 margin-bottom-40\" id=\"sidebar-nav-1\">
                    <li class=\"list-group-item active\">
                        <a href=\"#\"><i class=\"fa fa-bar-chart-o\"></i> Tableau de bord</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"";
        // line 20
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_profil");
        echo "\"><i class=\"fa fa-user\"></i> Profil</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"";
        // line 23
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_addreseau");
        echo "\"><i class=\"fa fa-group\"></i> Reseau</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_addreseau");
        echo "\"><i class=\"fa fa-group\"></i> Cda</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_addreseau");
        echo "\"><i class=\"fa fa-group\"></i> Agence</a>
                    </li>

                    <li class=\"list-group-item\">
                        <a href=\"#\"><i class=\"fa fa-cog\"></i> Settings</a>
                    </li>
                </ul>

            </div>
            <!--End Left Sidebar-->

            <!-- Profile Content -->
            <div class=\"col-md-9\">
                <div class=\"profile-body margin-bottom-20\">
                    <div class=\"tab-v1\">
                        <ul class=\"nav nav-justified nav-tabs\">
                            <li class=\"active\"><a data-toggle=\"tab\" href=\"#myprofile\">Mon Profil</a></li>
                            <li><a data-toggle=\"tab\" href=\"#profile\">Modifier Profil</a></li>
                            <li><a data-toggle=\"tab\" href=\"#passwordTab\">Changer Password</a></li>
                            <li><a data-toggle=\"tab\" href=\"#settings\">Notifications Settings</a></li>
                        </ul>
                        <div class=\"tab-content\">
                            <div id=\"myprofile\" class=\"profile-edit tab-pane fade in active\">


                                ";
        // line 54
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["users"] ?? $this->getContext($context, "users")));
        foreach ($context['_seq'] as $context["_key"] => $context["user"]) {
            // line 55
            echo "                                <dl class=\"dl-horizontal\">

                                    <dt><strong>Adresse e-mail </strong></dt>
                                    <dd>";
            // line 58
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "email", array()), "html", null, true);
            echo "</dd>
                                    <hr>

                                    <dt><strong>Civilité </strong></dt>
                                    <dd>";
            // line 62
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "civility", array()), "html", null, true);
            echo "</dd>
                                    <hr>

                                    <dt><strong>Nom </strong></dt>
                                    <dd>";
            // line 66
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "firstName", array()), "html", null, true);
            echo "</dd>
                                    <hr>

                                    <dt><strong>Prénom </strong></dt>
                                    <dd>";
            // line 70
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "lastName", array()), "html", null, true);
            echo "</dd>
                                    <hr>

                                    <dt><strong>Adresse personnelle </strong></dt>
                                    <dd>";
            // line 74
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "addressStreet", array()), "html", null, true);
            echo "</dd>
                                    <hr>

                                    <dt><strong>Ville </strong></dt>
                                    <dd>";
            // line 78
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "addressCity", array()), "html", null, true);
            echo "</dd>
                                    <hr>

                                    <dt><strong>Code postal </strong></dt>
                                    <dd>";
            // line 82
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "addressPostalCode", array()), "html", null, true);
            echo "</dd>
                                    <hr>

                                    <dt><strong>Type de comptes </strong></dt>
                                    <dd>";
            // line 86
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "role", array()), "html", null, true);
            echo "</dd>
                                    <hr>

                                    <dt><strong>Poste </strong></dt>
                                    <dd>";
            // line 90
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "job", array()), "html", null, true);
            echo "</dd>
                                    <hr>
                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['user'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 93
        echo "                                </dl>
                            </div>

                            <div id=\"profile\" class=\"profile-edit tab-pane\">
                                <h2 class=\"heading-md\">Mes coordonnées :</h2>
                                ";
        // line 98
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["formDetails"] ?? $this->getContext($context, "formDetails")), 'form_start', array("attr" => array("novalidate" => "novalidate")));
        echo "
                                ";
        // line 99
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["formDetails"] ?? $this->getContext($context, "formDetails")), 'form');
        echo "

                                <button type=\"submit\" class=\"btn-u\">Valider les modifications</button>
                                <button type=\"button\" class=\"btn-u btn-u-default\">Annuler</button>
                                ";
        // line 103
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["formDetails"] ?? $this->getContext($context, "formDetails")), 'form_end');
        echo "
                            </div>


                            <div id=\"passwordTab\" class=\"profile-edit tab-pane fade\">
                                <h2 class=\"heading-md\">Gestion de sécurité</h2>
                                <p>Modifier mon mot de passe.</p>
                                <br>
                                <form class=\"sky-form\" id=\"sky-form4\" action=\"#\">
                                    <dl class=\"dl-horizontal\">
                                        <dt>Username</dt>
                                        <dd>
                                            <section>
                                                <label class=\"input\">
                                                    <i class=\"icon-append fa fa-user\"></i>
                                                    <input type=\"text\" placeholder=\"Username\" name=\"username\">
                                                    <b class=\"tooltip tooltip-bottom-right\">Needed to enter the website</b>
                                                </label>
                                            </section>
                                        </dd>
                                        <dt>Adresse Email</dt>
                                        <dd>
                                            <section>
                                                <label class=\"input\">
                                                    <i class=\"icon-append fa fa-envelope\"></i>
                                                    <input type=\"email\" placeholder=\"Email address\" name=\"email\">
                                                    <b class=\"tooltip tooltip-bottom-right\">Needed to verify your account</b>
                                                </label>
                                            </section>
                                        </dd>
                                        <dt>Entrer votre mot de passe</dt>
                                        <dd>
                                            <section>
                                                <label class=\"input\">
                                                    <i class=\"icon-append fa fa-lock\"></i>
                                                    <input type=\"password\" id=\"password\" name=\"password\" placeholder=\"Password\">
                                                    <b class=\"tooltip tooltip-bottom-right\">Don't forget your password</b>
                                                </label>
                                            </section>
                                        </dd>
                                        <dt>Confirmer Mot de passe</dt>
                                        <dd>
                                            <section>
                                                <label class=\"input\">
                                                    <i class=\"icon-append fa fa-lock\"></i>
                                                    <input type=\"password\" name=\"passwordConfirm\" placeholder=\"Confirm password\">
                                                    <b class=\"tooltip tooltip-bottom-right\">Don't forget your password</b>
                                                </label>
                                            </section>
                                        </dd>
                                    </dl>

                                    <br>

                                    <button class=\"btn-u\" type=\"submit\">Valider les modifications</button>
                                    <button type=\"button\" class=\"btn-u btn-u-default\">Annuler</button>
                                </form>
                            </div>


                            <div id=\"settings\" class=\"profile-edit tab-pane fade\">
                                <h2 class=\"heading-md\">Gestion des Notifications.</h2>

                                <br>
                                <form class=\"sky-form\" id=\"sky-form3\" action=\"#\">
                                    <label class=\"toggle\"><input type=\"checkbox\" checked=\"\" name=\"checkbox-toggle-1\"><i class=\"no-rounded\"></i></label>
                                    <hr>
                                    <label class=\"toggle\"><input type=\"checkbox\" checked=\"\" name=\"checkbox-toggle-1\"><i class=\"no-rounded\"></i>Send me email notification when a user comments on my blog</label>
                                    <hr>
                                    <label class=\"toggle\"><input type=\"checkbox\" checked=\"\" name=\"checkbox-toggle-1\"><i class=\"no-rounded\"></i>Send me email notification for the latest update</label>
                                    <hr>
                                    <label class=\"toggle\"><input type=\"checkbox\" checked=\"\" name=\"checkbox-toggle-1\"><i class=\"no-rounded\"></i>Send me email notification when a user sends me message</label>
                                    <hr>
                                    <label class=\"toggle\"><input type=\"checkbox\" checked=\"\" name=\"checkbox-toggle-1\"><i class=\"no-rounded\"></i>Receive our monthly newsletter</label>
                                    <hr>
                                    <button class=\"btn-u\" type=\"submit\">Enregistrer les modification</button>
                                    <button type=\"button\" class=\"btn-u btn-u-default\">Annuler</button>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Profile Content -->
        </div><!--/end row-->
    </div>


";
        
        $__internal_7e523d8847fd03a2cba47f0a38256c84716958126b5beb2020c8c163d3abf1cf->leave($__internal_7e523d8847fd03a2cba47f0a38256c84716958126b5beb2020c8c163d3abf1cf_prof);

        
        $__internal_44f4ab68d3f23c21406a6784d4b6de163babcfae14683751522a176e0df0cede->leave($__internal_44f4ab68d3f23c21406a6784d4b6de163babcfae14683751522a176e0df0cede_prof);

    }

    public function getTemplateName()
    {
        return ":user:profile.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  211 => 103,  204 => 99,  200 => 98,  193 => 93,  184 => 90,  177 => 86,  170 => 82,  163 => 78,  156 => 74,  149 => 70,  142 => 66,  135 => 62,  128 => 58,  123 => 55,  119 => 54,  91 => 29,  85 => 26,  79 => 23,  73 => 20,  62 => 13,  59 => 12,  57 => 11,  49 => 5,  40 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}


{% block body %}

    <div class=\"container content profile\">
        <div class=\"row\">
            <!--Left Sidebar-->
            <div class=\"col-md-3 md-margin-bottom-40\">

                {% set filename = app.user.photo|default('img32-md.jpg') %}
                {% set url = globalUserPhotoUri ~ '/' ~ filename %}
                <img class=\"img-thumbnail\" id=\"photo\" src=\"{{ asset(url) }}\"/>
                <br><br>
                <ul class=\"list-group sidebar-nav-v1 margin-bottom-40\" id=\"sidebar-nav-1\">
                    <li class=\"list-group-item active\">
                        <a href=\"#\"><i class=\"fa fa-bar-chart-o\"></i> Tableau de bord</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"{{ path('app_user_user_profil') }}\"><i class=\"fa fa-user\"></i> Profil</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"{{ path('app_user_user_addreseau') }}\"><i class=\"fa fa-group\"></i> Reseau</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"{{ path('app_user_user_addreseau') }}\"><i class=\"fa fa-group\"></i> Cda</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"{{ path('app_user_user_addreseau') }}\"><i class=\"fa fa-group\"></i> Agence</a>
                    </li>

                    <li class=\"list-group-item\">
                        <a href=\"#\"><i class=\"fa fa-cog\"></i> Settings</a>
                    </li>
                </ul>

            </div>
            <!--End Left Sidebar-->

            <!-- Profile Content -->
            <div class=\"col-md-9\">
                <div class=\"profile-body margin-bottom-20\">
                    <div class=\"tab-v1\">
                        <ul class=\"nav nav-justified nav-tabs\">
                            <li class=\"active\"><a data-toggle=\"tab\" href=\"#myprofile\">Mon Profil</a></li>
                            <li><a data-toggle=\"tab\" href=\"#profile\">Modifier Profil</a></li>
                            <li><a data-toggle=\"tab\" href=\"#passwordTab\">Changer Password</a></li>
                            <li><a data-toggle=\"tab\" href=\"#settings\">Notifications Settings</a></li>
                        </ul>
                        <div class=\"tab-content\">
                            <div id=\"myprofile\" class=\"profile-edit tab-pane fade in active\">


                                {% for user in users %}
                                <dl class=\"dl-horizontal\">

                                    <dt><strong>Adresse e-mail </strong></dt>
                                    <dd>{{ user.email }}</dd>
                                    <hr>

                                    <dt><strong>Civilité </strong></dt>
                                    <dd>{{ user.civility }}</dd>
                                    <hr>

                                    <dt><strong>Nom </strong></dt>
                                    <dd>{{ user.firstName }}</dd>
                                    <hr>

                                    <dt><strong>Prénom </strong></dt>
                                    <dd>{{ user.lastName }}</dd>
                                    <hr>

                                    <dt><strong>Adresse personnelle </strong></dt>
                                    <dd>{{ user.addressStreet }}</dd>
                                    <hr>

                                    <dt><strong>Ville </strong></dt>
                                    <dd>{{ user.addressCity }}</dd>
                                    <hr>

                                    <dt><strong>Code postal </strong></dt>
                                    <dd>{{ user.addressPostalCode }}</dd>
                                    <hr>

                                    <dt><strong>Type de comptes </strong></dt>
                                    <dd>{{ user.role }}</dd>
                                    <hr>

                                    <dt><strong>Poste </strong></dt>
                                    <dd>{{ user.job }}</dd>
                                    <hr>
                                    {% endfor %}
                                </dl>
                            </div>

                            <div id=\"profile\" class=\"profile-edit tab-pane\">
                                <h2 class=\"heading-md\">Mes coordonnées :</h2>
                                {{ form_start(formDetails,{attr:{novalidate:'novalidate'}}) }}
                                {{ form(formDetails) }}

                                <button type=\"submit\" class=\"btn-u\">Valider les modifications</button>
                                <button type=\"button\" class=\"btn-u btn-u-default\">Annuler</button>
                                {{ form_end(formDetails) }}
                            </div>


                            <div id=\"passwordTab\" class=\"profile-edit tab-pane fade\">
                                <h2 class=\"heading-md\">Gestion de sécurité</h2>
                                <p>Modifier mon mot de passe.</p>
                                <br>
                                <form class=\"sky-form\" id=\"sky-form4\" action=\"#\">
                                    <dl class=\"dl-horizontal\">
                                        <dt>Username</dt>
                                        <dd>
                                            <section>
                                                <label class=\"input\">
                                                    <i class=\"icon-append fa fa-user\"></i>
                                                    <input type=\"text\" placeholder=\"Username\" name=\"username\">
                                                    <b class=\"tooltip tooltip-bottom-right\">Needed to enter the website</b>
                                                </label>
                                            </section>
                                        </dd>
                                        <dt>Adresse Email</dt>
                                        <dd>
                                            <section>
                                                <label class=\"input\">
                                                    <i class=\"icon-append fa fa-envelope\"></i>
                                                    <input type=\"email\" placeholder=\"Email address\" name=\"email\">
                                                    <b class=\"tooltip tooltip-bottom-right\">Needed to verify your account</b>
                                                </label>
                                            </section>
                                        </dd>
                                        <dt>Entrer votre mot de passe</dt>
                                        <dd>
                                            <section>
                                                <label class=\"input\">
                                                    <i class=\"icon-append fa fa-lock\"></i>
                                                    <input type=\"password\" id=\"password\" name=\"password\" placeholder=\"Password\">
                                                    <b class=\"tooltip tooltip-bottom-right\">Don't forget your password</b>
                                                </label>
                                            </section>
                                        </dd>
                                        <dt>Confirmer Mot de passe</dt>
                                        <dd>
                                            <section>
                                                <label class=\"input\">
                                                    <i class=\"icon-append fa fa-lock\"></i>
                                                    <input type=\"password\" name=\"passwordConfirm\" placeholder=\"Confirm password\">
                                                    <b class=\"tooltip tooltip-bottom-right\">Don't forget your password</b>
                                                </label>
                                            </section>
                                        </dd>
                                    </dl>

                                    <br>

                                    <button class=\"btn-u\" type=\"submit\">Valider les modifications</button>
                                    <button type=\"button\" class=\"btn-u btn-u-default\">Annuler</button>
                                </form>
                            </div>


                            <div id=\"settings\" class=\"profile-edit tab-pane fade\">
                                <h2 class=\"heading-md\">Gestion des Notifications.</h2>

                                <br>
                                <form class=\"sky-form\" id=\"sky-form3\" action=\"#\">
                                    <label class=\"toggle\"><input type=\"checkbox\" checked=\"\" name=\"checkbox-toggle-1\"><i class=\"no-rounded\"></i></label>
                                    <hr>
                                    <label class=\"toggle\"><input type=\"checkbox\" checked=\"\" name=\"checkbox-toggle-1\"><i class=\"no-rounded\"></i>Send me email notification when a user comments on my blog</label>
                                    <hr>
                                    <label class=\"toggle\"><input type=\"checkbox\" checked=\"\" name=\"checkbox-toggle-1\"><i class=\"no-rounded\"></i>Send me email notification for the latest update</label>
                                    <hr>
                                    <label class=\"toggle\"><input type=\"checkbox\" checked=\"\" name=\"checkbox-toggle-1\"><i class=\"no-rounded\"></i>Send me email notification when a user sends me message</label>
                                    <hr>
                                    <label class=\"toggle\"><input type=\"checkbox\" checked=\"\" name=\"checkbox-toggle-1\"><i class=\"no-rounded\"></i>Receive our monthly newsletter</label>
                                    <hr>
                                    <button class=\"btn-u\" type=\"submit\">Enregistrer les modification</button>
                                    <button type=\"button\" class=\"btn-u btn-u-default\">Annuler</button>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Profile Content -->
        </div><!--/end row-->
    </div>


{% endblock %}

", ":user:profile.html.twig", "C:\\wamp64\\www\\appli-era\\app/Resources\\views/user/profile.html.twig");
    }
}
