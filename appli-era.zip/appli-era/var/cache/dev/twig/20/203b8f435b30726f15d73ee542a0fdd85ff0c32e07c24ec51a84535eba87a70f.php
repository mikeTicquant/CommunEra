<?php

/* :grpagence:index.html.twig */
class __TwigTemplate_7a776741657e5245e62227be375c72aaa6b4443f2387bde0f4370ed5b363a3a8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":grpagence:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2595065e31bf7cd1b7ece6dfe4fab14bc711d9a715fdef16b6104cd6b2a3a420 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2595065e31bf7cd1b7ece6dfe4fab14bc711d9a715fdef16b6104cd6b2a3a420->enter($__internal_2595065e31bf7cd1b7ece6dfe4fab14bc711d9a715fdef16b6104cd6b2a3a420_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":grpagence:index.html.twig"));

        $__internal_bc869967fa4dfae113af202f4c2b9b68cd8699acbe931d8c5f6faa41afea647b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bc869967fa4dfae113af202f4c2b9b68cd8699acbe931d8c5f6faa41afea647b->enter($__internal_bc869967fa4dfae113af202f4c2b9b68cd8699acbe931d8c5f6faa41afea647b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":grpagence:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2595065e31bf7cd1b7ece6dfe4fab14bc711d9a715fdef16b6104cd6b2a3a420->leave($__internal_2595065e31bf7cd1b7ece6dfe4fab14bc711d9a715fdef16b6104cd6b2a3a420_prof);

        
        $__internal_bc869967fa4dfae113af202f4c2b9b68cd8699acbe931d8c5f6faa41afea647b->leave($__internal_bc869967fa4dfae113af202f4c2b9b68cd8699acbe931d8c5f6faa41afea647b_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_09ac94be930426e4246f6dca319e67311be2a4398aadb7f98b3168b187847ca2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_09ac94be930426e4246f6dca319e67311be2a4398aadb7f98b3168b187847ca2->enter($__internal_09ac94be930426e4246f6dca319e67311be2a4398aadb7f98b3168b187847ca2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_c5fefb27ba3bb06059c77494bd5cc8e3009c6c842a1300d22ddad7f72eb8c29f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c5fefb27ba3bb06059c77494bd5cc8e3009c6c842a1300d22ddad7f72eb8c29f->enter($__internal_c5fefb27ba3bb06059c77494bd5cc8e3009c6c842a1300d22ddad7f72eb8c29f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    <h1>Espace Groupe Agence</h1>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
";
        
        $__internal_c5fefb27ba3bb06059c77494bd5cc8e3009c6c842a1300d22ddad7f72eb8c29f->leave($__internal_c5fefb27ba3bb06059c77494bd5cc8e3009c6c842a1300d22ddad7f72eb8c29f_prof);

        
        $__internal_09ac94be930426e4246f6dca319e67311be2a4398aadb7f98b3168b187847ca2->leave($__internal_09ac94be930426e4246f6dca319e67311be2a4398aadb7f98b3168b187847ca2_prof);

    }

    public function getTemplateName()
    {
        return ":grpagence:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 3,  40 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block body %}
    <h1>Espace Groupe Agence</h1>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
{% endblock %}", ":grpagence:index.html.twig", "C:\\wamp64\\www\\appli-era\\app/Resources\\views/grpagence/index.html.twig");
    }
}
