<?php

/* @Framework/Form/form_row.html.php */
class __TwigTemplate_f678339ef624e0a41259bde234ed5b2a1c12f9e1b385bfb0965c06697d63feda extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4d98c6424edfc9f186727216cf9ed03cf50348c5e040fa8808837b1a22a6d668 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4d98c6424edfc9f186727216cf9ed03cf50348c5e040fa8808837b1a22a6d668->enter($__internal_4d98c6424edfc9f186727216cf9ed03cf50348c5e040fa8808837b1a22a6d668_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_row.html.php"));

        $__internal_f2ee30f55a0e324b4476f77f668e9b9c69f27912adbeea994a89276eed592b99 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f2ee30f55a0e324b4476f77f668e9b9c69f27912adbeea994a89276eed592b99->enter($__internal_f2ee30f55a0e324b4476f77f668e9b9c69f27912adbeea994a89276eed592b99_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_4d98c6424edfc9f186727216cf9ed03cf50348c5e040fa8808837b1a22a6d668->leave($__internal_4d98c6424edfc9f186727216cf9ed03cf50348c5e040fa8808837b1a22a6d668_prof);

        
        $__internal_f2ee30f55a0e324b4476f77f668e9b9c69f27912adbeea994a89276eed592b99->leave($__internal_f2ee30f55a0e324b4476f77f668e9b9c69f27912adbeea994a89276eed592b99_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
", "@Framework/Form/form_row.html.php", "C:\\wamp64\\www\\appli-era\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_row.html.php");
    }
}
