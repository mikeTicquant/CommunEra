<?php

/* @WebProfiler/Profiler/ajax_layout.html.twig */
class __TwigTemplate_66e8bae2ef0bd2c2153a91118f4d3f9ab9780394776fc2a701e2dabe733a3f1a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4587f007232794cf75a461e6575a35350eb701e4e17a688e4c44713324809816 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4587f007232794cf75a461e6575a35350eb701e4e17a688e4c44713324809816->enter($__internal_4587f007232794cf75a461e6575a35350eb701e4e17a688e4c44713324809816_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        $__internal_9f710966db12a2a2937bf02c57fb32f99cb10af586bf8e7c0885277c5b8fe71a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9f710966db12a2a2937bf02c57fb32f99cb10af586bf8e7c0885277c5b8fe71a->enter($__internal_9f710966db12a2a2937bf02c57fb32f99cb10af586bf8e7c0885277c5b8fe71a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_4587f007232794cf75a461e6575a35350eb701e4e17a688e4c44713324809816->leave($__internal_4587f007232794cf75a461e6575a35350eb701e4e17a688e4c44713324809816_prof);

        
        $__internal_9f710966db12a2a2937bf02c57fb32f99cb10af586bf8e7c0885277c5b8fe71a->leave($__internal_9f710966db12a2a2937bf02c57fb32f99cb10af586bf8e7c0885277c5b8fe71a_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_ad1023b362d7a8f8dd3c5a968e13955c1f9dc171c66bca837ccd6d0a8b3c8e10 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ad1023b362d7a8f8dd3c5a968e13955c1f9dc171c66bca837ccd6d0a8b3c8e10->enter($__internal_ad1023b362d7a8f8dd3c5a968e13955c1f9dc171c66bca837ccd6d0a8b3c8e10_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_a518552446a832235ae92bf654eba0248e8a038de6da3631ae49f0b5c53ac23f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a518552446a832235ae92bf654eba0248e8a038de6da3631ae49f0b5c53ac23f->enter($__internal_a518552446a832235ae92bf654eba0248e8a038de6da3631ae49f0b5c53ac23f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_a518552446a832235ae92bf654eba0248e8a038de6da3631ae49f0b5c53ac23f->leave($__internal_a518552446a832235ae92bf654eba0248e8a038de6da3631ae49f0b5c53ac23f_prof);

        
        $__internal_ad1023b362d7a8f8dd3c5a968e13955c1f9dc171c66bca837ccd6d0a8b3c8e10->leave($__internal_ad1023b362d7a8f8dd3c5a968e13955c1f9dc171c66bca837ccd6d0a8b3c8e10_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "@WebProfiler/Profiler/ajax_layout.html.twig", "C:\\wamp64\\www\\appli-era\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\ajax_layout.html.twig");
    }
}
