<?php

/* ::_flash.html.twig */
class __TwigTemplate_feeee7957d5260cca52da1687bce1796a7d7dcd77e7ba8e6654ae6f4b443154c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a41409cd6c1a07f1b4f911c2243a10b4f0057342aae63bbace2f2fbb8c90da36 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a41409cd6c1a07f1b4f911c2243a10b4f0057342aae63bbace2f2fbb8c90da36->enter($__internal_a41409cd6c1a07f1b4f911c2243a10b4f0057342aae63bbace2f2fbb8c90da36_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::_flash.html.twig"));

        $__internal_c017cbb333d07327f9cea8bc1eefc0c27bb9664ceeb4100e8d9bc0a12553b2ac = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c017cbb333d07327f9cea8bc1eefc0c27bb9664ceeb4100e8d9bc0a12553b2ac->enter($__internal_c017cbb333d07327f9cea8bc1eefc0c27bb9664ceeb4100e8d9bc0a12553b2ac_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::_flash.html.twig"));

        // line 1
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "session", array()), "flashBag", array()), "all", array(), "method"));
        foreach ($context['_seq'] as $context["type"] => $context["messages"]) {
            // line 2
            echo "    <div class=\"alert alert-";
            echo twig_escape_filter($this->env, $context["type"], "html", null, true);
            echo "\">
        ";
            // line 3
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($context["messages"]);
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
                // line 4
                echo "            ";
                echo twig_escape_filter($this->env, $context["message"], "html", null, true);
                echo "
            ";
                // line 5
                echo (( !$this->getAttribute($context["loop"], "last", array())) ? ("<br>") : (""));
                echo "
        ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 7
            echo "        <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-label=\"Close\">
            <span aria-hidden=\"true\">&times;</span>
        </button>
    </div>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['type'], $context['messages'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        
        $__internal_a41409cd6c1a07f1b4f911c2243a10b4f0057342aae63bbace2f2fbb8c90da36->leave($__internal_a41409cd6c1a07f1b4f911c2243a10b4f0057342aae63bbace2f2fbb8c90da36_prof);

        
        $__internal_c017cbb333d07327f9cea8bc1eefc0c27bb9664ceeb4100e8d9bc0a12553b2ac->leave($__internal_c017cbb333d07327f9cea8bc1eefc0c27bb9664ceeb4100e8d9bc0a12553b2ac_prof);

    }

    public function getTemplateName()
    {
        return "::_flash.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 7,  56 => 5,  51 => 4,  34 => 3,  29 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% for type,messages in app.session.flashBag.all() %}
    <div class=\"alert alert-{{ type }}\">
        {% for message in messages %}
            {{ message }}
            {{ not loop.last ? '<br>' }}
        {% endfor %}
        <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-label=\"Close\">
            <span aria-hidden=\"true\">&times;</span>
        </button>
    </div>
{% endfor %}", "::_flash.html.twig", "C:\\wamp64\\www\\appli-era\\app/Resources\\views/_flash.html.twig");
    }
}
