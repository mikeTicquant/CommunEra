<?php

/* @Framework/Form/textarea_widget.html.php */
class __TwigTemplate_899395eb8f93ff7f2bbf1989f52b4496c16e1665d2242bcf11bf7a06ecbaa275 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5cb7f264250ae841db891f98b40c060e6c0998ff69d8d325d320c1c124e2d1dd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5cb7f264250ae841db891f98b40c060e6c0998ff69d8d325d320c1c124e2d1dd->enter($__internal_5cb7f264250ae841db891f98b40c060e6c0998ff69d8d325d320c1c124e2d1dd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        $__internal_cc21481bfd75408337021a13944dd14cae3957584ccad4b6785c4e9fc33c9af9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cc21481bfd75408337021a13944dd14cae3957584ccad4b6785c4e9fc33c9af9->enter($__internal_cc21481bfd75408337021a13944dd14cae3957584ccad4b6785c4e9fc33c9af9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        // line 1
        echo "<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
";
        
        $__internal_5cb7f264250ae841db891f98b40c060e6c0998ff69d8d325d320c1c124e2d1dd->leave($__internal_5cb7f264250ae841db891f98b40c060e6c0998ff69d8d325d320c1c124e2d1dd_prof);

        
        $__internal_cc21481bfd75408337021a13944dd14cae3957584ccad4b6785c4e9fc33c9af9->leave($__internal_cc21481bfd75408337021a13944dd14cae3957584ccad4b6785c4e9fc33c9af9_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/textarea_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
", "@Framework/Form/textarea_widget.html.php", "C:\\wamp64\\www\\appli-era\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\textarea_widget.html.php");
    }
}
