<?php

/* WebProfilerBundle:Collector:exception.html.twig */
class __TwigTemplate_5145ff72f6a3e76e148ff39b58ac40e49140d53b1948a05da82a690f8b1e8636 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "WebProfilerBundle:Collector:exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d710b66f65ae5898389687b4c73c1882803254470c8e7ad6989959835e39a504 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d710b66f65ae5898389687b4c73c1882803254470c8e7ad6989959835e39a504->enter($__internal_d710b66f65ae5898389687b4c73c1882803254470c8e7ad6989959835e39a504_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:exception.html.twig"));

        $__internal_0de6b3346ed026e567933f54101488a9048503a80d499703b8f127c2760ca8af = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0de6b3346ed026e567933f54101488a9048503a80d499703b8f127c2760ca8af->enter($__internal_0de6b3346ed026e567933f54101488a9048503a80d499703b8f127c2760ca8af_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d710b66f65ae5898389687b4c73c1882803254470c8e7ad6989959835e39a504->leave($__internal_d710b66f65ae5898389687b4c73c1882803254470c8e7ad6989959835e39a504_prof);

        
        $__internal_0de6b3346ed026e567933f54101488a9048503a80d499703b8f127c2760ca8af->leave($__internal_0de6b3346ed026e567933f54101488a9048503a80d499703b8f127c2760ca8af_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_8cbba7bccecc09b1a0b92fd62c88898d1bcd1456492ce12e67bdce5acfd2dd5f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8cbba7bccecc09b1a0b92fd62c88898d1bcd1456492ce12e67bdce5acfd2dd5f->enter($__internal_8cbba7bccecc09b1a0b92fd62c88898d1bcd1456492ce12e67bdce5acfd2dd5f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_97ff4eb1e60d77990cae3b3e0e089c94a1d73321a74e0f41c5557874b5537924 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_97ff4eb1e60d77990cae3b3e0e089c94a1d73321a74e0f41c5557874b5537924->enter($__internal_97ff4eb1e60d77990cae3b3e0e089c94a1d73321a74e0f41c5557874b5537924_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_97ff4eb1e60d77990cae3b3e0e089c94a1d73321a74e0f41c5557874b5537924->leave($__internal_97ff4eb1e60d77990cae3b3e0e089c94a1d73321a74e0f41c5557874b5537924_prof);

        
        $__internal_8cbba7bccecc09b1a0b92fd62c88898d1bcd1456492ce12e67bdce5acfd2dd5f->leave($__internal_8cbba7bccecc09b1a0b92fd62c88898d1bcd1456492ce12e67bdce5acfd2dd5f_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_6dad3582d5ebde2392396eecd6aec50f452739b26a432c1c4e47ba8ee37ded21 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6dad3582d5ebde2392396eecd6aec50f452739b26a432c1c4e47ba8ee37ded21->enter($__internal_6dad3582d5ebde2392396eecd6aec50f452739b26a432c1c4e47ba8ee37ded21_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_eb09c3a247a242a5445e146bdd54b864dafb70c7372c8fcd7592a1ed6ce8fca3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eb09c3a247a242a5445e146bdd54b864dafb70c7372c8fcd7592a1ed6ce8fca3->enter($__internal_eb09c3a247a242a5445e146bdd54b864dafb70c7372c8fcd7592a1ed6ce8fca3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_eb09c3a247a242a5445e146bdd54b864dafb70c7372c8fcd7592a1ed6ce8fca3->leave($__internal_eb09c3a247a242a5445e146bdd54b864dafb70c7372c8fcd7592a1ed6ce8fca3_prof);

        
        $__internal_6dad3582d5ebde2392396eecd6aec50f452739b26a432c1c4e47ba8ee37ded21->leave($__internal_6dad3582d5ebde2392396eecd6aec50f452739b26a432c1c4e47ba8ee37ded21_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_9cf2839121f623e8fea4cf58a9c410c1d0648c5be6ac4c0186717e423e85f8c2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9cf2839121f623e8fea4cf58a9c410c1d0648c5be6ac4c0186717e423e85f8c2->enter($__internal_9cf2839121f623e8fea4cf58a9c410c1d0648c5be6ac4c0186717e423e85f8c2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_f9e8bf9d857025938bca26f6cf8b00465d2a720603de4792109ba23d8b7023d0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f9e8bf9d857025938bca26f6cf8b00465d2a720603de4792109ba23d8b7023d0->enter($__internal_f9e8bf9d857025938bca26f6cf8b00465d2a720603de4792109ba23d8b7023d0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_f9e8bf9d857025938bca26f6cf8b00465d2a720603de4792109ba23d8b7023d0->leave($__internal_f9e8bf9d857025938bca26f6cf8b00465d2a720603de4792109ba23d8b7023d0_prof);

        
        $__internal_9cf2839121f623e8fea4cf58a9c410c1d0648c5be6ac4c0186717e423e85f8c2->leave($__internal_9cf2839121f623e8fea4cf58a9c410c1d0648c5be6ac4c0186717e423e85f8c2_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Collector:exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "WebProfilerBundle:Collector:exception.html.twig", "C:\\wamp64\\www\\appli-era\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Collector/exception.html.twig");
    }
}
