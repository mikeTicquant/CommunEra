<?php

/* bootstrap_3_layout.html.twig */
class __TwigTemplate_9ac23d87c7061c256c94edbc4544067babc64fb9eb6c5d6555f0bc1cece426ad extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $_trait_0 = $this->loadTemplate("form_div_layout.html.twig", "bootstrap_3_layout.html.twig", 1);
        // line 1
        if (!$_trait_0->isTraitable()) {
            throw new Twig_Error_Runtime('Template "'."form_div_layout.html.twig".'" cannot be used as a trait.');
        }
        $_trait_0_blocks = $_trait_0->getBlocks();

        $this->traits = $_trait_0_blocks;

        $this->blocks = array_merge(
            $this->traits,
            array(
                'form_widget_simple' => array($this, 'block_form_widget_simple'),
                'textarea_widget' => array($this, 'block_textarea_widget'),
                'button_widget' => array($this, 'block_button_widget'),
                'money_widget' => array($this, 'block_money_widget'),
                'percent_widget' => array($this, 'block_percent_widget'),
                'datetime_widget' => array($this, 'block_datetime_widget'),
                'date_widget' => array($this, 'block_date_widget'),
                'time_widget' => array($this, 'block_time_widget'),
                'dateinterval_widget' => array($this, 'block_dateinterval_widget'),
                'choice_widget_collapsed' => array($this, 'block_choice_widget_collapsed'),
                'choice_widget_expanded' => array($this, 'block_choice_widget_expanded'),
                'checkbox_widget' => array($this, 'block_checkbox_widget'),
                'radio_widget' => array($this, 'block_radio_widget'),
                'form_label' => array($this, 'block_form_label'),
                'choice_label' => array($this, 'block_choice_label'),
                'checkbox_label' => array($this, 'block_checkbox_label'),
                'radio_label' => array($this, 'block_radio_label'),
                'checkbox_radio_label' => array($this, 'block_checkbox_radio_label'),
                'form_row' => array($this, 'block_form_row'),
                'button_row' => array($this, 'block_button_row'),
                'choice_row' => array($this, 'block_choice_row'),
                'date_row' => array($this, 'block_date_row'),
                'time_row' => array($this, 'block_time_row'),
                'datetime_row' => array($this, 'block_datetime_row'),
                'checkbox_row' => array($this, 'block_checkbox_row'),
                'radio_row' => array($this, 'block_radio_row'),
                'form_errors' => array($this, 'block_form_errors'),
            )
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_72b3840aaa4a3d2dc17dd289f828514bbbcab9a8901184a2d2333a56001cf03d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_72b3840aaa4a3d2dc17dd289f828514bbbcab9a8901184a2d2333a56001cf03d->enter($__internal_72b3840aaa4a3d2dc17dd289f828514bbbcab9a8901184a2d2333a56001cf03d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "bootstrap_3_layout.html.twig"));

        $__internal_7f7e50b491347bda96d57ada1964d25cd8510712866dacd804cba2da439594ef = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7f7e50b491347bda96d57ada1964d25cd8510712866dacd804cba2da439594ef->enter($__internal_7f7e50b491347bda96d57ada1964d25cd8510712866dacd804cba2da439594ef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "bootstrap_3_layout.html.twig"));

        // line 2
        echo "
";
        // line 4
        echo "
";
        // line 5
        $this->displayBlock('form_widget_simple', $context, $blocks);
        // line 11
        echo "
";
        // line 12
        $this->displayBlock('textarea_widget', $context, $blocks);
        // line 16
        echo "
";
        // line 17
        $this->displayBlock('button_widget', $context, $blocks);
        // line 21
        echo "
";
        // line 22
        $this->displayBlock('money_widget', $context, $blocks);
        // line 34
        echo "
";
        // line 35
        $this->displayBlock('percent_widget', $context, $blocks);
        // line 41
        echo "
";
        // line 42
        $this->displayBlock('datetime_widget', $context, $blocks);
        // line 55
        echo "
";
        // line 56
        $this->displayBlock('date_widget', $context, $blocks);
        // line 74
        echo "
";
        // line 75
        $this->displayBlock('time_widget', $context, $blocks);
        // line 90
        $this->displayBlock('dateinterval_widget', $context, $blocks);
        // line 109
        $this->displayBlock('choice_widget_collapsed', $context, $blocks);
        // line 113
        echo "
";
        // line 114
        $this->displayBlock('choice_widget_expanded', $context, $blocks);
        // line 133
        echo "
";
        // line 134
        $this->displayBlock('checkbox_widget', $context, $blocks);
        // line 144
        echo "
";
        // line 145
        $this->displayBlock('radio_widget', $context, $blocks);
        // line 155
        echo "
";
        // line 157
        echo "
";
        // line 158
        $this->displayBlock('form_label', $context, $blocks);
        // line 162
        echo "
";
        // line 163
        $this->displayBlock('choice_label', $context, $blocks);
        // line 168
        echo "
";
        // line 169
        $this->displayBlock('checkbox_label', $context, $blocks);
        // line 172
        echo "
";
        // line 173
        $this->displayBlock('radio_label', $context, $blocks);
        // line 176
        echo "
";
        // line 177
        $this->displayBlock('checkbox_radio_label', $context, $blocks);
        // line 201
        echo "
";
        // line 203
        echo "
";
        // line 204
        $this->displayBlock('form_row', $context, $blocks);
        // line 211
        echo "
";
        // line 212
        $this->displayBlock('button_row', $context, $blocks);
        // line 217
        echo "
";
        // line 218
        $this->displayBlock('choice_row', $context, $blocks);
        // line 222
        echo "
";
        // line 223
        $this->displayBlock('date_row', $context, $blocks);
        // line 227
        echo "
";
        // line 228
        $this->displayBlock('time_row', $context, $blocks);
        // line 232
        echo "
";
        // line 233
        $this->displayBlock('datetime_row', $context, $blocks);
        // line 237
        echo "
";
        // line 238
        $this->displayBlock('checkbox_row', $context, $blocks);
        // line 244
        echo "
";
        // line 245
        $this->displayBlock('radio_row', $context, $blocks);
        // line 251
        echo "
";
        // line 253
        echo "
";
        // line 254
        $this->displayBlock('form_errors', $context, $blocks);
        
        $__internal_72b3840aaa4a3d2dc17dd289f828514bbbcab9a8901184a2d2333a56001cf03d->leave($__internal_72b3840aaa4a3d2dc17dd289f828514bbbcab9a8901184a2d2333a56001cf03d_prof);

        
        $__internal_7f7e50b491347bda96d57ada1964d25cd8510712866dacd804cba2da439594ef->leave($__internal_7f7e50b491347bda96d57ada1964d25cd8510712866dacd804cba2da439594ef_prof);

    }

    // line 5
    public function block_form_widget_simple($context, array $blocks = array())
    {
        $__internal_29bae5b225e55b69c7367fbf2860b26fba431c12e3fc3ee6fc1b0c8056b69d87 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_29bae5b225e55b69c7367fbf2860b26fba431c12e3fc3ee6fc1b0c8056b69d87->enter($__internal_29bae5b225e55b69c7367fbf2860b26fba431c12e3fc3ee6fc1b0c8056b69d87_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_widget_simple"));

        $__internal_bfe23eeaf06a0cca5e907eb0a6a87d1cbc44d4270ac0c68835479c0c39d9a1de = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bfe23eeaf06a0cca5e907eb0a6a87d1cbc44d4270ac0c68835479c0c39d9a1de->enter($__internal_bfe23eeaf06a0cca5e907eb0a6a87d1cbc44d4270ac0c68835479c0c39d9a1de_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_widget_simple"));

        // line 6
        if (( !array_key_exists("type", $context) || !twig_in_filter(($context["type"] ?? $this->getContext($context, "type")), array(0 => "file", 1 => "hidden")))) {
            // line 7
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => trim(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-control"))));
        }
        // line 9
        $this->displayParentBlock("form_widget_simple", $context, $blocks);
        
        $__internal_bfe23eeaf06a0cca5e907eb0a6a87d1cbc44d4270ac0c68835479c0c39d9a1de->leave($__internal_bfe23eeaf06a0cca5e907eb0a6a87d1cbc44d4270ac0c68835479c0c39d9a1de_prof);

        
        $__internal_29bae5b225e55b69c7367fbf2860b26fba431c12e3fc3ee6fc1b0c8056b69d87->leave($__internal_29bae5b225e55b69c7367fbf2860b26fba431c12e3fc3ee6fc1b0c8056b69d87_prof);

    }

    // line 12
    public function block_textarea_widget($context, array $blocks = array())
    {
        $__internal_eba4c1620a63011a4804b2ed7e8de66a1ccf7f6a1cb92fe736225c98e6a60948 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_eba4c1620a63011a4804b2ed7e8de66a1ccf7f6a1cb92fe736225c98e6a60948->enter($__internal_eba4c1620a63011a4804b2ed7e8de66a1ccf7f6a1cb92fe736225c98e6a60948_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "textarea_widget"));

        $__internal_9879c4a3bbdc12f65bbd668bca969c323c1e07fb75fb3eb60dd78e5861e54600 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9879c4a3bbdc12f65bbd668bca969c323c1e07fb75fb3eb60dd78e5861e54600->enter($__internal_9879c4a3bbdc12f65bbd668bca969c323c1e07fb75fb3eb60dd78e5861e54600_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "textarea_widget"));

        // line 13
        $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => trim(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-control"))));
        // line 14
        $this->displayParentBlock("textarea_widget", $context, $blocks);
        
        $__internal_9879c4a3bbdc12f65bbd668bca969c323c1e07fb75fb3eb60dd78e5861e54600->leave($__internal_9879c4a3bbdc12f65bbd668bca969c323c1e07fb75fb3eb60dd78e5861e54600_prof);

        
        $__internal_eba4c1620a63011a4804b2ed7e8de66a1ccf7f6a1cb92fe736225c98e6a60948->leave($__internal_eba4c1620a63011a4804b2ed7e8de66a1ccf7f6a1cb92fe736225c98e6a60948_prof);

    }

    // line 17
    public function block_button_widget($context, array $blocks = array())
    {
        $__internal_a370f07bd03b31346b79d4fd5f9cfc28c017c079be34db51a30c2b706ad1687d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a370f07bd03b31346b79d4fd5f9cfc28c017c079be34db51a30c2b706ad1687d->enter($__internal_a370f07bd03b31346b79d4fd5f9cfc28c017c079be34db51a30c2b706ad1687d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "button_widget"));

        $__internal_76b39458f0e32e770f83653a9ab232dea5d8be6bf2524ec9c888d25dd8797abf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_76b39458f0e32e770f83653a9ab232dea5d8be6bf2524ec9c888d25dd8797abf->enter($__internal_76b39458f0e32e770f83653a9ab232dea5d8be6bf2524ec9c888d25dd8797abf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "button_widget"));

        // line 18
        $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => trim(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "btn-default")) : ("btn-default")) . " btn"))));
        // line 19
        $this->displayParentBlock("button_widget", $context, $blocks);
        
        $__internal_76b39458f0e32e770f83653a9ab232dea5d8be6bf2524ec9c888d25dd8797abf->leave($__internal_76b39458f0e32e770f83653a9ab232dea5d8be6bf2524ec9c888d25dd8797abf_prof);

        
        $__internal_a370f07bd03b31346b79d4fd5f9cfc28c017c079be34db51a30c2b706ad1687d->leave($__internal_a370f07bd03b31346b79d4fd5f9cfc28c017c079be34db51a30c2b706ad1687d_prof);

    }

    // line 22
    public function block_money_widget($context, array $blocks = array())
    {
        $__internal_ace47045d3013ff048411c376ba74f098ec9fb6a2a21a8a45df8915ede1354e8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ace47045d3013ff048411c376ba74f098ec9fb6a2a21a8a45df8915ede1354e8->enter($__internal_ace47045d3013ff048411c376ba74f098ec9fb6a2a21a8a45df8915ede1354e8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "money_widget"));

        $__internal_1f6999f2bf78b35a4a40acc8fa550fc9e5012ff2a4e79a0987d50c4271f69355 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1f6999f2bf78b35a4a40acc8fa550fc9e5012ff2a4e79a0987d50c4271f69355->enter($__internal_1f6999f2bf78b35a4a40acc8fa550fc9e5012ff2a4e79a0987d50c4271f69355_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "money_widget"));

        // line 23
        echo "<div class=\"input-group\">
        ";
        // line 24
        $context["append"] = (is_string($__internal_6d768ae2e4ebd04771147a7dc51fc68b1934ffa3be0086a303d97ac14ac82ad7 = ($context["money_pattern"] ?? $this->getContext($context, "money_pattern"))) && is_string($__internal_040f08d231f53f837fbe3f0c77333bbbf11a7f76d5c3b5b7805d5915823ae414 = "{{") && ('' === $__internal_040f08d231f53f837fbe3f0c77333bbbf11a7f76d5c3b5b7805d5915823ae414 || 0 === strpos($__internal_6d768ae2e4ebd04771147a7dc51fc68b1934ffa3be0086a303d97ac14ac82ad7, $__internal_040f08d231f53f837fbe3f0c77333bbbf11a7f76d5c3b5b7805d5915823ae414)));
        // line 25
        echo "        ";
        if ( !($context["append"] ?? $this->getContext($context, "append"))) {
            // line 26
            echo "            <span class=\"input-group-addon\">";
            echo twig_escape_filter($this->env, twig_replace_filter(($context["money_pattern"] ?? $this->getContext($context, "money_pattern")), array("{{ widget }}" => "")), "html", null, true);
            echo "</span>
        ";
        }
        // line 28
        $this->displayBlock("form_widget_simple", $context, $blocks);
        // line 29
        if (($context["append"] ?? $this->getContext($context, "append"))) {
            // line 30
            echo "            <span class=\"input-group-addon\">";
            echo twig_escape_filter($this->env, twig_replace_filter(($context["money_pattern"] ?? $this->getContext($context, "money_pattern")), array("{{ widget }}" => "")), "html", null, true);
            echo "</span>
        ";
        }
        // line 32
        echo "    </div>";
        
        $__internal_1f6999f2bf78b35a4a40acc8fa550fc9e5012ff2a4e79a0987d50c4271f69355->leave($__internal_1f6999f2bf78b35a4a40acc8fa550fc9e5012ff2a4e79a0987d50c4271f69355_prof);

        
        $__internal_ace47045d3013ff048411c376ba74f098ec9fb6a2a21a8a45df8915ede1354e8->leave($__internal_ace47045d3013ff048411c376ba74f098ec9fb6a2a21a8a45df8915ede1354e8_prof);

    }

    // line 35
    public function block_percent_widget($context, array $blocks = array())
    {
        $__internal_811353a4f9817b62fe088488bf4d43c56a80d4e6d7970cb17dd5d74898dce1a2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_811353a4f9817b62fe088488bf4d43c56a80d4e6d7970cb17dd5d74898dce1a2->enter($__internal_811353a4f9817b62fe088488bf4d43c56a80d4e6d7970cb17dd5d74898dce1a2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "percent_widget"));

        $__internal_7448dd504ab90692c6c3aaad31423984884479124ae30d86a836e79944750094 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7448dd504ab90692c6c3aaad31423984884479124ae30d86a836e79944750094->enter($__internal_7448dd504ab90692c6c3aaad31423984884479124ae30d86a836e79944750094_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "percent_widget"));

        // line 36
        echo "<div class=\"input-group\">";
        // line 37
        $this->displayBlock("form_widget_simple", $context, $blocks);
        // line 38
        echo "<span class=\"input-group-addon\">%</span>
    </div>";
        
        $__internal_7448dd504ab90692c6c3aaad31423984884479124ae30d86a836e79944750094->leave($__internal_7448dd504ab90692c6c3aaad31423984884479124ae30d86a836e79944750094_prof);

        
        $__internal_811353a4f9817b62fe088488bf4d43c56a80d4e6d7970cb17dd5d74898dce1a2->leave($__internal_811353a4f9817b62fe088488bf4d43c56a80d4e6d7970cb17dd5d74898dce1a2_prof);

    }

    // line 42
    public function block_datetime_widget($context, array $blocks = array())
    {
        $__internal_078ff0e761ff6785800ac7ad700945a5b344399267b982fae711f5bc24fab867 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_078ff0e761ff6785800ac7ad700945a5b344399267b982fae711f5bc24fab867->enter($__internal_078ff0e761ff6785800ac7ad700945a5b344399267b982fae711f5bc24fab867_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datetime_widget"));

        $__internal_ae2558ef4518915adcd5b2c4b322b1fe1fce5b9e205ed6bf5bbcf2e1328fc344 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ae2558ef4518915adcd5b2c4b322b1fe1fce5b9e205ed6bf5bbcf2e1328fc344->enter($__internal_ae2558ef4518915adcd5b2c4b322b1fe1fce5b9e205ed6bf5bbcf2e1328fc344_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datetime_widget"));

        // line 43
        if ((($context["widget"] ?? $this->getContext($context, "widget")) == "single_text")) {
            // line 44
            $this->displayBlock("form_widget_simple", $context, $blocks);
        } else {
            // line 46
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => trim(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-inline"))));
            // line 47
            echo "<div ";
            $this->displayBlock("widget_container_attributes", $context, $blocks);
            echo ">";
            // line 48
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "date", array()), 'errors');
            // line 49
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "time", array()), 'errors');
            // line 50
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "date", array()), 'widget', array("datetime" => true));
            // line 51
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "time", array()), 'widget', array("datetime" => true));
            // line 52
            echo "</div>";
        }
        
        $__internal_ae2558ef4518915adcd5b2c4b322b1fe1fce5b9e205ed6bf5bbcf2e1328fc344->leave($__internal_ae2558ef4518915adcd5b2c4b322b1fe1fce5b9e205ed6bf5bbcf2e1328fc344_prof);

        
        $__internal_078ff0e761ff6785800ac7ad700945a5b344399267b982fae711f5bc24fab867->leave($__internal_078ff0e761ff6785800ac7ad700945a5b344399267b982fae711f5bc24fab867_prof);

    }

    // line 56
    public function block_date_widget($context, array $blocks = array())
    {
        $__internal_f3ecafa9e2b21f25a7167ced60b911ce7ccfb5e95273cd1aec99247165e61a42 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f3ecafa9e2b21f25a7167ced60b911ce7ccfb5e95273cd1aec99247165e61a42->enter($__internal_f3ecafa9e2b21f25a7167ced60b911ce7ccfb5e95273cd1aec99247165e61a42_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "date_widget"));

        $__internal_85039f5c1811e247c0ccbbe2b2f64eb6602122b1884bd5316dabf68c9c3aaeb4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_85039f5c1811e247c0ccbbe2b2f64eb6602122b1884bd5316dabf68c9c3aaeb4->enter($__internal_85039f5c1811e247c0ccbbe2b2f64eb6602122b1884bd5316dabf68c9c3aaeb4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "date_widget"));

        // line 57
        if ((($context["widget"] ?? $this->getContext($context, "widget")) == "single_text")) {
            // line 58
            $this->displayBlock("form_widget_simple", $context, $blocks);
        } else {
            // line 60
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => trim(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-inline"))));
            // line 61
            if (( !array_key_exists("datetime", $context) ||  !($context["datetime"] ?? $this->getContext($context, "datetime")))) {
                // line 62
                echo "<div ";
                $this->displayBlock("widget_container_attributes", $context, $blocks);
                echo ">";
            }
            // line 64
            echo twig_replace_filter(($context["date_pattern"] ?? $this->getContext($context, "date_pattern")), array("{{ year }}" =>             // line 65
$this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "year", array()), 'widget'), "{{ month }}" =>             // line 66
$this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "month", array()), 'widget'), "{{ day }}" =>             // line 67
$this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "day", array()), 'widget')));
            // line 69
            if (( !array_key_exists("datetime", $context) ||  !($context["datetime"] ?? $this->getContext($context, "datetime")))) {
                // line 70
                echo "</div>";
            }
        }
        
        $__internal_85039f5c1811e247c0ccbbe2b2f64eb6602122b1884bd5316dabf68c9c3aaeb4->leave($__internal_85039f5c1811e247c0ccbbe2b2f64eb6602122b1884bd5316dabf68c9c3aaeb4_prof);

        
        $__internal_f3ecafa9e2b21f25a7167ced60b911ce7ccfb5e95273cd1aec99247165e61a42->leave($__internal_f3ecafa9e2b21f25a7167ced60b911ce7ccfb5e95273cd1aec99247165e61a42_prof);

    }

    // line 75
    public function block_time_widget($context, array $blocks = array())
    {
        $__internal_cb313df61dccaf2727d7f831cb212a9655c4e30c91ab7a3a85b5b9d3678a0afa = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cb313df61dccaf2727d7f831cb212a9655c4e30c91ab7a3a85b5b9d3678a0afa->enter($__internal_cb313df61dccaf2727d7f831cb212a9655c4e30c91ab7a3a85b5b9d3678a0afa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "time_widget"));

        $__internal_f4d2c3efb4086e12f121349a22623eb3f1ff4e515d8331ffb0bcfdafe0ef630d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f4d2c3efb4086e12f121349a22623eb3f1ff4e515d8331ffb0bcfdafe0ef630d->enter($__internal_f4d2c3efb4086e12f121349a22623eb3f1ff4e515d8331ffb0bcfdafe0ef630d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "time_widget"));

        // line 76
        if ((($context["widget"] ?? $this->getContext($context, "widget")) == "single_text")) {
            // line 77
            $this->displayBlock("form_widget_simple", $context, $blocks);
        } else {
            // line 79
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => trim(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-inline"))));
            // line 80
            if (( !array_key_exists("datetime", $context) || (false == ($context["datetime"] ?? $this->getContext($context, "datetime"))))) {
                // line 81
                echo "<div ";
                $this->displayBlock("widget_container_attributes", $context, $blocks);
                echo ">";
            }
            // line 83
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "hour", array()), 'widget');
            if (($context["with_minutes"] ?? $this->getContext($context, "with_minutes"))) {
                echo ":";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "minute", array()), 'widget');
            }
            if (($context["with_seconds"] ?? $this->getContext($context, "with_seconds"))) {
                echo ":";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "second", array()), 'widget');
            }
            // line 84
            echo "        ";
            if (( !array_key_exists("datetime", $context) || (false == ($context["datetime"] ?? $this->getContext($context, "datetime"))))) {
                // line 85
                echo "</div>";
            }
        }
        
        $__internal_f4d2c3efb4086e12f121349a22623eb3f1ff4e515d8331ffb0bcfdafe0ef630d->leave($__internal_f4d2c3efb4086e12f121349a22623eb3f1ff4e515d8331ffb0bcfdafe0ef630d_prof);

        
        $__internal_cb313df61dccaf2727d7f831cb212a9655c4e30c91ab7a3a85b5b9d3678a0afa->leave($__internal_cb313df61dccaf2727d7f831cb212a9655c4e30c91ab7a3a85b5b9d3678a0afa_prof);

    }

    // line 90
    public function block_dateinterval_widget($context, array $blocks = array())
    {
        $__internal_45ff278ea60a4f2d31d8d248c1eba67b67d6f776b752e8f5a126a6e92283ae18 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_45ff278ea60a4f2d31d8d248c1eba67b67d6f776b752e8f5a126a6e92283ae18->enter($__internal_45ff278ea60a4f2d31d8d248c1eba67b67d6f776b752e8f5a126a6e92283ae18_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "dateinterval_widget"));

        $__internal_b34ceb586cfb89f4d8c01bd267338ed6884da1c48bbbe461301efe7efe27bc44 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b34ceb586cfb89f4d8c01bd267338ed6884da1c48bbbe461301efe7efe27bc44->enter($__internal_b34ceb586cfb89f4d8c01bd267338ed6884da1c48bbbe461301efe7efe27bc44_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "dateinterval_widget"));

        // line 91
        if ((($context["widget"] ?? $this->getContext($context, "widget")) == "single_text")) {
            // line 92
            $this->displayBlock("form_widget_simple", $context, $blocks);
        } else {
            // line 94
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => trim(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-inline"))));
            // line 95
            echo "<div ";
            $this->displayBlock("widget_container_attributes", $context, $blocks);
            echo ">";
            // line 96
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors');
            // line 97
            if (($context["with_years"] ?? $this->getContext($context, "with_years"))) {
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "years", array()), 'widget');
            }
            // line 98
            if (($context["with_months"] ?? $this->getContext($context, "with_months"))) {
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "months", array()), 'widget');
            }
            // line 99
            if (($context["with_weeks"] ?? $this->getContext($context, "with_weeks"))) {
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "weeks", array()), 'widget');
            }
            // line 100
            if (($context["with_days"] ?? $this->getContext($context, "with_days"))) {
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "days", array()), 'widget');
            }
            // line 101
            if (($context["with_hours"] ?? $this->getContext($context, "with_hours"))) {
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "hours", array()), 'widget');
            }
            // line 102
            if (($context["with_minutes"] ?? $this->getContext($context, "with_minutes"))) {
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "minutes", array()), 'widget');
            }
            // line 103
            if (($context["with_seconds"] ?? $this->getContext($context, "with_seconds"))) {
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "seconds", array()), 'widget');
            }
            // line 104
            if (($context["with_invert"] ?? $this->getContext($context, "with_invert"))) {
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "invert", array()), 'widget');
            }
            // line 105
            echo "</div>";
        }
        
        $__internal_b34ceb586cfb89f4d8c01bd267338ed6884da1c48bbbe461301efe7efe27bc44->leave($__internal_b34ceb586cfb89f4d8c01bd267338ed6884da1c48bbbe461301efe7efe27bc44_prof);

        
        $__internal_45ff278ea60a4f2d31d8d248c1eba67b67d6f776b752e8f5a126a6e92283ae18->leave($__internal_45ff278ea60a4f2d31d8d248c1eba67b67d6f776b752e8f5a126a6e92283ae18_prof);

    }

    // line 109
    public function block_choice_widget_collapsed($context, array $blocks = array())
    {
        $__internal_ff1eae0db1297e063c720dfbbeab50d06e24bf297c567e822631507140530eb0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ff1eae0db1297e063c720dfbbeab50d06e24bf297c567e822631507140530eb0->enter($__internal_ff1eae0db1297e063c720dfbbeab50d06e24bf297c567e822631507140530eb0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_widget_collapsed"));

        $__internal_dbec07cbe42a78babe11242795609b9ac583fa68c0865d081dce137ce40c9d52 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dbec07cbe42a78babe11242795609b9ac583fa68c0865d081dce137ce40c9d52->enter($__internal_dbec07cbe42a78babe11242795609b9ac583fa68c0865d081dce137ce40c9d52_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_widget_collapsed"));

        // line 110
        $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => trim(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-control"))));
        // line 111
        $this->displayParentBlock("choice_widget_collapsed", $context, $blocks);
        
        $__internal_dbec07cbe42a78babe11242795609b9ac583fa68c0865d081dce137ce40c9d52->leave($__internal_dbec07cbe42a78babe11242795609b9ac583fa68c0865d081dce137ce40c9d52_prof);

        
        $__internal_ff1eae0db1297e063c720dfbbeab50d06e24bf297c567e822631507140530eb0->leave($__internal_ff1eae0db1297e063c720dfbbeab50d06e24bf297c567e822631507140530eb0_prof);

    }

    // line 114
    public function block_choice_widget_expanded($context, array $blocks = array())
    {
        $__internal_df6d83b9bc5209e2d8772283fe418a30a73e9d296a57851fe3084002c0cbd20b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_df6d83b9bc5209e2d8772283fe418a30a73e9d296a57851fe3084002c0cbd20b->enter($__internal_df6d83b9bc5209e2d8772283fe418a30a73e9d296a57851fe3084002c0cbd20b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_widget_expanded"));

        $__internal_e7f4dedbdf85250a0a681efd63444836fca8daf3fefd9372465abe3b5a701816 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e7f4dedbdf85250a0a681efd63444836fca8daf3fefd9372465abe3b5a701816->enter($__internal_e7f4dedbdf85250a0a681efd63444836fca8daf3fefd9372465abe3b5a701816_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_widget_expanded"));

        // line 115
        if (twig_in_filter("-inline", (($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")))) {
            // line 116
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["form"] ?? $this->getContext($context, "form")));
            foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
                // line 117
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($context["child"], 'widget', array("parent_label_class" => (($this->getAttribute(                // line 118
($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")), "translation_domain" =>                 // line 119
($context["choice_translation_domain"] ?? $this->getContext($context, "choice_translation_domain"))));
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        } else {
            // line 123
            echo "<div ";
            $this->displayBlock("widget_container_attributes", $context, $blocks);
            echo ">";
            // line 124
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["form"] ?? $this->getContext($context, "form")));
            foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
                // line 125
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($context["child"], 'widget', array("parent_label_class" => (($this->getAttribute(                // line 126
($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")), "translation_domain" =>                 // line 127
($context["choice_translation_domain"] ?? $this->getContext($context, "choice_translation_domain"))));
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 130
            echo "</div>";
        }
        
        $__internal_e7f4dedbdf85250a0a681efd63444836fca8daf3fefd9372465abe3b5a701816->leave($__internal_e7f4dedbdf85250a0a681efd63444836fca8daf3fefd9372465abe3b5a701816_prof);

        
        $__internal_df6d83b9bc5209e2d8772283fe418a30a73e9d296a57851fe3084002c0cbd20b->leave($__internal_df6d83b9bc5209e2d8772283fe418a30a73e9d296a57851fe3084002c0cbd20b_prof);

    }

    // line 134
    public function block_checkbox_widget($context, array $blocks = array())
    {
        $__internal_d482beb918d407e5945f2ef6bf004332dfa08de6498a6a4cf94d25f39a9002e4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d482beb918d407e5945f2ef6bf004332dfa08de6498a6a4cf94d25f39a9002e4->enter($__internal_d482beb918d407e5945f2ef6bf004332dfa08de6498a6a4cf94d25f39a9002e4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_widget"));

        $__internal_f7b058bba747ee7e814696a7d412279d1984fb2fe54c716b1586dee5b48c48a1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f7b058bba747ee7e814696a7d412279d1984fb2fe54c716b1586dee5b48c48a1->enter($__internal_f7b058bba747ee7e814696a7d412279d1984fb2fe54c716b1586dee5b48c48a1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_widget"));

        // line 135
        $context["parent_label_class"] = ((array_key_exists("parent_label_class", $context)) ? (_twig_default_filter(($context["parent_label_class"] ?? $this->getContext($context, "parent_label_class")), (($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")))) : ((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : (""))));
        // line 136
        if (twig_in_filter("checkbox-inline", ($context["parent_label_class"] ?? $this->getContext($context, "parent_label_class")))) {
            // line 137
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label', array("widget" => $this->renderParentBlock("checkbox_widget", $context, $blocks)));
        } else {
            // line 139
            echo "<div class=\"checkbox\">";
            // line 140
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label', array("widget" => $this->renderParentBlock("checkbox_widget", $context, $blocks)));
            // line 141
            echo "</div>";
        }
        
        $__internal_f7b058bba747ee7e814696a7d412279d1984fb2fe54c716b1586dee5b48c48a1->leave($__internal_f7b058bba747ee7e814696a7d412279d1984fb2fe54c716b1586dee5b48c48a1_prof);

        
        $__internal_d482beb918d407e5945f2ef6bf004332dfa08de6498a6a4cf94d25f39a9002e4->leave($__internal_d482beb918d407e5945f2ef6bf004332dfa08de6498a6a4cf94d25f39a9002e4_prof);

    }

    // line 145
    public function block_radio_widget($context, array $blocks = array())
    {
        $__internal_c8235aeb0089b1db7318c567ca8581e88f9fe4f1c426ac942338a2969d20b6b8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c8235aeb0089b1db7318c567ca8581e88f9fe4f1c426ac942338a2969d20b6b8->enter($__internal_c8235aeb0089b1db7318c567ca8581e88f9fe4f1c426ac942338a2969d20b6b8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "radio_widget"));

        $__internal_43941ef674e6827404fee32bd88073129af5c6946400dadbe4140e66859843ce = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_43941ef674e6827404fee32bd88073129af5c6946400dadbe4140e66859843ce->enter($__internal_43941ef674e6827404fee32bd88073129af5c6946400dadbe4140e66859843ce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "radio_widget"));

        // line 146
        $context["parent_label_class"] = ((array_key_exists("parent_label_class", $context)) ? (_twig_default_filter(($context["parent_label_class"] ?? $this->getContext($context, "parent_label_class")), (($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")))) : ((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : (""))));
        // line 147
        if (twig_in_filter("radio-inline", ($context["parent_label_class"] ?? $this->getContext($context, "parent_label_class")))) {
            // line 148
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label', array("widget" => $this->renderParentBlock("radio_widget", $context, $blocks)));
        } else {
            // line 150
            echo "<div class=\"radio\">";
            // line 151
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label', array("widget" => $this->renderParentBlock("radio_widget", $context, $blocks)));
            // line 152
            echo "</div>";
        }
        
        $__internal_43941ef674e6827404fee32bd88073129af5c6946400dadbe4140e66859843ce->leave($__internal_43941ef674e6827404fee32bd88073129af5c6946400dadbe4140e66859843ce_prof);

        
        $__internal_c8235aeb0089b1db7318c567ca8581e88f9fe4f1c426ac942338a2969d20b6b8->leave($__internal_c8235aeb0089b1db7318c567ca8581e88f9fe4f1c426ac942338a2969d20b6b8_prof);

    }

    // line 158
    public function block_form_label($context, array $blocks = array())
    {
        $__internal_c5be81d7b38f8494e3fdb88e7192318ef808083c6ed97fda589706838a0cc047 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c5be81d7b38f8494e3fdb88e7192318ef808083c6ed97fda589706838a0cc047->enter($__internal_c5be81d7b38f8494e3fdb88e7192318ef808083c6ed97fda589706838a0cc047_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_label"));

        $__internal_949549d75b68cfc3542ee37830b7160bd08bbb483c605353c7f0199bd18d3d7b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_949549d75b68cfc3542ee37830b7160bd08bbb483c605353c7f0199bd18d3d7b->enter($__internal_949549d75b68cfc3542ee37830b7160bd08bbb483c605353c7f0199bd18d3d7b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_label"));

        // line 159
        $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("class" => trim(((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")) . " control-label"))));
        // line 160
        $this->displayParentBlock("form_label", $context, $blocks);
        
        $__internal_949549d75b68cfc3542ee37830b7160bd08bbb483c605353c7f0199bd18d3d7b->leave($__internal_949549d75b68cfc3542ee37830b7160bd08bbb483c605353c7f0199bd18d3d7b_prof);

        
        $__internal_c5be81d7b38f8494e3fdb88e7192318ef808083c6ed97fda589706838a0cc047->leave($__internal_c5be81d7b38f8494e3fdb88e7192318ef808083c6ed97fda589706838a0cc047_prof);

    }

    // line 163
    public function block_choice_label($context, array $blocks = array())
    {
        $__internal_b3a29f02c1a4b680dcc52f0d7b1834815cc801e64e09db8840d89755f4e13fae = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b3a29f02c1a4b680dcc52f0d7b1834815cc801e64e09db8840d89755f4e13fae->enter($__internal_b3a29f02c1a4b680dcc52f0d7b1834815cc801e64e09db8840d89755f4e13fae_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_label"));

        $__internal_3d52caad40001e7129dd0c07070c876d43efa8fa22f5ec1ed405f1ada26116a0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3d52caad40001e7129dd0c07070c876d43efa8fa22f5ec1ed405f1ada26116a0->enter($__internal_3d52caad40001e7129dd0c07070c876d43efa8fa22f5ec1ed405f1ada26116a0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_label"));

        // line 165
        $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("class" => trim(twig_replace_filter((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")), array("checkbox-inline" => "", "radio-inline" => "")))));
        // line 166
        $this->displayBlock("form_label", $context, $blocks);
        
        $__internal_3d52caad40001e7129dd0c07070c876d43efa8fa22f5ec1ed405f1ada26116a0->leave($__internal_3d52caad40001e7129dd0c07070c876d43efa8fa22f5ec1ed405f1ada26116a0_prof);

        
        $__internal_b3a29f02c1a4b680dcc52f0d7b1834815cc801e64e09db8840d89755f4e13fae->leave($__internal_b3a29f02c1a4b680dcc52f0d7b1834815cc801e64e09db8840d89755f4e13fae_prof);

    }

    // line 169
    public function block_checkbox_label($context, array $blocks = array())
    {
        $__internal_03c2d59301941c0200d506aae4abea595a0ef272e8c4d429864300725cebee22 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_03c2d59301941c0200d506aae4abea595a0ef272e8c4d429864300725cebee22->enter($__internal_03c2d59301941c0200d506aae4abea595a0ef272e8c4d429864300725cebee22_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_label"));

        $__internal_4bb2402e8021edb271f4e8bb957123c1e1534a0db57764d2a463906ce3c48e6b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4bb2402e8021edb271f4e8bb957123c1e1534a0db57764d2a463906ce3c48e6b->enter($__internal_4bb2402e8021edb271f4e8bb957123c1e1534a0db57764d2a463906ce3c48e6b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_label"));

        // line 170
        $this->displayBlock("checkbox_radio_label", $context, $blocks);
        
        $__internal_4bb2402e8021edb271f4e8bb957123c1e1534a0db57764d2a463906ce3c48e6b->leave($__internal_4bb2402e8021edb271f4e8bb957123c1e1534a0db57764d2a463906ce3c48e6b_prof);

        
        $__internal_03c2d59301941c0200d506aae4abea595a0ef272e8c4d429864300725cebee22->leave($__internal_03c2d59301941c0200d506aae4abea595a0ef272e8c4d429864300725cebee22_prof);

    }

    // line 173
    public function block_radio_label($context, array $blocks = array())
    {
        $__internal_a3f1bb4165500051d499581925f440993558f4bc786a5c1fb443f8b3f52edcf9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a3f1bb4165500051d499581925f440993558f4bc786a5c1fb443f8b3f52edcf9->enter($__internal_a3f1bb4165500051d499581925f440993558f4bc786a5c1fb443f8b3f52edcf9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "radio_label"));

        $__internal_a39633c984ea6efbe7be53e0426bb80476c1e131f313b9badf6d9dfcc4eb8b27 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a39633c984ea6efbe7be53e0426bb80476c1e131f313b9badf6d9dfcc4eb8b27->enter($__internal_a39633c984ea6efbe7be53e0426bb80476c1e131f313b9badf6d9dfcc4eb8b27_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "radio_label"));

        // line 174
        $this->displayBlock("checkbox_radio_label", $context, $blocks);
        
        $__internal_a39633c984ea6efbe7be53e0426bb80476c1e131f313b9badf6d9dfcc4eb8b27->leave($__internal_a39633c984ea6efbe7be53e0426bb80476c1e131f313b9badf6d9dfcc4eb8b27_prof);

        
        $__internal_a3f1bb4165500051d499581925f440993558f4bc786a5c1fb443f8b3f52edcf9->leave($__internal_a3f1bb4165500051d499581925f440993558f4bc786a5c1fb443f8b3f52edcf9_prof);

    }

    // line 177
    public function block_checkbox_radio_label($context, array $blocks = array())
    {
        $__internal_f8335e690dd775df19ff1a50d6353e1f053ad05c4e6535f4bef965d02895ae9b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f8335e690dd775df19ff1a50d6353e1f053ad05c4e6535f4bef965d02895ae9b->enter($__internal_f8335e690dd775df19ff1a50d6353e1f053ad05c4e6535f4bef965d02895ae9b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_radio_label"));

        $__internal_6c6fb00d6bf2d66bd8f484e3fa0df2a7048085bbbd0cdd1567c53c2b1f845879 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6c6fb00d6bf2d66bd8f484e3fa0df2a7048085bbbd0cdd1567c53c2b1f845879->enter($__internal_6c6fb00d6bf2d66bd8f484e3fa0df2a7048085bbbd0cdd1567c53c2b1f845879_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_radio_label"));

        // line 178
        echo "    ";
        // line 179
        echo "    ";
        if (array_key_exists("widget", $context)) {
            // line 180
            echo "        ";
            if (($context["required"] ?? $this->getContext($context, "required"))) {
                // line 181
                echo "            ";
                $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("class" => trim(((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")) . " required"))));
                // line 182
                echo "        ";
            }
            // line 183
            echo "        ";
            if (array_key_exists("parent_label_class", $context)) {
                // line 184
                echo "            ";
                $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("class" => trim((((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")) . " ") . ($context["parent_label_class"] ?? $this->getContext($context, "parent_label_class"))))));
                // line 185
                echo "        ";
            }
            // line 186
            echo "        ";
            if (( !(($context["label"] ?? $this->getContext($context, "label")) === false) && twig_test_empty(($context["label"] ?? $this->getContext($context, "label"))))) {
                // line 187
                if ( !twig_test_empty(($context["label_format"] ?? $this->getContext($context, "label_format")))) {
                    // line 188
                    $context["label"] = twig_replace_filter(($context["label_format"] ?? $this->getContext($context, "label_format")), array("%name%" =>                     // line 189
($context["name"] ?? $this->getContext($context, "name")), "%id%" =>                     // line 190
($context["id"] ?? $this->getContext($context, "id"))));
                } else {
                    // line 193
                    $context["label"] = $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->humanize(($context["name"] ?? $this->getContext($context, "name")));
                }
            }
            // line 196
            echo "        <label";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["label_attr"] ?? $this->getContext($context, "label_attr")));
            foreach ($context['_seq'] as $context["attrname"] => $context["attrvalue"]) {
                echo " ";
                echo twig_escape_filter($this->env, $context["attrname"], "html", null, true);
                echo "=\"";
                echo twig_escape_filter($this->env, $context["attrvalue"], "html", null, true);
                echo "\"";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['attrname'], $context['attrvalue'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo ">";
            // line 197
            echo ($context["widget"] ?? $this->getContext($context, "widget"));
            echo " ";
            echo twig_escape_filter($this->env, (( !(($context["label"] ?? $this->getContext($context, "label")) === false)) ? ((((($context["translation_domain"] ?? $this->getContext($context, "translation_domain")) === false)) ? (($context["label"] ?? $this->getContext($context, "label"))) : ($this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans(($context["label"] ?? $this->getContext($context, "label")), array(), ($context["translation_domain"] ?? $this->getContext($context, "translation_domain")))))) : ("")), "html", null, true);
            // line 198
            echo "</label>
    ";
        }
        
        $__internal_6c6fb00d6bf2d66bd8f484e3fa0df2a7048085bbbd0cdd1567c53c2b1f845879->leave($__internal_6c6fb00d6bf2d66bd8f484e3fa0df2a7048085bbbd0cdd1567c53c2b1f845879_prof);

        
        $__internal_f8335e690dd775df19ff1a50d6353e1f053ad05c4e6535f4bef965d02895ae9b->leave($__internal_f8335e690dd775df19ff1a50d6353e1f053ad05c4e6535f4bef965d02895ae9b_prof);

    }

    // line 204
    public function block_form_row($context, array $blocks = array())
    {
        $__internal_be1cf61579da1c20ef12e00b9d56e9ffe8f13b3051dde03b3ed4bb2f4ae9b739 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_be1cf61579da1c20ef12e00b9d56e9ffe8f13b3051dde03b3ed4bb2f4ae9b739->enter($__internal_be1cf61579da1c20ef12e00b9d56e9ffe8f13b3051dde03b3ed4bb2f4ae9b739_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_row"));

        $__internal_45e3f120dacf6f58cfffe595f7f609332bdbabc1e851bacdf31063e519ee634d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_45e3f120dacf6f58cfffe595f7f609332bdbabc1e851bacdf31063e519ee634d->enter($__internal_45e3f120dacf6f58cfffe595f7f609332bdbabc1e851bacdf31063e519ee634d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_row"));

        // line 205
        echo "<div class=\"form-group";
        if ((( !($context["compound"] ?? $this->getContext($context, "compound")) || ((array_key_exists("force_error", $context)) ? (_twig_default_filter(($context["force_error"] ?? $this->getContext($context, "force_error")), false)) : (false))) &&  !($context["valid"] ?? $this->getContext($context, "valid")))) {
            echo " has-error";
        }
        echo "\">";
        // line 206
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label');
        // line 207
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 208
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors');
        // line 209
        echo "</div>";
        
        $__internal_45e3f120dacf6f58cfffe595f7f609332bdbabc1e851bacdf31063e519ee634d->leave($__internal_45e3f120dacf6f58cfffe595f7f609332bdbabc1e851bacdf31063e519ee634d_prof);

        
        $__internal_be1cf61579da1c20ef12e00b9d56e9ffe8f13b3051dde03b3ed4bb2f4ae9b739->leave($__internal_be1cf61579da1c20ef12e00b9d56e9ffe8f13b3051dde03b3ed4bb2f4ae9b739_prof);

    }

    // line 212
    public function block_button_row($context, array $blocks = array())
    {
        $__internal_2c4599f91546bc2df7582366560d21868ca00250459098184c4f689779a1b3ff = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2c4599f91546bc2df7582366560d21868ca00250459098184c4f689779a1b3ff->enter($__internal_2c4599f91546bc2df7582366560d21868ca00250459098184c4f689779a1b3ff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "button_row"));

        $__internal_213faed5225bd40fbcf6e6e97dd3d106dfc9e623951107cf6f5c47b7ff20b37f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_213faed5225bd40fbcf6e6e97dd3d106dfc9e623951107cf6f5c47b7ff20b37f->enter($__internal_213faed5225bd40fbcf6e6e97dd3d106dfc9e623951107cf6f5c47b7ff20b37f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "button_row"));

        // line 213
        echo "<div class=\"form-group\">";
        // line 214
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 215
        echo "</div>";
        
        $__internal_213faed5225bd40fbcf6e6e97dd3d106dfc9e623951107cf6f5c47b7ff20b37f->leave($__internal_213faed5225bd40fbcf6e6e97dd3d106dfc9e623951107cf6f5c47b7ff20b37f_prof);

        
        $__internal_2c4599f91546bc2df7582366560d21868ca00250459098184c4f689779a1b3ff->leave($__internal_2c4599f91546bc2df7582366560d21868ca00250459098184c4f689779a1b3ff_prof);

    }

    // line 218
    public function block_choice_row($context, array $blocks = array())
    {
        $__internal_ecf131a81f58423eda0e453c5f58b8b705b66ed505e3fcb2bcecc20433f7dc07 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ecf131a81f58423eda0e453c5f58b8b705b66ed505e3fcb2bcecc20433f7dc07->enter($__internal_ecf131a81f58423eda0e453c5f58b8b705b66ed505e3fcb2bcecc20433f7dc07_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_row"));

        $__internal_22582f5eb2eab8b5d357fec5a5014b865284f94b2a8271584d016fd8a2900419 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_22582f5eb2eab8b5d357fec5a5014b865284f94b2a8271584d016fd8a2900419->enter($__internal_22582f5eb2eab8b5d357fec5a5014b865284f94b2a8271584d016fd8a2900419_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_row"));

        // line 219
        $context["force_error"] = true;
        // line 220
        $this->displayBlock("form_row", $context, $blocks);
        
        $__internal_22582f5eb2eab8b5d357fec5a5014b865284f94b2a8271584d016fd8a2900419->leave($__internal_22582f5eb2eab8b5d357fec5a5014b865284f94b2a8271584d016fd8a2900419_prof);

        
        $__internal_ecf131a81f58423eda0e453c5f58b8b705b66ed505e3fcb2bcecc20433f7dc07->leave($__internal_ecf131a81f58423eda0e453c5f58b8b705b66ed505e3fcb2bcecc20433f7dc07_prof);

    }

    // line 223
    public function block_date_row($context, array $blocks = array())
    {
        $__internal_4683f0988f1f992cf4c4d477e11bc979e6aa819a0be79691e257fc19a7ea4cff = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4683f0988f1f992cf4c4d477e11bc979e6aa819a0be79691e257fc19a7ea4cff->enter($__internal_4683f0988f1f992cf4c4d477e11bc979e6aa819a0be79691e257fc19a7ea4cff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "date_row"));

        $__internal_6b5489b8f475586c0d178c802efcbdceeab9a6afefe9bba503b0ee5f22d11867 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6b5489b8f475586c0d178c802efcbdceeab9a6afefe9bba503b0ee5f22d11867->enter($__internal_6b5489b8f475586c0d178c802efcbdceeab9a6afefe9bba503b0ee5f22d11867_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "date_row"));

        // line 224
        $context["force_error"] = true;
        // line 225
        $this->displayBlock("form_row", $context, $blocks);
        
        $__internal_6b5489b8f475586c0d178c802efcbdceeab9a6afefe9bba503b0ee5f22d11867->leave($__internal_6b5489b8f475586c0d178c802efcbdceeab9a6afefe9bba503b0ee5f22d11867_prof);

        
        $__internal_4683f0988f1f992cf4c4d477e11bc979e6aa819a0be79691e257fc19a7ea4cff->leave($__internal_4683f0988f1f992cf4c4d477e11bc979e6aa819a0be79691e257fc19a7ea4cff_prof);

    }

    // line 228
    public function block_time_row($context, array $blocks = array())
    {
        $__internal_e6d78f451207b7fbd773659ae124b60fdfe75413b5e82a6e5fdd3654dedb4de4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e6d78f451207b7fbd773659ae124b60fdfe75413b5e82a6e5fdd3654dedb4de4->enter($__internal_e6d78f451207b7fbd773659ae124b60fdfe75413b5e82a6e5fdd3654dedb4de4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "time_row"));

        $__internal_cbbdd4f2b4091e50116600b148588763f5ae34f890ae7ead9d1f239e69840e04 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cbbdd4f2b4091e50116600b148588763f5ae34f890ae7ead9d1f239e69840e04->enter($__internal_cbbdd4f2b4091e50116600b148588763f5ae34f890ae7ead9d1f239e69840e04_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "time_row"));

        // line 229
        $context["force_error"] = true;
        // line 230
        $this->displayBlock("form_row", $context, $blocks);
        
        $__internal_cbbdd4f2b4091e50116600b148588763f5ae34f890ae7ead9d1f239e69840e04->leave($__internal_cbbdd4f2b4091e50116600b148588763f5ae34f890ae7ead9d1f239e69840e04_prof);

        
        $__internal_e6d78f451207b7fbd773659ae124b60fdfe75413b5e82a6e5fdd3654dedb4de4->leave($__internal_e6d78f451207b7fbd773659ae124b60fdfe75413b5e82a6e5fdd3654dedb4de4_prof);

    }

    // line 233
    public function block_datetime_row($context, array $blocks = array())
    {
        $__internal_a6915ba7435f61d665aa09e6cf9b837a9be2916215b85c09481a5ace3afdb2ab = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a6915ba7435f61d665aa09e6cf9b837a9be2916215b85c09481a5ace3afdb2ab->enter($__internal_a6915ba7435f61d665aa09e6cf9b837a9be2916215b85c09481a5ace3afdb2ab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datetime_row"));

        $__internal_9614455c361e489525fb09536bea050e08bc6b1265a64b18ff2d421c0e0d843a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9614455c361e489525fb09536bea050e08bc6b1265a64b18ff2d421c0e0d843a->enter($__internal_9614455c361e489525fb09536bea050e08bc6b1265a64b18ff2d421c0e0d843a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datetime_row"));

        // line 234
        $context["force_error"] = true;
        // line 235
        $this->displayBlock("form_row", $context, $blocks);
        
        $__internal_9614455c361e489525fb09536bea050e08bc6b1265a64b18ff2d421c0e0d843a->leave($__internal_9614455c361e489525fb09536bea050e08bc6b1265a64b18ff2d421c0e0d843a_prof);

        
        $__internal_a6915ba7435f61d665aa09e6cf9b837a9be2916215b85c09481a5ace3afdb2ab->leave($__internal_a6915ba7435f61d665aa09e6cf9b837a9be2916215b85c09481a5ace3afdb2ab_prof);

    }

    // line 238
    public function block_checkbox_row($context, array $blocks = array())
    {
        $__internal_d5f274d0bb328ced5209f1bd0f77f77a756aa67ec2a591c15642cf2fc205ec75 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d5f274d0bb328ced5209f1bd0f77f77a756aa67ec2a591c15642cf2fc205ec75->enter($__internal_d5f274d0bb328ced5209f1bd0f77f77a756aa67ec2a591c15642cf2fc205ec75_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_row"));

        $__internal_f5e278a21b3389bdc6eaf8b3029d41237a3ea7a9898815f431b1664bc864adc6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f5e278a21b3389bdc6eaf8b3029d41237a3ea7a9898815f431b1664bc864adc6->enter($__internal_f5e278a21b3389bdc6eaf8b3029d41237a3ea7a9898815f431b1664bc864adc6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_row"));

        // line 239
        echo "<div class=\"form-group";
        if ( !($context["valid"] ?? $this->getContext($context, "valid"))) {
            echo " has-error";
        }
        echo "\">";
        // line 240
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 241
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors');
        // line 242
        echo "</div>";
        
        $__internal_f5e278a21b3389bdc6eaf8b3029d41237a3ea7a9898815f431b1664bc864adc6->leave($__internal_f5e278a21b3389bdc6eaf8b3029d41237a3ea7a9898815f431b1664bc864adc6_prof);

        
        $__internal_d5f274d0bb328ced5209f1bd0f77f77a756aa67ec2a591c15642cf2fc205ec75->leave($__internal_d5f274d0bb328ced5209f1bd0f77f77a756aa67ec2a591c15642cf2fc205ec75_prof);

    }

    // line 245
    public function block_radio_row($context, array $blocks = array())
    {
        $__internal_ec78f33d5a9c1f4d4d1513c5296dc88315815a4cf98c3d13b31fee95086292e0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ec78f33d5a9c1f4d4d1513c5296dc88315815a4cf98c3d13b31fee95086292e0->enter($__internal_ec78f33d5a9c1f4d4d1513c5296dc88315815a4cf98c3d13b31fee95086292e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "radio_row"));

        $__internal_1149d3609f443d6fdf9714df5c04239ce97a0ab0344b71b21d673458b378cb50 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1149d3609f443d6fdf9714df5c04239ce97a0ab0344b71b21d673458b378cb50->enter($__internal_1149d3609f443d6fdf9714df5c04239ce97a0ab0344b71b21d673458b378cb50_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "radio_row"));

        // line 246
        echo "<div class=\"form-group";
        if ( !($context["valid"] ?? $this->getContext($context, "valid"))) {
            echo " has-error";
        }
        echo "\">";
        // line 247
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 248
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors');
        // line 249
        echo "</div>";
        
        $__internal_1149d3609f443d6fdf9714df5c04239ce97a0ab0344b71b21d673458b378cb50->leave($__internal_1149d3609f443d6fdf9714df5c04239ce97a0ab0344b71b21d673458b378cb50_prof);

        
        $__internal_ec78f33d5a9c1f4d4d1513c5296dc88315815a4cf98c3d13b31fee95086292e0->leave($__internal_ec78f33d5a9c1f4d4d1513c5296dc88315815a4cf98c3d13b31fee95086292e0_prof);

    }

    // line 254
    public function block_form_errors($context, array $blocks = array())
    {
        $__internal_d3f9e6b615e3af29f1edb34fae8b1d2dbefad142b7e296019ed4e299e6fdc907 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d3f9e6b615e3af29f1edb34fae8b1d2dbefad142b7e296019ed4e299e6fdc907->enter($__internal_d3f9e6b615e3af29f1edb34fae8b1d2dbefad142b7e296019ed4e299e6fdc907_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_errors"));

        $__internal_9cb68ece869cc0817a6d7a7c9e7eee39196ebcd328ca19ed15fe28a089af4bef = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9cb68ece869cc0817a6d7a7c9e7eee39196ebcd328ca19ed15fe28a089af4bef->enter($__internal_9cb68ece869cc0817a6d7a7c9e7eee39196ebcd328ca19ed15fe28a089af4bef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_errors"));

        // line 255
        if ((twig_length_filter($this->env, ($context["errors"] ?? $this->getContext($context, "errors"))) > 0)) {
            // line 256
            if ($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "parent", array())) {
                echo "<span class=\"help-block\">";
            } else {
                echo "<div class=\"alert alert-danger\">";
            }
            // line 257
            echo "    <ul class=\"list-unstyled\">";
            // line 258
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["errors"] ?? $this->getContext($context, "errors")));
            foreach ($context['_seq'] as $context["_key"] => $context["error"]) {
                // line 259
                echo "<li><span class=\"glyphicon glyphicon-exclamation-sign\"></span> ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["error"], "message", array()), "html", null, true);
                echo "</li>";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['error'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 261
            echo "</ul>
    ";
            // line 262
            if ($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "parent", array())) {
                echo "</span>";
            } else {
                echo "</div>";
            }
        }
        
        $__internal_9cb68ece869cc0817a6d7a7c9e7eee39196ebcd328ca19ed15fe28a089af4bef->leave($__internal_9cb68ece869cc0817a6d7a7c9e7eee39196ebcd328ca19ed15fe28a089af4bef_prof);

        
        $__internal_d3f9e6b615e3af29f1edb34fae8b1d2dbefad142b7e296019ed4e299e6fdc907->leave($__internal_d3f9e6b615e3af29f1edb34fae8b1d2dbefad142b7e296019ed4e299e6fdc907_prof);

    }

    public function getTemplateName()
    {
        return "bootstrap_3_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  1061 => 262,  1058 => 261,  1050 => 259,  1046 => 258,  1044 => 257,  1038 => 256,  1036 => 255,  1027 => 254,  1017 => 249,  1015 => 248,  1013 => 247,  1007 => 246,  998 => 245,  988 => 242,  986 => 241,  984 => 240,  978 => 239,  969 => 238,  959 => 235,  957 => 234,  948 => 233,  938 => 230,  936 => 229,  927 => 228,  917 => 225,  915 => 224,  906 => 223,  896 => 220,  894 => 219,  885 => 218,  875 => 215,  873 => 214,  871 => 213,  862 => 212,  852 => 209,  850 => 208,  848 => 207,  846 => 206,  840 => 205,  831 => 204,  819 => 198,  815 => 197,  800 => 196,  796 => 193,  793 => 190,  792 => 189,  791 => 188,  789 => 187,  786 => 186,  783 => 185,  780 => 184,  777 => 183,  774 => 182,  771 => 181,  768 => 180,  765 => 179,  763 => 178,  754 => 177,  744 => 174,  735 => 173,  725 => 170,  716 => 169,  706 => 166,  704 => 165,  695 => 163,  685 => 160,  683 => 159,  674 => 158,  663 => 152,  661 => 151,  659 => 150,  656 => 148,  654 => 147,  652 => 146,  643 => 145,  632 => 141,  630 => 140,  628 => 139,  625 => 137,  623 => 136,  621 => 135,  612 => 134,  601 => 130,  595 => 127,  594 => 126,  593 => 125,  589 => 124,  585 => 123,  578 => 119,  577 => 118,  576 => 117,  572 => 116,  570 => 115,  561 => 114,  551 => 111,  549 => 110,  540 => 109,  529 => 105,  525 => 104,  521 => 103,  517 => 102,  513 => 101,  509 => 100,  505 => 99,  501 => 98,  497 => 97,  495 => 96,  491 => 95,  489 => 94,  486 => 92,  484 => 91,  475 => 90,  463 => 85,  460 => 84,  450 => 83,  445 => 81,  443 => 80,  441 => 79,  438 => 77,  436 => 76,  427 => 75,  415 => 70,  413 => 69,  411 => 67,  410 => 66,  409 => 65,  408 => 64,  403 => 62,  401 => 61,  399 => 60,  396 => 58,  394 => 57,  385 => 56,  374 => 52,  372 => 51,  370 => 50,  368 => 49,  366 => 48,  362 => 47,  360 => 46,  357 => 44,  355 => 43,  346 => 42,  335 => 38,  333 => 37,  331 => 36,  322 => 35,  312 => 32,  306 => 30,  304 => 29,  302 => 28,  296 => 26,  293 => 25,  291 => 24,  288 => 23,  279 => 22,  269 => 19,  267 => 18,  258 => 17,  248 => 14,  246 => 13,  237 => 12,  227 => 9,  224 => 7,  222 => 6,  213 => 5,  203 => 254,  200 => 253,  197 => 251,  195 => 245,  192 => 244,  190 => 238,  187 => 237,  185 => 233,  182 => 232,  180 => 228,  177 => 227,  175 => 223,  172 => 222,  170 => 218,  167 => 217,  165 => 212,  162 => 211,  160 => 204,  157 => 203,  154 => 201,  152 => 177,  149 => 176,  147 => 173,  144 => 172,  142 => 169,  139 => 168,  137 => 163,  134 => 162,  132 => 158,  129 => 157,  126 => 155,  124 => 145,  121 => 144,  119 => 134,  116 => 133,  114 => 114,  111 => 113,  109 => 109,  107 => 90,  105 => 75,  102 => 74,  100 => 56,  97 => 55,  95 => 42,  92 => 41,  90 => 35,  87 => 34,  85 => 22,  82 => 21,  80 => 17,  77 => 16,  75 => 12,  72 => 11,  70 => 5,  67 => 4,  64 => 2,  14 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% use \"form_div_layout.html.twig\" %}

{# Widgets #}

{% block form_widget_simple -%}
    {% if type is not defined or type not in ['file', 'hidden'] %}
        {%- set attr = attr|merge({class: (attr.class|default('') ~ ' form-control')|trim}) -%}
    {% endif %}
    {{- parent() -}}
{%- endblock form_widget_simple %}

{% block textarea_widget -%}
    {% set attr = attr|merge({class: (attr.class|default('') ~ ' form-control')|trim}) %}
    {{- parent() -}}
{%- endblock textarea_widget %}

{% block button_widget -%}
    {% set attr = attr|merge({class: (attr.class|default('btn-default') ~ ' btn')|trim}) %}
    {{- parent() -}}
{%- endblock %}

{% block money_widget -%}
    <div class=\"input-group\">
        {% set append = money_pattern starts with '{{' %}
        {% if not append %}
            <span class=\"input-group-addon\">{{ money_pattern|replace({ '{{ widget }}':''}) }}</span>
        {% endif %}
        {{- block('form_widget_simple') -}}
        {% if append %}
            <span class=\"input-group-addon\">{{ money_pattern|replace({ '{{ widget }}':''}) }}</span>
        {% endif %}
    </div>
{%- endblock money_widget %}

{% block percent_widget -%}
    <div class=\"input-group\">
        {{- block('form_widget_simple') -}}
        <span class=\"input-group-addon\">%</span>
    </div>
{%- endblock percent_widget %}

{% block datetime_widget -%}
    {% if widget == 'single_text' %}
        {{- block('form_widget_simple') -}}
    {% else -%}
        {% set attr = attr|merge({class: (attr.class|default('') ~ ' form-inline')|trim}) -%}
        <div {{ block('widget_container_attributes') }}>
            {{- form_errors(form.date) -}}
            {{- form_errors(form.time) -}}
            {{- form_widget(form.date, { datetime: true } ) -}}
            {{- form_widget(form.time, { datetime: true } ) -}}
        </div>
    {%- endif %}
{%- endblock datetime_widget %}

{% block date_widget -%}
    {% if widget == 'single_text' %}
        {{- block('form_widget_simple') -}}
    {% else -%}
        {% set attr = attr|merge({class: (attr.class|default('') ~ ' form-inline')|trim}) -%}
        {% if datetime is not defined or not datetime -%}
            <div {{ block('widget_container_attributes') -}}>
        {%- endif %}
            {{- date_pattern|replace({
                '{{ year }}': form_widget(form.year),
                '{{ month }}': form_widget(form.month),
                '{{ day }}': form_widget(form.day),
            })|raw -}}
        {% if datetime is not defined or not datetime -%}
            </div>
        {%- endif -%}
    {% endif %}
{%- endblock date_widget %}

{% block time_widget -%}
    {% if widget == 'single_text' %}
        {{- block('form_widget_simple') -}}
    {% else -%}
        {% set attr = attr|merge({class: (attr.class|default('') ~ ' form-inline')|trim}) -%}
        {% if datetime is not defined or false == datetime -%}
            <div {{ block('widget_container_attributes') -}}>
        {%- endif -%}
        {{- form_widget(form.hour) }}{% if with_minutes %}:{{ form_widget(form.minute) }}{% endif %}{% if with_seconds %}:{{ form_widget(form.second) }}{% endif %}
        {% if datetime is not defined or false == datetime -%}
            </div>
        {%- endif -%}
    {% endif %}
{%- endblock time_widget %}

{%- block dateinterval_widget -%}
    {%- if widget == 'single_text' -%}
        {{- block('form_widget_simple') -}}
    {%- else -%}
        {%- set attr = attr|merge({class: (attr.class|default('') ~ ' form-inline')|trim}) -%}
        <div {{ block('widget_container_attributes') }}>
            {{- form_errors(form) -}}
            {%- if with_years %}{{ form_widget(form.years) }}{% endif -%}
            {%- if with_months %}{{ form_widget(form.months) }}{% endif -%}
            {%- if with_weeks %}{{ form_widget(form.weeks) }}{% endif -%}
            {%- if with_days %}{{ form_widget(form.days) }}{% endif -%}
            {%- if with_hours %}{{ form_widget(form.hours) }}{% endif -%}
            {%- if with_minutes %}{{ form_widget(form.minutes) }}{% endif -%}
            {%- if with_seconds %}{{ form_widget(form.seconds) }}{% endif -%}
            {%- if with_invert %}{{ form_widget(form.invert) }}{% endif -%}
        </div>
    {%- endif -%}
{%- endblock dateinterval_widget -%}

{% block choice_widget_collapsed -%}
    {% set attr = attr|merge({class: (attr.class|default('') ~ ' form-control')|trim}) %}
    {{- parent() -}}
{%- endblock %}

{% block choice_widget_expanded -%}
    {% if '-inline' in label_attr.class|default('') -%}
        {%- for child in form %}
            {{- form_widget(child, {
                parent_label_class: label_attr.class|default(''),
                translation_domain: choice_translation_domain,
            }) -}}
        {% endfor -%}
    {%- else -%}
        <div {{ block('widget_container_attributes') }}>
            {%- for child in form %}
                {{- form_widget(child, {
                    parent_label_class: label_attr.class|default(''),
                    translation_domain: choice_translation_domain,
                }) -}}
            {% endfor -%}
        </div>
    {%- endif %}
{%- endblock choice_widget_expanded %}

{% block checkbox_widget -%}
    {%- set parent_label_class = parent_label_class|default(label_attr.class|default('')) -%}
    {% if 'checkbox-inline' in parent_label_class %}
        {{- form_label(form, null, { widget: parent() }) -}}
    {% else -%}
        <div class=\"checkbox\">
            {{- form_label(form, null, { widget: parent() }) -}}
        </div>
    {%- endif %}
{%- endblock checkbox_widget %}

{% block radio_widget -%}
    {%- set parent_label_class = parent_label_class|default(label_attr.class|default('')) -%}
    {% if 'radio-inline' in parent_label_class %}
        {{- form_label(form, null, { widget: parent() }) -}}
    {% else -%}
        <div class=\"radio\">
            {{- form_label(form, null, { widget: parent() }) -}}
        </div>
    {%- endif %}
{%- endblock radio_widget %}

{# Labels #}

{% block form_label -%}
    {%- set label_attr = label_attr|merge({class: (label_attr.class|default('') ~ ' control-label')|trim}) -%}
    {{- parent() -}}
{%- endblock form_label %}

{% block choice_label -%}
    {# remove the checkbox-inline and radio-inline class, it's only useful for embed labels #}
    {%- set label_attr = label_attr|merge({class: label_attr.class|default('')|replace({'checkbox-inline': '', 'radio-inline': ''})|trim}) -%}
    {{- block('form_label') -}}
{% endblock %}

{% block checkbox_label -%}
    {{- block('checkbox_radio_label') -}}
{%- endblock checkbox_label %}

{% block radio_label -%}
    {{- block('checkbox_radio_label') -}}
{%- endblock radio_label %}

{% block checkbox_radio_label %}
    {# Do not display the label if widget is not defined in order to prevent double label rendering #}
    {% if widget is defined %}
        {% if required %}
            {% set label_attr = label_attr|merge({class: (label_attr.class|default('') ~ ' required')|trim}) %}
        {% endif %}
        {% if parent_label_class is defined %}
            {% set label_attr = label_attr|merge({class: (label_attr.class|default('') ~ ' ' ~ parent_label_class)|trim}) %}
        {% endif %}
        {% if label is not same as(false) and label is empty %}
            {%- if label_format is not empty -%}
                {% set label = label_format|replace({
                    '%name%': name,
                    '%id%': id,
                }) %}
            {%- else -%}
                {% set label = name|humanize %}
            {%- endif -%}
        {% endif %}
        <label{% for attrname, attrvalue in label_attr %} {{ attrname }}=\"{{ attrvalue }}\"{% endfor %}>
            {{- widget|raw }} {{ label is not same as(false) ? (translation_domain is same as(false) ? label : label|trans({}, translation_domain)) -}}
        </label>
    {% endif %}
{% endblock checkbox_radio_label %}

{# Rows #}

{% block form_row -%}
    <div class=\"form-group{% if (not compound or force_error|default(false)) and not valid %} has-error{% endif %}\">
        {{- form_label(form) -}}
        {{- form_widget(form) -}}
        {{- form_errors(form) -}}
    </div>
{%- endblock form_row %}

{% block button_row -%}
    <div class=\"form-group\">
        {{- form_widget(form) -}}
    </div>
{%- endblock button_row %}

{% block choice_row -%}
    {% set force_error = true %}
    {{- block('form_row') }}
{%- endblock choice_row %}

{% block date_row -%}
    {% set force_error = true %}
    {{- block('form_row') }}
{%- endblock date_row %}

{% block time_row -%}
    {% set force_error = true %}
    {{- block('form_row') }}
{%- endblock time_row %}

{% block datetime_row -%}
    {% set force_error = true %}
    {{- block('form_row') }}
{%- endblock datetime_row %}

{% block checkbox_row -%}
    <div class=\"form-group{% if not valid %} has-error{% endif %}\">
        {{- form_widget(form) -}}
        {{- form_errors(form) -}}
    </div>
{%- endblock checkbox_row %}

{% block radio_row -%}
    <div class=\"form-group{% if not valid %} has-error{% endif %}\">
        {{- form_widget(form) -}}
        {{- form_errors(form) -}}
    </div>
{%- endblock radio_row %}

{# Errors #}

{% block form_errors -%}
    {% if errors|length > 0 -%}
    {% if form.parent %}<span class=\"help-block\">{% else %}<div class=\"alert alert-danger\">{% endif %}
    <ul class=\"list-unstyled\">
        {%- for error in errors -%}
            <li><span class=\"glyphicon glyphicon-exclamation-sign\"></span> {{ error.message }}</li>
        {%- endfor -%}
    </ul>
    {% if form.parent %}</span>{% else %}</div>{% endif %}
    {%- endif %}
{%- endblock form_errors %}
", "bootstrap_3_layout.html.twig", "C:\\wamp64\\www\\appli-era\\vendor\\symfony\\symfony\\src\\Symfony\\Bridge\\Twig\\Resources\\views\\Form\\bootstrap_3_layout.html.twig");
    }
}
