<?php

/* admin/default/index.html.twig */
class __TwigTemplate_526e0377375475675f83d38836e27622ece9967348bb6bcadce84bcbeac0688f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("admin/base_admin.html.twig", "admin/default/index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "admin/base_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7e96fa4ded7b5728d1a54d2632dd6db200f3e61d18a09f8083fcffebb67bdf11 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7e96fa4ded7b5728d1a54d2632dd6db200f3e61d18a09f8083fcffebb67bdf11->enter($__internal_7e96fa4ded7b5728d1a54d2632dd6db200f3e61d18a09f8083fcffebb67bdf11_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/default/index.html.twig"));

        $__internal_4e0983ac05fc4c142d69297348c9f04198d9344ffa0eca76516048472a609ed1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4e0983ac05fc4c142d69297348c9f04198d9344ffa0eca76516048472a609ed1->enter($__internal_4e0983ac05fc4c142d69297348c9f04198d9344ffa0eca76516048472a609ed1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/default/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_7e96fa4ded7b5728d1a54d2632dd6db200f3e61d18a09f8083fcffebb67bdf11->leave($__internal_7e96fa4ded7b5728d1a54d2632dd6db200f3e61d18a09f8083fcffebb67bdf11_prof);

        
        $__internal_4e0983ac05fc4c142d69297348c9f04198d9344ffa0eca76516048472a609ed1->leave($__internal_4e0983ac05fc4c142d69297348c9f04198d9344ffa0eca76516048472a609ed1_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_93db99bf60875cfed3f56517bf67dc3db393418445181bb195d593847cb3d812 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_93db99bf60875cfed3f56517bf67dc3db393418445181bb195d593847cb3d812->enter($__internal_93db99bf60875cfed3f56517bf67dc3db393418445181bb195d593847cb3d812_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_995cb62e8cc1468e23906d384549e97b7cc96b8f2120bbfb74af59ea9acf7752 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_995cb62e8cc1468e23906d384549e97b7cc96b8f2120bbfb74af59ea9acf7752->enter($__internal_995cb62e8cc1468e23906d384549e97b7cc96b8f2120bbfb74af59ea9acf7752_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    <h1>Administration</h1>


        ";
        // line 6
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\DumpExtension')->dump($this->env, $context, $this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()));
        echo "


";
        
        $__internal_995cb62e8cc1468e23906d384549e97b7cc96b8f2120bbfb74af59ea9acf7752->leave($__internal_995cb62e8cc1468e23906d384549e97b7cc96b8f2120bbfb74af59ea9acf7752_prof);

        
        $__internal_93db99bf60875cfed3f56517bf67dc3db393418445181bb195d593847cb3d812->leave($__internal_93db99bf60875cfed3f56517bf67dc3db393418445181bb195d593847cb3d812_prof);

    }

    public function getTemplateName()
    {
        return "admin/default/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  54 => 6,  49 => 3,  40 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'admin/base_admin.html.twig' %}
{% block body %}
    <h1>Administration</h1>


        {{ dump(app.user) }}


{% endblock %}
", "admin/default/index.html.twig", "C:\\wamp64\\www\\appli-era\\app\\Resources\\views\\admin\\default\\index.html.twig");
    }
}
