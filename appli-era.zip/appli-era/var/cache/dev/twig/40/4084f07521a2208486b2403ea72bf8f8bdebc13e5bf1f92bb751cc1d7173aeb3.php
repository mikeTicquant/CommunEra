<?php

/* WebProfilerBundle:Profiler:toolbar_redirect.html.twig */
class __TwigTemplate_4605bf05efe8f32a08493f79fd99b767097142122862dfe55af220441a895efe extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_914ba42fdbabd41c18fbce6ca88f13245e1468b3a15740dbcee6c38860a2ea95 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_914ba42fdbabd41c18fbce6ca88f13245e1468b3a15740dbcee6c38860a2ea95->enter($__internal_914ba42fdbabd41c18fbce6ca88f13245e1468b3a15740dbcee6c38860a2ea95_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $__internal_c70c39c2fdcccf074944be0e49f6df27192687c1429f9ea3f1f5f1e2d53bb6a2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c70c39c2fdcccf074944be0e49f6df27192687c1429f9ea3f1f5f1e2d53bb6a2->enter($__internal_c70c39c2fdcccf074944be0e49f6df27192687c1429f9ea3f1f5f1e2d53bb6a2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_914ba42fdbabd41c18fbce6ca88f13245e1468b3a15740dbcee6c38860a2ea95->leave($__internal_914ba42fdbabd41c18fbce6ca88f13245e1468b3a15740dbcee6c38860a2ea95_prof);

        
        $__internal_c70c39c2fdcccf074944be0e49f6df27192687c1429f9ea3f1f5f1e2d53bb6a2->leave($__internal_c70c39c2fdcccf074944be0e49f6df27192687c1429f9ea3f1f5f1e2d53bb6a2_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_8736fc81231164ed06f25e9d5183ca62fce94259431f7c26cfd64d9ed1a7e49b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8736fc81231164ed06f25e9d5183ca62fce94259431f7c26cfd64d9ed1a7e49b->enter($__internal_8736fc81231164ed06f25e9d5183ca62fce94259431f7c26cfd64d9ed1a7e49b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_ba63c11236047fe22636f1472b6f67ecc49ff5038563254b0410233c876a27c9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ba63c11236047fe22636f1472b6f67ecc49ff5038563254b0410233c876a27c9->enter($__internal_ba63c11236047fe22636f1472b6f67ecc49ff5038563254b0410233c876a27c9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_ba63c11236047fe22636f1472b6f67ecc49ff5038563254b0410233c876a27c9->leave($__internal_ba63c11236047fe22636f1472b6f67ecc49ff5038563254b0410233c876a27c9_prof);

        
        $__internal_8736fc81231164ed06f25e9d5183ca62fce94259431f7c26cfd64d9ed1a7e49b->leave($__internal_8736fc81231164ed06f25e9d5183ca62fce94259431f7c26cfd64d9ed1a7e49b_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_0398609ba268dfff9f2bad87f75dc8a699f881e8bae7166752d2eeea6ca9ed57 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0398609ba268dfff9f2bad87f75dc8a699f881e8bae7166752d2eeea6ca9ed57->enter($__internal_0398609ba268dfff9f2bad87f75dc8a699f881e8bae7166752d2eeea6ca9ed57_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_f28d0960bf0c6a19aa1844309448acb91476dea56ab5c1686f8e8cc07adb4057 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f28d0960bf0c6a19aa1844309448acb91476dea56ab5c1686f8e8cc07adb4057->enter($__internal_f28d0960bf0c6a19aa1844309448acb91476dea56ab5c1686f8e8cc07adb4057_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, ($context["location"] ?? $this->getContext($context, "location")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, ($context["location"] ?? $this->getContext($context, "location")), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_f28d0960bf0c6a19aa1844309448acb91476dea56ab5c1686f8e8cc07adb4057->leave($__internal_f28d0960bf0c6a19aa1844309448acb91476dea56ab5c1686f8e8cc07adb4057_prof);

        
        $__internal_0398609ba268dfff9f2bad87f75dc8a699f881e8bae7166752d2eeea6ca9ed57->leave($__internal_0398609ba268dfff9f2bad87f75dc8a699f881e8bae7166752d2eeea6ca9ed57_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 8,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block title 'Redirection Intercepted' %}

{% block body %}
    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"{{ location }}\">{{ location }}</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
{% endblock %}
", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", "C:\\wamp64\\www\\appli-era\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Profiler/toolbar_redirect.html.twig");
    }
}
