<?php

/* ::_nav.html.twig */
class __TwigTemplate_49405d153b7df4349d31b1901fb4fef4851e43262d945427ecae8ae8b9469a4b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c560a65cce8ee61806d0bec00f5fbf51430ba704f75fdd7b42b60d9f2e35298a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c560a65cce8ee61806d0bec00f5fbf51430ba704f75fdd7b42b60d9f2e35298a->enter($__internal_c560a65cce8ee61806d0bec00f5fbf51430ba704f75fdd7b42b60d9f2e35298a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::_nav.html.twig"));

        $__internal_2baa213bc66f0867d63c594660428d58683d630300e876e748e3a017b077d6b6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2baa213bc66f0867d63c594660428d58683d630300e876e748e3a017b077d6b6->enter($__internal_2baa213bc66f0867d63c594660428d58683d630300e876e748e3a017b077d6b6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::_nav.html.twig"));

        // line 1
        $context["prospec_macros"] = $this->loadTemplate("_macro.html.twig", "::_nav.html.twig", 1);
        // line 2
        echo "
";
        // line 3
        $context["currentRoute"] = $this->getAttribute($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "attributes", array()), "get", array(0 => "_route"), "method");
        // line 4
        echo "
<nav class=\"navbar navbar-default navbar-fixed-top\">
    <div class=\"container-fluid\">

        <div class=\"navbar-header\">
            <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#nav\" aria-expanded=\"false\">
                <span class=\"sr-only\">Afficher/Cacher la navigation</span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
            </button>
            <a class=\"navbar-brand animated slideInLeft\" href=\"";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("homepage");
        echo "\">
                PROSPEC
            </a>
        </div>

        <div class=\"collapse navbar-collapse\" id=\"nav\">



            <ul class=\"nav navbar-nav navbar-right\">
                ";
        // line 25
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("IS_AUTHENTICATED_FULLY")) {
            // line 26
            echo "
                    ";
            // line 27
            if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_NEGOCIATEUR")) {
                // line 28
                echo "
                        <li><p class=\"navbar-text\">Bonjour ";
                // line 29
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "username", array()), "html", null, true);
                echo " !</p></li>
                        ";
                // line 30
                echo $context["prospec_macros"]->getnav_li_a("app_user_user_profil", "Mon profil", "user", ($context["currentRoute"] ?? $this->getContext($context, "currentRoute")));
                echo "
                        ";
                // line 31
                echo $context["prospec_macros"]->getnav_li_a("app_user_user_index", "Tableau de bord", "key", ($context["currentRoute"] ?? $this->getContext($context, "currentRoute")));
                echo "
                        ";
                // line 32
                echo $context["prospec_macros"]->getnav_li_a("app_user_user_profil", "Actions", "user-plus");
                echo "

                    ";
            } elseif ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_USER")) {
                // line 35
                echo "
                        <li>Bonjour ";
                // line 36
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "firstname", array()), "html", null, true);
                echo " !</li>
                        ";
                // line 37
                echo $context["prospec_macros"]->getnav_li_a("homepage", "Mon compte", null, ($context["currentRoute"] ?? $this->getContext($context, "currentRoute")));
                echo "
                        ";
                // line 38
                echo $context["prospec_macros"]->getnav_li_a("homepage", "Mes favoris", null, ($context["currentRoute"] ?? $this->getContext($context, "currentRoute")));
                echo "

                    ";
            }
            // line 41
            echo "
                    ";
            // line 42
            echo $context["prospec_macros"]->getnav_li_a("logout", "Déconnexion", null, ($context["currentRoute"] ?? $this->getContext($context, "currentRoute")));
            echo "

                ";
        } else {
            // line 45
            echo "
                    ";
            // line 46
            echo $context["prospec_macros"]->getnav_li_a("app_user_user_signup", "Inscription", "user-plus", ($context["currentRoute"] ?? $this->getContext($context, "currentRoute")));
            echo "
                    ";
            // line 47
            echo $context["prospec_macros"]->getnav_li_a("login", "Mon compte", "user", ($context["currentRoute"] ?? $this->getContext($context, "currentRoute")));
            echo "
                    ";
            // line 48
            echo $context["prospec_macros"]->getnav_li_a("homepage", "Administration", "key", ($context["currentRoute"] ?? $this->getContext($context, "currentRoute")));
            echo "

                ";
        }
        // line 51
        echo "            </ul>

        </div>
    </div>
</nav>
";
        
        $__internal_c560a65cce8ee61806d0bec00f5fbf51430ba704f75fdd7b42b60d9f2e35298a->leave($__internal_c560a65cce8ee61806d0bec00f5fbf51430ba704f75fdd7b42b60d9f2e35298a_prof);

        
        $__internal_2baa213bc66f0867d63c594660428d58683d630300e876e748e3a017b077d6b6->leave($__internal_2baa213bc66f0867d63c594660428d58683d630300e876e748e3a017b077d6b6_prof);

    }

    public function getTemplateName()
    {
        return "::_nav.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  129 => 51,  123 => 48,  119 => 47,  115 => 46,  112 => 45,  106 => 42,  103 => 41,  97 => 38,  93 => 37,  89 => 36,  86 => 35,  80 => 32,  76 => 31,  72 => 30,  68 => 29,  65 => 28,  63 => 27,  60 => 26,  58 => 25,  45 => 15,  32 => 4,  30 => 3,  27 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% import '_macro.html.twig' as prospec_macros %}

{% set currentRoute = app.request.attributes.get('_route') %}

<nav class=\"navbar navbar-default navbar-fixed-top\">
    <div class=\"container-fluid\">

        <div class=\"navbar-header\">
            <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#nav\" aria-expanded=\"false\">
                <span class=\"sr-only\">Afficher/Cacher la navigation</span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
            </button>
            <a class=\"navbar-brand animated slideInLeft\" href=\"{{ path('homepage') }}\">
                PROSPEC
            </a>
        </div>

        <div class=\"collapse navbar-collapse\" id=\"nav\">



            <ul class=\"nav navbar-nav navbar-right\">
                {% if is_granted('IS_AUTHENTICATED_FULLY') %}

                    {% if is_granted('ROLE_NEGOCIATEUR') %}

                        <li><p class=\"navbar-text\">Bonjour {{ app.user.username }} !</p></li>
                        {{ prospec_macros.nav_li_a('app_user_user_profil', 'Mon profil','user',currentRoute) }}
                        {{ prospec_macros.nav_li_a('app_user_user_index', 'Tableau de bord','key',currentRoute) }}
                        {{ prospec_macros.nav_li_a('app_user_user_profil', 'Actions','user-plus') }}

                    {% elseif is_granted('ROLE_USER') %}

                        <li>Bonjour {{ app.user.firstname }} !</li>
                        {{ prospec_macros.nav_li_a('homepage', 'Mon compte', null, currentRoute) }}
                        {{ prospec_macros.nav_li_a('homepage', 'Mes favoris', null, currentRoute) }}

                    {% endif %}

                    {{ prospec_macros.nav_li_a('logout', 'Déconnexion', null, currentRoute) }}

                {% else %}

                    {{ prospec_macros.nav_li_a('app_user_user_signup', 'Inscription', 'user-plus', currentRoute) }}
                    {{ prospec_macros.nav_li_a('login', 'Mon compte', 'user', currentRoute) }}
                    {{ prospec_macros.nav_li_a('homepage', 'Administration', 'key', currentRoute) }}

                {% endif %}
            </ul>

        </div>
    </div>
</nav>
", "::_nav.html.twig", "C:\\wamp64\\www\\appli-era\\app/Resources\\views/_nav.html.twig");
    }
}
