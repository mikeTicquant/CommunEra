<?php

/* reseau/index.html.twig */
class __TwigTemplate_b4af7cf144c924bc6f820b3b70c428bf4cc485863bfde13414f77ec4338ea0c6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "reseau/index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e9dbafdf36d6eedb363aa47cdad8ba7910316dbead495a432d3fde0cfe01c907 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e9dbafdf36d6eedb363aa47cdad8ba7910316dbead495a432d3fde0cfe01c907->enter($__internal_e9dbafdf36d6eedb363aa47cdad8ba7910316dbead495a432d3fde0cfe01c907_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "reseau/index.html.twig"));

        $__internal_a5b856eb5f330ffff9b3914189a26029c1a7fe9b0e6ef111376afdec0a7df691 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a5b856eb5f330ffff9b3914189a26029c1a7fe9b0e6ef111376afdec0a7df691->enter($__internal_a5b856eb5f330ffff9b3914189a26029c1a7fe9b0e6ef111376afdec0a7df691_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "reseau/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e9dbafdf36d6eedb363aa47cdad8ba7910316dbead495a432d3fde0cfe01c907->leave($__internal_e9dbafdf36d6eedb363aa47cdad8ba7910316dbead495a432d3fde0cfe01c907_prof);

        
        $__internal_a5b856eb5f330ffff9b3914189a26029c1a7fe9b0e6ef111376afdec0a7df691->leave($__internal_a5b856eb5f330ffff9b3914189a26029c1a7fe9b0e6ef111376afdec0a7df691_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_908986631d2540c24f53916845be535226158a5266aca419fb361048df3d4fec = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_908986631d2540c24f53916845be535226158a5266aca419fb361048df3d4fec->enter($__internal_908986631d2540c24f53916845be535226158a5266aca419fb361048df3d4fec_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_f33b3cfa4894761cf6a613636ac7b9bc849e6a4766317d144b7b0c4a00d23012 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f33b3cfa4894761cf6a613636ac7b9bc849e6a4766317d144b7b0c4a00d23012->enter($__internal_f33b3cfa4894761cf6a613636ac7b9bc849e6a4766317d144b7b0c4a00d23012_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    <h1>Espace Reseau</h1>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
";
        
        $__internal_f33b3cfa4894761cf6a613636ac7b9bc849e6a4766317d144b7b0c4a00d23012->leave($__internal_f33b3cfa4894761cf6a613636ac7b9bc849e6a4766317d144b7b0c4a00d23012_prof);

        
        $__internal_908986631d2540c24f53916845be535226158a5266aca419fb361048df3d4fec->leave($__internal_908986631d2540c24f53916845be535226158a5266aca419fb361048df3d4fec_prof);

    }

    public function getTemplateName()
    {
        return "reseau/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 3,  40 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block body %}
    <h1>Espace Reseau</h1>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
{% endblock %}", "reseau/index.html.twig", "C:\\wamp64\\www\\appli-era\\app\\Resources\\views\\reseau\\index.html.twig");
    }
}
