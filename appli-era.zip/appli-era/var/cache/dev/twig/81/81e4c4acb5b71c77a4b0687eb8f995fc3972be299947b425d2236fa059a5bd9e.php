<?php

/* @Framework/Form/form_errors.html.php */
class __TwigTemplate_eee9f7b46636b96b348ec436d5894ae81dab8ed0a583921ceaf1591029d61bfe extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_842bb957f9962d5c5bbd6ffdcce556064f7ceb1b70d465cd224577cd0ed27f41 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_842bb957f9962d5c5bbd6ffdcce556064f7ceb1b70d465cd224577cd0ed27f41->enter($__internal_842bb957f9962d5c5bbd6ffdcce556064f7ceb1b70d465cd224577cd0ed27f41_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        $__internal_cfbf8971b515f266d575522f2f31b108548a6a776858aaaf98612ffb7c3c6d78 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cfbf8971b515f266d575522f2f31b108548a6a776858aaaf98612ffb7c3c6d78->enter($__internal_cfbf8971b515f266d575522f2f31b108548a6a776858aaaf98612ffb7c3c6d78_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        // line 1
        echo "<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
";
        
        $__internal_842bb957f9962d5c5bbd6ffdcce556064f7ceb1b70d465cd224577cd0ed27f41->leave($__internal_842bb957f9962d5c5bbd6ffdcce556064f7ceb1b70d465cd224577cd0ed27f41_prof);

        
        $__internal_cfbf8971b515f266d575522f2f31b108548a6a776858aaaf98612ffb7c3c6d78->leave($__internal_cfbf8971b515f266d575522f2f31b108548a6a776858aaaf98612ffb7c3c6d78_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_errors.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
", "@Framework/Form/form_errors.html.php", "C:\\wamp64\\www\\appli-era\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_errors.html.php");
    }
}
