<?php

/* :nego:index.html.twig */
class __TwigTemplate_dd83abb07c3cfcfe6379f6ffc59d4bd93d2fed7a5fa18e82179371c4e7209653 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":nego:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9ecd0a6585d6824e3adffa003a5adf4aa51174f90967eb5b47b88f68fac622f6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9ecd0a6585d6824e3adffa003a5adf4aa51174f90967eb5b47b88f68fac622f6->enter($__internal_9ecd0a6585d6824e3adffa003a5adf4aa51174f90967eb5b47b88f68fac622f6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":nego:index.html.twig"));

        $__internal_fbd8e7e744da6795bf0bea4c0c52312a5d60766e851f9433fe1a304db3c7d0a9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fbd8e7e744da6795bf0bea4c0c52312a5d60766e851f9433fe1a304db3c7d0a9->enter($__internal_fbd8e7e744da6795bf0bea4c0c52312a5d60766e851f9433fe1a304db3c7d0a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":nego:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9ecd0a6585d6824e3adffa003a5adf4aa51174f90967eb5b47b88f68fac622f6->leave($__internal_9ecd0a6585d6824e3adffa003a5adf4aa51174f90967eb5b47b88f68fac622f6_prof);

        
        $__internal_fbd8e7e744da6795bf0bea4c0c52312a5d60766e851f9433fe1a304db3c7d0a9->leave($__internal_fbd8e7e744da6795bf0bea4c0c52312a5d60766e851f9433fe1a304db3c7d0a9_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_5622b36cce339078b8c5409f32e9f29858789ff369bc9960c7a3abc5264bd1e1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5622b36cce339078b8c5409f32e9f29858789ff369bc9960c7a3abc5264bd1e1->enter($__internal_5622b36cce339078b8c5409f32e9f29858789ff369bc9960c7a3abc5264bd1e1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_64ae542c2e9c962b28625141ef13a5117e25e050de1ba3ce796bc09e4071d33e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_64ae542c2e9c962b28625141ef13a5117e25e050de1ba3ce796bc09e4071d33e->enter($__internal_64ae542c2e9c962b28625141ef13a5117e25e050de1ba3ce796bc09e4071d33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    <h1>Espace NEGOCIATEUR</h1>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
";
        
        $__internal_64ae542c2e9c962b28625141ef13a5117e25e050de1ba3ce796bc09e4071d33e->leave($__internal_64ae542c2e9c962b28625141ef13a5117e25e050de1ba3ce796bc09e4071d33e_prof);

        
        $__internal_5622b36cce339078b8c5409f32e9f29858789ff369bc9960c7a3abc5264bd1e1->leave($__internal_5622b36cce339078b8c5409f32e9f29858789ff369bc9960c7a3abc5264bd1e1_prof);

    }

    public function getTemplateName()
    {
        return ":nego:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 3,  40 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block body %}
    <h1>Espace NEGOCIATEUR</h1>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
{% endblock %}", ":nego:index.html.twig", "C:\\wamp64\\www\\appli-era\\app/Resources\\views/nego/index.html.twig");
    }
}
