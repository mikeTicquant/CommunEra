<?php

/* _macro.html.twig */
class __TwigTemplate_51106e9629b7929490199197faac66ac5d8fa80f0e4e28a5f3b644e0eaefc7e4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fb28dc295b29bab6f66e87216ee536feae1cf41650661cdbc45950a0ceb72231 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fb28dc295b29bab6f66e87216ee536feae1cf41650661cdbc45950a0ceb72231->enter($__internal_fb28dc295b29bab6f66e87216ee536feae1cf41650661cdbc45950a0ceb72231_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "_macro.html.twig"));

        $__internal_7c52219a4931444c6c44839afc49e06ffffe24f31a0d9517fe5af3b4175e3b4d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7c52219a4931444c6c44839afc49e06ffffe24f31a0d9517fe5af3b4175e3b4d->enter($__internal_7c52219a4931444c6c44839afc49e06ffffe24f31a0d9517fe5af3b4175e3b4d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "_macro.html.twig"));

        
        $__internal_fb28dc295b29bab6f66e87216ee536feae1cf41650661cdbc45950a0ceb72231->leave($__internal_fb28dc295b29bab6f66e87216ee536feae1cf41650661cdbc45950a0ceb72231_prof);

        
        $__internal_7c52219a4931444c6c44839afc49e06ffffe24f31a0d9517fe5af3b4175e3b4d->leave($__internal_7c52219a4931444c6c44839afc49e06ffffe24f31a0d9517fe5af3b4175e3b4d_prof);

    }

    // line 1
    public function getnav_li_a($__route__ = null, $__name__ = null, $__icon__ = null, $__currentRoute__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "route" => $__route__,
            "name" => $__name__,
            "icon" => $__icon__,
            "currentRoute" => $__currentRoute__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            $__internal_556742f3a9e9fce11b3ad1030faffe8435910f2bf1621e82fe4e14852ae5b744 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
            $__internal_556742f3a9e9fce11b3ad1030faffe8435910f2bf1621e82fe4e14852ae5b744->enter($__internal_556742f3a9e9fce11b3ad1030faffe8435910f2bf1621e82fe4e14852ae5b744_prof = new Twig_Profiler_Profile($this->getTemplateName(), "macro", "nav_li_a"));

            $__internal_745b29d2b26825f11639a288be911716b9bc35c78f39620c068e420f9a52f5cc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
            $__internal_745b29d2b26825f11639a288be911716b9bc35c78f39620c068e420f9a52f5cc->enter($__internal_745b29d2b26825f11639a288be911716b9bc35c78f39620c068e420f9a52f5cc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "macro", "nav_li_a"));

            // line 2
            echo "
    <li class=\"";
            // line 3
            echo ((( !twig_test_empty(($context["currentRoute"] ?? $this->getContext($context, "currentRoute"))) && (($context["route"] ?? $this->getContext($context, "route")) == ($context["currentRoute"] ?? $this->getContext($context, "currentRoute"))))) ? ("active") : (""));
            echo "\">
        <a href=\"";
            // line 4
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath(($context["route"] ?? $this->getContext($context, "route")));
            echo "\">
            ";
            // line 5
            if ((array_key_exists("icon", $context) &&  !twig_test_empty(($context["icon"] ?? $this->getContext($context, "icon"))))) {
                // line 6
                echo "                <span class=\"fa fa-fw fa-";
                echo twig_escape_filter($this->env, ($context["icon"] ?? $this->getContext($context, "icon")), "html", null, true);
                echo "\"></span>
            ";
            }
            // line 8
            echo "            ";
            echo twig_escape_filter($this->env, ($context["name"] ?? $this->getContext($context, "name")), "html", null, true);
            echo "
        </a>
    </li>

";
            
            $__internal_745b29d2b26825f11639a288be911716b9bc35c78f39620c068e420f9a52f5cc->leave($__internal_745b29d2b26825f11639a288be911716b9bc35c78f39620c068e420f9a52f5cc_prof);

            
            $__internal_556742f3a9e9fce11b3ad1030faffe8435910f2bf1621e82fe4e14852ae5b744->leave($__internal_556742f3a9e9fce11b3ad1030faffe8435910f2bf1621e82fe4e14852ae5b744_prof);

        } catch (Exception $e) {
            ob_end_clean();

            throw $e;
        } catch (Throwable $e) {
            ob_end_clean();

            throw $e;
        }

        return ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
    }

    public function getTemplateName()
    {
        return "_macro.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 8,  67 => 6,  65 => 5,  61 => 4,  57 => 3,  54 => 2,  33 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% macro nav_li_a(route, name, icon, currentRoute) %}

    <li class=\"{{ (currentRoute is not empty and route == currentRoute) ? 'active' }}\">
        <a href=\"{{ path(route) }}\">
            {% if icon is defined and icon is not empty %}
                <span class=\"fa fa-fw fa-{{ icon }}\"></span>
            {% endif %}
            {{ name }}
        </a>
    </li>

{% endmacro %}
", "_macro.html.twig", "C:\\wamp64\\www\\appli-era\\app\\Resources\\views\\_macro.html.twig");
    }
}
