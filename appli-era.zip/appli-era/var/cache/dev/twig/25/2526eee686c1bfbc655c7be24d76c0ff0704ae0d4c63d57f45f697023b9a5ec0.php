<?php

/* :admin/user:index.html.twig */
class __TwigTemplate_9e5ac422e20658d571e6169656d405ad896678ff86cb1cc8bf977a4a5eb45cc5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":admin/user:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b6172f855f289e8327d81f9dd007d67aba2d4bd7119584bd1dd151d2a08bcf7a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b6172f855f289e8327d81f9dd007d67aba2d4bd7119584bd1dd151d2a08bcf7a->enter($__internal_b6172f855f289e8327d81f9dd007d67aba2d4bd7119584bd1dd151d2a08bcf7a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":admin/user:index.html.twig"));

        $__internal_810078fe75e386b3ebaad986143e68e595edd125aaf3757ea083e497f85717bd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_810078fe75e386b3ebaad986143e68e595edd125aaf3757ea083e497f85717bd->enter($__internal_810078fe75e386b3ebaad986143e68e595edd125aaf3757ea083e497f85717bd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":admin/user:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b6172f855f289e8327d81f9dd007d67aba2d4bd7119584bd1dd151d2a08bcf7a->leave($__internal_b6172f855f289e8327d81f9dd007d67aba2d4bd7119584bd1dd151d2a08bcf7a_prof);

        
        $__internal_810078fe75e386b3ebaad986143e68e595edd125aaf3757ea083e497f85717bd->leave($__internal_810078fe75e386b3ebaad986143e68e595edd125aaf3757ea083e497f85717bd_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_c2f574e2756dca2b71ccb59f6f543d4b4802e33483945086b8b0f9be075621a9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c2f574e2756dca2b71ccb59f6f543d4b4802e33483945086b8b0f9be075621a9->enter($__internal_c2f574e2756dca2b71ccb59f6f543d4b4802e33483945086b8b0f9be075621a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_5cba629274d2713c19b3813d137724d3e32a915dd07112266985ae1f00fda54d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5cba629274d2713c19b3813d137724d3e32a915dd07112266985ae1f00fda54d->enter($__internal_5cba629274d2713c19b3813d137724d3e32a915dd07112266985ae1f00fda54d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1 class=\"text-center text-uppercase\">Chèvres</h1>
    <ul class=\"list-inline\">
        <li>
            <a class=\"btn btn-xs btn-success\" href=\"";
        // line 7
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_admin_goat_create");
        echo "\">
                <span class=\"fa fa-plus\"></span>
                Créer
            </a>
        </li>
    </ul>
    <div class=\"table-responsive\">
        <table class=\"table table-bordered table-condensed table-hover\">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nom</th>
                    <th>Date de naissance</th>
                    <th>Couleur</th>
                    <th>Nombre de vue(s)</th>
                    <th>Etiquettes</th>
                    <th colspan=\"2\" class=\"sm\"></th>
                </tr>
            </thead>
            <tbody>
                ";
        // line 27
        $context["_token"] = $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderCsrfToken("GOAT_DELETE");
        // line 28
        echo "                ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["goats"] ?? $this->getContext($context, "goats")));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["goat"]) {
            // line 29
            echo "                    <tr>
                        <td>";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute($context["goat"], "id", array()), "html", null, true);
            echo "</td>
                        <td>";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute($context["goat"], "name", array()), "html", null, true);
            echo "</td>
                        <td>";
            // line 32
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["goat"], "birthdate", array())), "html", null, true);
            echo "</td>
                        <td class=\"text-center\"><span class=\"fa fa-square\" style=\"color: #";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute($context["goat"], "color", array()), "html", null, true);
            echo "\"></span></td>
                        <td class=\"text-center\">";
            // line 34
            echo twig_escape_filter($this->env, $this->getAttribute($context["goat"], "views", array()), "html", null, true);
            echo "</td>
                        <td>
                            ";
            // line 36
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($context["goat"], "tags", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["tag"]) {
                // line 37
                echo "                                <span class=\"badge\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["tag"], "name", array()), "html", null, true);
                echo "</span>
                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['tag'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 39
            echo "                        </td>
                        <td class=\"sm\">
                            <a class=\"btn btn-xs btn-warning\" href=\"";
            // line 41
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_admin_goat_update", array("id" => $this->getAttribute($context["goat"], "id", array()))), "html", null, true);
            echo "\">
                                <span class=\"fa fa-pencil\"></span>
                                Modifier
                            </a>
                        </td>
                        <td class=\"sm\">
                            <a class=\"btn btn-xs btn-danger\" href=\"";
            // line 47
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_admin_goat_delete", array("id" => $this->getAttribute($context["goat"], "id", array()), "_token" => ($context["_token"] ?? $this->getContext($context, "_token")))), "html", null, true);
            echo "\">
                                <span class=\"fa fa-trash-o\"></span>
                                Supprimer
                            </a>
                        </td>
                    </tr>
                ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 54
            echo "                    <tr>
                        <td colspan=\"100%\">
                            <p class=\"alert alert-info\">Aucune chèvre trouvée.</p>
                        </td>
                    </tr>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['goat'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 60
        echo "            </tbody>
        </table>
    </div>
";
        
        $__internal_5cba629274d2713c19b3813d137724d3e32a915dd07112266985ae1f00fda54d->leave($__internal_5cba629274d2713c19b3813d137724d3e32a915dd07112266985ae1f00fda54d_prof);

        
        $__internal_c2f574e2756dca2b71ccb59f6f543d4b4802e33483945086b8b0f9be075621a9->leave($__internal_c2f574e2756dca2b71ccb59f6f543d4b4802e33483945086b8b0f9be075621a9_prof);

    }

    public function getTemplateName()
    {
        return ":admin/user:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  158 => 60,  147 => 54,  135 => 47,  126 => 41,  122 => 39,  113 => 37,  109 => 36,  104 => 34,  100 => 33,  96 => 32,  92 => 31,  88 => 30,  85 => 29,  79 => 28,  77 => 27,  54 => 7,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <h1 class=\"text-center text-uppercase\">Chèvres</h1>
    <ul class=\"list-inline\">
        <li>
            <a class=\"btn btn-xs btn-success\" href=\"{{ path('app_admin_goat_create') }}\">
                <span class=\"fa fa-plus\"></span>
                Créer
            </a>
        </li>
    </ul>
    <div class=\"table-responsive\">
        <table class=\"table table-bordered table-condensed table-hover\">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nom</th>
                    <th>Date de naissance</th>
                    <th>Couleur</th>
                    <th>Nombre de vue(s)</th>
                    <th>Etiquettes</th>
                    <th colspan=\"2\" class=\"sm\"></th>
                </tr>
            </thead>
            <tbody>
                {% set _token = csrf_token('GOAT_DELETE') %}
                {% for goat in goats %}
                    <tr>
                        <td>{{ goat.id }}</td>
                        <td>{{ goat.name }}</td>
                        <td>{{ goat.birthdate|date }}</td>
                        <td class=\"text-center\"><span class=\"fa fa-square\" style=\"color: #{{ goat.color }}\"></span></td>
                        <td class=\"text-center\">{{ goat.views }}</td>
                        <td>
                            {% for tag in goat.tags %}
                                <span class=\"badge\">{{ tag.name }}</span>
                            {% endfor %}
                        </td>
                        <td class=\"sm\">
                            <a class=\"btn btn-xs btn-warning\" href=\"{{ path('app_admin_goat_update',{id:goat.id}) }}\">
                                <span class=\"fa fa-pencil\"></span>
                                Modifier
                            </a>
                        </td>
                        <td class=\"sm\">
                            <a class=\"btn btn-xs btn-danger\" href=\"{{ path('app_admin_goat_delete',{id:goat.id,_token:_token}) }}\">
                                <span class=\"fa fa-trash-o\"></span>
                                Supprimer
                            </a>
                        </td>
                    </tr>
                {% else %}
                    <tr>
                        <td colspan=\"100%\">
                            <p class=\"alert alert-info\">Aucune chèvre trouvée.</p>
                        </td>
                    </tr>
                {% endfor %}
            </tbody>
        </table>
    </div>
{% endblock %}
", ":admin/user:index.html.twig", "C:\\wamp64\\www\\appli-era\\app/Resources\\views/admin/user/index.html.twig");
    }
}
