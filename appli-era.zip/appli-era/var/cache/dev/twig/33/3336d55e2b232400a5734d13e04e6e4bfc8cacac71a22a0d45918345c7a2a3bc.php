<?php

/* @Framework/Form/money_widget.html.php */
class __TwigTemplate_2b975ac0ecdcb0b8f9ba78ebecd896e0eb47be8a32c32d0511fde3011742e0bf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_12dfe713752bd0aa71430852f80c3ce2464fe7bd3362619f1d5a272537d02d25 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_12dfe713752bd0aa71430852f80c3ce2464fe7bd3362619f1d5a272537d02d25->enter($__internal_12dfe713752bd0aa71430852f80c3ce2464fe7bd3362619f1d5a272537d02d25_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/money_widget.html.php"));

        $__internal_2cb7be3818213f6dd984ae036f3930bcd3c5ff8127e264ef16ef8e0c20021c98 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2cb7be3818213f6dd984ae036f3930bcd3c5ff8127e264ef16ef8e0c20021c98->enter($__internal_2cb7be3818213f6dd984ae036f3930bcd3c5ff8127e264ef16ef8e0c20021c98_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/money_widget.html.php"));

        // line 1
        echo "<?php echo str_replace('";
        echo twig_escape_filter($this->env, ($context["widget"] ?? $this->getContext($context, "widget")), "html", null, true);
        echo "', \$view['form']->block(\$form, 'form_widget_simple'), \$money_pattern) ?>
";
        
        $__internal_12dfe713752bd0aa71430852f80c3ce2464fe7bd3362619f1d5a272537d02d25->leave($__internal_12dfe713752bd0aa71430852f80c3ce2464fe7bd3362619f1d5a272537d02d25_prof);

        
        $__internal_2cb7be3818213f6dd984ae036f3930bcd3c5ff8127e264ef16ef8e0c20021c98->leave($__internal_2cb7be3818213f6dd984ae036f3930bcd3c5ff8127e264ef16ef8e0c20021c98_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/money_widget.html.php";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo str_replace('{{ widget }}', \$view['form']->block(\$form, 'form_widget_simple'), \$money_pattern) ?>
", "@Framework/Form/money_widget.html.php", "C:\\wamp64\\www\\appli-era\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\money_widget.html.php");
    }
}
