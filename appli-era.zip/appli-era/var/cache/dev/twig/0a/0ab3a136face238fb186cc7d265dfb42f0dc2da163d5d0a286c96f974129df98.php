<?php

/* :user/cda:add.cda.html.twig */
class __TwigTemplate_3a0ac751fe6d094a87270dca0b3c52c9f62dac017ffa51b055cd73e07d8a4dd4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":user/cda:add.cda.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_180615d07e4ce4e4c35456fda4feda12a361eefb8d27c91872a125f49c1a7d97 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_180615d07e4ce4e4c35456fda4feda12a361eefb8d27c91872a125f49c1a7d97->enter($__internal_180615d07e4ce4e4c35456fda4feda12a361eefb8d27c91872a125f49c1a7d97_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":user/cda:add.cda.html.twig"));

        $__internal_4345010bd73e8da81853ac8dececf4aab4260b25e5b8d820746fc543e88f5f72 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4345010bd73e8da81853ac8dececf4aab4260b25e5b8d820746fc543e88f5f72->enter($__internal_4345010bd73e8da81853ac8dececf4aab4260b25e5b8d820746fc543e88f5f72_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":user/cda:add.cda.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_180615d07e4ce4e4c35456fda4feda12a361eefb8d27c91872a125f49c1a7d97->leave($__internal_180615d07e4ce4e4c35456fda4feda12a361eefb8d27c91872a125f49c1a7d97_prof);

        
        $__internal_4345010bd73e8da81853ac8dececf4aab4260b25e5b8d820746fc543e88f5f72->leave($__internal_4345010bd73e8da81853ac8dececf4aab4260b25e5b8d820746fc543e88f5f72_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_88ff46b85845df5c0ae577b31ed404ba4adb97edaf2592bd543702caa16dc720 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_88ff46b85845df5c0ae577b31ed404ba4adb97edaf2592bd543702caa16dc720->enter($__internal_88ff46b85845df5c0ae577b31ed404ba4adb97edaf2592bd543702caa16dc720_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_4ce5bff9a426a77aa78ca8aa1195f861bc1156d6f95c281fc0131c202079ac15 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4ce5bff9a426a77aa78ca8aa1195f861bc1156d6f95c281fc0131c202079ac15->enter($__internal_4ce5bff9a426a77aa78ca8aa1195f861bc1156d6f95c281fc0131c202079ac15_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "

    <div class=\"container content profile\">
        <div class=\"row\">
            <!--Left Sidebar-->
            <div class=\"col-md-3 md-margin-bottom-40\">

                ";
        // line 10
        $context["filename"] = (($this->getAttribute($this->getAttribute(($context["app"] ?? null), "user", array(), "any", false, true), "photo", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute($this->getAttribute(($context["app"] ?? null), "user", array(), "any", false, true), "photo", array()), "img32-md.jpg")) : ("img32-md.jpg"));
        // line 11
        echo "                ";
        $context["url"] = ((($context["globalUserPhotoUri"] ?? $this->getContext($context, "globalUserPhotoUri")) . "/") . ($context["filename"] ?? $this->getContext($context, "filename")));
        // line 12
        echo "                <img class=\"img-thumbnail\" id=\"photo\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl(($context["url"] ?? $this->getContext($context, "url"))), "html", null, true);
        echo "\"/>
                <br><br>
                <ul class=\"list-group sidebar-nav-v1 margin-bottom-40\" id=\"sidebar-nav-1\">
                    <li class=\"list-group-item active\">
                        <a href=\"#\"><i class=\"fa fa-bar-chart-o\"></i> Tableau de bord</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"";
        // line 19
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_profil");
        echo "\"><i class=\"fa fa-user\"></i> Profil</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"";
        // line 22
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_addreseau");
        echo "\"><i class=\"fa fa-group\"></i> Code d'affiliation</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"";
        // line 25
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_addreseau");
        echo "\"><i class=\"fa fa-group\"></i> Reseau</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"";
        // line 28
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_addcda");
        echo "\"><i class=\"fa fa-group\"></i> Cda</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"";
        // line 31
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_addgagence");
        echo "\"><i class=\"fa fa-group\"></i> Groupe Agence</a>
                    </li>

                    <li class=\"list-group-item\">
                        <a href=\"";
        // line 35
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_addreseau");
        echo "\"><i class=\"fa fa-group\"></i> Agence</a>
                    </li>

                    <li class=\"list-group-item\">
                        <a href=\"#\"><i class=\"fa fa-cog\"></i> Settings</a>
                    </li>
                </ul>

            </div>
            <!--End Left Sidebar-->

            <!-- Profile Content -->
            <div class=\"col-md-9\">
                <div class=\"profile-body margin-bottom-20\">

                    <h2 class=\"heading-md\">Code d'affiliation</h2>
                    <br>

                    <dl class=\"dl-horizontal\">
                        <dt></dt>
                        <dd>
                            <section>
                                ";
        // line 57
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start', array("attr" => array("novalidate" => "novalidate")));
        echo "
                                <label class=\"input\">

                                    ";
        // line 60
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start', array("attr" => array("novalidate" => "novalidate")));
        echo "
                                    ";
        // line 61
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        echo "

                                </label>
                            </section>
                            <section>
                                <br>
                                <button class=\"btn-u\" type=\"submit\">Ajouter le code d'affiliation</button>
                                <button type=\"button\" class=\"btn-u btn-u-default\">Annuler</button>
                                ";
        // line 69
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        echo "
                            </section>
                        </dd>

                    </dl>

                </div>

            </div>
        </div>
        <!-- End Profile Content -->
    </div><!--/end row-->




";
        
        $__internal_4ce5bff9a426a77aa78ca8aa1195f861bc1156d6f95c281fc0131c202079ac15->leave($__internal_4ce5bff9a426a77aa78ca8aa1195f861bc1156d6f95c281fc0131c202079ac15_prof);

        
        $__internal_88ff46b85845df5c0ae577b31ed404ba4adb97edaf2592bd543702caa16dc720->leave($__internal_88ff46b85845df5c0ae577b31ed404ba4adb97edaf2592bd543702caa16dc720_prof);

    }

    public function getTemplateName()
    {
        return ":user/cda:add.cda.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  151 => 69,  140 => 61,  136 => 60,  130 => 57,  105 => 35,  98 => 31,  92 => 28,  86 => 25,  80 => 22,  74 => 19,  63 => 12,  60 => 11,  58 => 10,  49 => 3,  40 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block body %}


    <div class=\"container content profile\">
        <div class=\"row\">
            <!--Left Sidebar-->
            <div class=\"col-md-3 md-margin-bottom-40\">

                {% set filename = app.user.photo|default('img32-md.jpg') %}
                {% set url = globalUserPhotoUri ~ '/' ~ filename %}
                <img class=\"img-thumbnail\" id=\"photo\" src=\"{{ asset(url) }}\"/>
                <br><br>
                <ul class=\"list-group sidebar-nav-v1 margin-bottom-40\" id=\"sidebar-nav-1\">
                    <li class=\"list-group-item active\">
                        <a href=\"#\"><i class=\"fa fa-bar-chart-o\"></i> Tableau de bord</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"{{ path('app_user_user_profil') }}\"><i class=\"fa fa-user\"></i> Profil</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"{{ path('app_user_user_addreseau') }}\"><i class=\"fa fa-group\"></i> Code d'affiliation</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"{{ path('app_user_user_addreseau') }}\"><i class=\"fa fa-group\"></i> Reseau</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"{{ path('app_user_user_addcda') }}\"><i class=\"fa fa-group\"></i> Cda</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"{{ path('app_user_user_addgagence') }}\"><i class=\"fa fa-group\"></i> Groupe Agence</a>
                    </li>

                    <li class=\"list-group-item\">
                        <a href=\"{{ path('app_user_user_addreseau') }}\"><i class=\"fa fa-group\"></i> Agence</a>
                    </li>

                    <li class=\"list-group-item\">
                        <a href=\"#\"><i class=\"fa fa-cog\"></i> Settings</a>
                    </li>
                </ul>

            </div>
            <!--End Left Sidebar-->

            <!-- Profile Content -->
            <div class=\"col-md-9\">
                <div class=\"profile-body margin-bottom-20\">

                    <h2 class=\"heading-md\">Code d'affiliation</h2>
                    <br>

                    <dl class=\"dl-horizontal\">
                        <dt></dt>
                        <dd>
                            <section>
                                {{ form_start(form,{attr:{novalidate:'novalidate'}}) }}
                                <label class=\"input\">

                                    {{ form_start(form,{attr:{novalidate:'novalidate'}}) }}
                                    {{ form_widget(form) }}

                                </label>
                            </section>
                            <section>
                                <br>
                                <button class=\"btn-u\" type=\"submit\">Ajouter le code d'affiliation</button>
                                <button type=\"button\" class=\"btn-u btn-u-default\">Annuler</button>
                                {{ form_end(form) }}
                            </section>
                        </dd>

                    </dl>

                </div>

            </div>
        </div>
        <!-- End Profile Content -->
    </div><!--/end row-->




{% endblock %}", ":user/cda:add.cda.html.twig", "C:\\wamp64\\www\\appli-era\\app/Resources\\views/user/cda/add.cda.html.twig");
    }
}
