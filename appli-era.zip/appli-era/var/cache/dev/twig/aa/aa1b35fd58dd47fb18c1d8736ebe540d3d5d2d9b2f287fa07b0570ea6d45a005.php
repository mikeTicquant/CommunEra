<?php

/* menu.html.twig */
class __TwigTemplate_14b514c9697fbbe2cfee5fac676475ca3ca534556a8bc9f5975289e3440c15a0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c14c3a468cd849b87925115c79a94ad409e382706e1557e45d07b834a595878b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c14c3a468cd849b87925115c79a94ad409e382706e1557e45d07b834a595878b->enter($__internal_c14c3a468cd849b87925115c79a94ad409e382706e1557e45d07b834a595878b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "menu.html.twig"));

        $__internal_34250ba4dd1987100b84408ee0de3c1370a8352345947eb386678e26169d9c26 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_34250ba4dd1987100b84408ee0de3c1370a8352345947eb386678e26169d9c26->enter($__internal_34250ba4dd1987100b84408ee0de3c1370a8352345947eb386678e26169d9c26_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "menu.html.twig"));

        
        $__internal_c14c3a468cd849b87925115c79a94ad409e382706e1557e45d07b834a595878b->leave($__internal_c14c3a468cd849b87925115c79a94ad409e382706e1557e45d07b834a595878b_prof);

        
        $__internal_34250ba4dd1987100b84408ee0de3c1370a8352345947eb386678e26169d9c26->leave($__internal_34250ba4dd1987100b84408ee0de3c1370a8352345947eb386678e26169d9c26_prof);

    }

    public function getTemplateName()
    {
        return "menu.html.twig";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "menu.html.twig", "C:\\wamp64\\www\\appli-era\\app\\Resources\\views\\menu.html.twig");
    }
}
