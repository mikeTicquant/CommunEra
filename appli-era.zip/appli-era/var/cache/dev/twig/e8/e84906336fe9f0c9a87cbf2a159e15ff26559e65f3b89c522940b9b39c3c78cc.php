<?php

/* TwigBundle:Exception:error.atom.twig */
class __TwigTemplate_e54ba81b6c17b07d0428a0daedfd35ab467be4baff09be38a39e83aa2f7d3736 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fadd795f71a3299f256815bfca4eeddc421bf8f847e0189c16128e04d6d2fb38 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fadd795f71a3299f256815bfca4eeddc421bf8f847e0189c16128e04d6d2fb38->enter($__internal_fadd795f71a3299f256815bfca4eeddc421bf8f847e0189c16128e04d6d2fb38_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        $__internal_e1826d1d5bb9b6015e7c6922cb1d0ca2c3baeae5119be0a22e17d9b10ec9a30c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e1826d1d5bb9b6015e7c6922cb1d0ca2c3baeae5119be0a22e17d9b10ec9a30c->enter($__internal_e1826d1d5bb9b6015e7c6922cb1d0ca2c3baeae5119be0a22e17d9b10ec9a30c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.atom.twig", 1)->display($context);
        
        $__internal_fadd795f71a3299f256815bfca4eeddc421bf8f847e0189c16128e04d6d2fb38->leave($__internal_fadd795f71a3299f256815bfca4eeddc421bf8f847e0189c16128e04d6d2fb38_prof);

        
        $__internal_e1826d1d5bb9b6015e7c6922cb1d0ca2c3baeae5119be0a22e17d9b10ec9a30c->leave($__internal_e1826d1d5bb9b6015e7c6922cb1d0ca2c3baeae5119be0a22e17d9b10ec9a30c_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.atom.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/error.xml.twig' %}
", "TwigBundle:Exception:error.atom.twig", "C:\\wamp64\\www\\appli-era\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.atom.twig");
    }
}
