<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_cae05033129e673a718ad8a132b696a28ca361b1697bd930631eb9b76a21ddd0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d0d5cb33c45e679b677e559fc5f5a0be5be221d111661fe714629107c0b3071f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d0d5cb33c45e679b677e559fc5f5a0be5be221d111661fe714629107c0b3071f->enter($__internal_d0d5cb33c45e679b677e559fc5f5a0be5be221d111661fe714629107c0b3071f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        $__internal_84d7a7fb271f7b1f6f17d1d90156d66b5faeaef97872859d2a09456638a0e7d3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_84d7a7fb271f7b1f6f17d1d90156d66b5faeaef97872859d2a09456638a0e7d3->enter($__internal_84d7a7fb271f7b1f6f17d1d90156d66b5faeaef97872859d2a09456638a0e7d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_d0d5cb33c45e679b677e559fc5f5a0be5be221d111661fe714629107c0b3071f->leave($__internal_d0d5cb33c45e679b677e559fc5f5a0be5be221d111661fe714629107c0b3071f_prof);

        
        $__internal_84d7a7fb271f7b1f6f17d1d90156d66b5faeaef97872859d2a09456638a0e7d3->leave($__internal_84d7a7fb271f7b1f6f17d1d90156d66b5faeaef97872859d2a09456638a0e7d3_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_452b8ca5e61aed8438859c4d46ddd7ed3b28f9f535d8ccdc4ced93690f9d85b3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_452b8ca5e61aed8438859c4d46ddd7ed3b28f9f535d8ccdc4ced93690f9d85b3->enter($__internal_452b8ca5e61aed8438859c4d46ddd7ed3b28f9f535d8ccdc4ced93690f9d85b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_446893090dcfe0f2973db357ce688d3ff4c28e8ce85b25825fa626a3129751d7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_446893090dcfe0f2973db357ce688d3ff4c28e8ce85b25825fa626a3129751d7->enter($__internal_446893090dcfe0f2973db357ce688d3ff4c28e8ce85b25825fa626a3129751d7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_446893090dcfe0f2973db357ce688d3ff4c28e8ce85b25825fa626a3129751d7->leave($__internal_446893090dcfe0f2973db357ce688d3ff4c28e8ce85b25825fa626a3129751d7_prof);

        
        $__internal_452b8ca5e61aed8438859c4d46ddd7ed3b28f9f535d8ccdc4ced93690f9d85b3->leave($__internal_452b8ca5e61aed8438859c4d46ddd7ed3b28f9f535d8ccdc4ced93690f9d85b3_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "WebProfilerBundle:Profiler:ajax_layout.html.twig", "C:\\wamp64\\www\\appli-era\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Profiler/ajax_layout.html.twig");
    }
}
