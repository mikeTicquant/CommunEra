<?php

/* :security:login.html.twig */
class __TwigTemplate_afa6dd7cf7825f3597a6d75c0822821e3ed60c38cf41704902948a02ca3c3eaa extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":security:login.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3a703ada26550a17af01ae6b949669d6f6c2b6de5fea0f0795458837002f943d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3a703ada26550a17af01ae6b949669d6f6c2b6de5fea0f0795458837002f943d->enter($__internal_3a703ada26550a17af01ae6b949669d6f6c2b6de5fea0f0795458837002f943d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":security:login.html.twig"));

        $__internal_a85ee97aaa8062430d0d76ec7c726f63c2fe60473468ef44c3d455e64ed3aef8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a85ee97aaa8062430d0d76ec7c726f63c2fe60473468ef44c3d455e64ed3aef8->enter($__internal_a85ee97aaa8062430d0d76ec7c726f63c2fe60473468ef44c3d455e64ed3aef8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":security:login.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3a703ada26550a17af01ae6b949669d6f6c2b6de5fea0f0795458837002f943d->leave($__internal_3a703ada26550a17af01ae6b949669d6f6c2b6de5fea0f0795458837002f943d_prof);

        
        $__internal_a85ee97aaa8062430d0d76ec7c726f63c2fe60473468ef44c3d455e64ed3aef8->leave($__internal_a85ee97aaa8062430d0d76ec7c726f63c2fe60473468ef44c3d455e64ed3aef8_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_12c9e514c262c5d3524ef6d6b7c3305cd44972d86ff3c4daddc7b984fc71baf7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_12c9e514c262c5d3524ef6d6b7c3305cd44972d86ff3c4daddc7b984fc71baf7->enter($__internal_12c9e514c262c5d3524ef6d6b7c3305cd44972d86ff3c4daddc7b984fc71baf7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_864e85dc954d8711f86d7a829b46b1c036140a423ccadb82006eb77217220f7c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_864e85dc954d8711f86d7a829b46b1c036140a423ccadb82006eb77217220f7c->enter($__internal_864e85dc954d8711f86d7a829b46b1c036140a423ccadb82006eb77217220f7c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "
 <div class=\"col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2\">
     ";
        // line 5
        if (($context["error"] ?? $this->getContext($context, "error"))) {
            // line 6
            echo "         <div class=\"alert alert-danger animated bounceInDown\">
             ";
            // line 7
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans($this->getAttribute(($context["error"] ?? $this->getContext($context, "error")), "messageKey", array()), $this->getAttribute(($context["error"] ?? $this->getContext($context, "error")), "messageData", array()), "security"), "html", null, true);
            echo "
             <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-label=\"Close\">
                 <span aria-hidden=\"true\">&times;</span>
             </button>
         </div>
     ";
        }
        // line 13
        echo "    <div class=\"margin-top-20\">
        <br>
        <form class=\"reg-page\" action=\"";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("login");
        echo "\" method=\"post\">
            <div class=\"reg-header\">
                <h2>Connexion</h2>
            </div>

            <div class=\"input-group margin-bottom-50\">
                <span class=\"input-group-addon\"><i class=\"fa fa-user\"></i></span>
                <input type=\"text\" placeholder=\"Adresse email\" class=\"form-control\" id=\"username\" name=\"_username\" value=\"";
        // line 22
        echo twig_escape_filter($this->env, ($context["lastUsername"] ?? $this->getContext($context, "lastUsername")), "html", null, true);
        echo "\">
            </div>
            <div class=\"input-group margin-bottom-20\">
                <span class=\"input-group-addon\"><i class=\"fa fa-lock\"></i></span>
                <input type=\"password\" placeholder=\"Mot de passe\"  class=\"form-control\" id=\"password\" name=\"_password\">
            </div>

            <div class=\"row\">
                <div class=\"col-md-6 checkbox\">
                    <label><input type=\"checkbox\"> Restez connecté</label>
                </div>
                <div class=\"col-md-6\">
                    <button class=\"btn-u pull-right\" type=\"submit\">Login</button>
                </div>
            </div>

            <hr>

            <h4>Mot de passe oublié ?</h4>
            <p>Pas de problème, <a class=\"color-green\" href=\"#\">clique ici</a> réintialiser le mot de passe.</p>
        </form>
    </div>
 </div>
";
        
        $__internal_864e85dc954d8711f86d7a829b46b1c036140a423ccadb82006eb77217220f7c->leave($__internal_864e85dc954d8711f86d7a829b46b1c036140a423ccadb82006eb77217220f7c_prof);

        
        $__internal_12c9e514c262c5d3524ef6d6b7c3305cd44972d86ff3c4daddc7b984fc71baf7->leave($__internal_12c9e514c262c5d3524ef6d6b7c3305cd44972d86ff3c4daddc7b984fc71baf7_prof);

    }

    public function getTemplateName()
    {
        return ":security:login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  81 => 22,  71 => 15,  67 => 13,  58 => 7,  55 => 6,  53 => 5,  49 => 3,  40 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block body %}

 <div class=\"col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2\">
     {% if error %}
         <div class=\"alert alert-danger animated bounceInDown\">
             {{ error.messageKey|trans(error.messageData,'security') }}
             <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-label=\"Close\">
                 <span aria-hidden=\"true\">&times;</span>
             </button>
         </div>
     {% endif %}
    <div class=\"margin-top-20\">
        <br>
        <form class=\"reg-page\" action=\"{{ path('login') }}\" method=\"post\">
            <div class=\"reg-header\">
                <h2>Connexion</h2>
            </div>

            <div class=\"input-group margin-bottom-50\">
                <span class=\"input-group-addon\"><i class=\"fa fa-user\"></i></span>
                <input type=\"text\" placeholder=\"Adresse email\" class=\"form-control\" id=\"username\" name=\"_username\" value=\"{{ lastUsername }}\">
            </div>
            <div class=\"input-group margin-bottom-20\">
                <span class=\"input-group-addon\"><i class=\"fa fa-lock\"></i></span>
                <input type=\"password\" placeholder=\"Mot de passe\"  class=\"form-control\" id=\"password\" name=\"_password\">
            </div>

            <div class=\"row\">
                <div class=\"col-md-6 checkbox\">
                    <label><input type=\"checkbox\"> Restez connecté</label>
                </div>
                <div class=\"col-md-6\">
                    <button class=\"btn-u pull-right\" type=\"submit\">Login</button>
                </div>
            </div>

            <hr>

            <h4>Mot de passe oublié ?</h4>
            <p>Pas de problème, <a class=\"color-green\" href=\"#\">clique ici</a> réintialiser le mot de passe.</p>
        </form>
    </div>
 </div>
{% endblock %}", ":security:login.html.twig", "C:\\wamp64\\www\\appli-era\\app/Resources\\views/security/login.html.twig");
    }
}
