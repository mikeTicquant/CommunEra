<?php

/* ::base.html.twig */
class __TwigTemplate_aa068f60139572ba38c888cd19d2a7b936fa05b8d69f1ddd0141087ead89194d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'stylesheet' => array($this, 'block_stylesheet'),
            'navbar' => array($this, 'block_navbar'),
            'body' => array($this, 'block_body'),
            'footer' => array($this, 'block_footer'),
            'javascript' => array($this, 'block_javascript'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_14e04e65f40740fb9707fe263f1d7fff03448fafad69b7772f475dc103b79c36 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_14e04e65f40740fb9707fe263f1d7fff03448fafad69b7772f475dc103b79c36->enter($__internal_14e04e65f40740fb9707fe263f1d7fff03448fafad69b7772f475dc103b79c36_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        $__internal_b33f2e08b7d2f9bbce49459196081914d9ca28e3fa09ca57c531d92d46edd47c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b33f2e08b7d2f9bbce49459196081914d9ca28e3fa09ca57c531d92d46edd47c->enter($__internal_b33f2e08b7d2f9bbce49459196081914d9ca28e3fa09ca57c531d92d46edd47c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<!--[if IE 8]> <html lang=\"en\" class=\"ie8\"> <![endif]-->
<!--[if IE 9]> <html lang=\"en\" class=\"ie9\"> <![endif]-->
<!--[if !IE]><!--> <html lang=\"en\"> <!--<![endif]-->
<head>
\t<title>Gestion des prospections</title>

\t<!-- Meta -->
\t<meta charset=\"utf-8\">
\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
\t<meta name=\"description\" content=\"\">
\t<meta name=\"author\" content=\"\">

\t";
        // line 14
        $this->displayBlock('stylesheet', $context, $blocks);
        // line 50
        echo "</head>

<body class=\"\">
\t<div class=\"wrapper\">
\t\t";
        // line 54
        $this->displayBlock('navbar', $context, $blocks);
        // line 57
        echo "
\t\t<!--=== Content Part ===-->
\t\t<div class=\"container content margin-top-20\">
\t\t\t<div class=\"row\">

                    ";
        // line 62
        echo twig_include($this->env, $context, "_flash.html.twig");
        echo "
\t\t\t\t";
        // line 63
        $this->displayBlock('body', $context, $blocks);
        // line 66
        echo "\t\t\t</div>
\t\t</div><!--/container-->
\t\t<!--=== End Content Part ===-->

\t\t<!--=== Footer Version 1 ===-->
\t\t";
        // line 71
        $this->displayBlock('footer', $context, $blocks);
        // line 74
        echo "\t\t<!--=== End Footer Version 1 ===-->
\t</div>


";
        // line 78
        $this->displayBlock('javascript', $context, $blocks);
        // line 104
        echo "</body>
</html>
";
        
        $__internal_14e04e65f40740fb9707fe263f1d7fff03448fafad69b7772f475dc103b79c36->leave($__internal_14e04e65f40740fb9707fe263f1d7fff03448fafad69b7772f475dc103b79c36_prof);

        
        $__internal_b33f2e08b7d2f9bbce49459196081914d9ca28e3fa09ca57c531d92d46edd47c->leave($__internal_b33f2e08b7d2f9bbce49459196081914d9ca28e3fa09ca57c531d92d46edd47c_prof);

    }

    // line 14
    public function block_stylesheet($context, array $blocks = array())
    {
        $__internal_a9fb80db09e8b805e7fd506056f51ca45993d318726bf559b36209e0c51c9e4a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a9fb80db09e8b805e7fd506056f51ca45993d318726bf559b36209e0c51c9e4a->enter($__internal_a9fb80db09e8b805e7fd506056f51ca45993d318726bf559b36209e0c51c9e4a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheet"));

        $__internal_8e9bf82ef61b2588d0c51ccb6299dcb796787d8541833920ffbc7123e2364e4e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8e9bf82ef61b2588d0c51ccb6299dcb796787d8541833920ffbc7123e2364e4e->enter($__internal_8e9bf82ef61b2588d0c51ccb6299dcb796787d8541833920ffbc7123e2364e4e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheet"));

        // line 15
        echo "\t\t<!-- Favicon -->
\t\t<link rel=\"shortcut icon\" href=\"favicon.ico\">

\t\t<!-- Web Fonts -->
\t\t<link rel='stylesheet' type='text/css' href='//fonts.googleapis.com/css?family=Open+Sans:400,300,600&amp;subset=cyrillic,latin'>

\t\t<!-- CSS Global Compulsory -->
\t\t<link rel=\"stylesheet\" href=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/bootstrap/css/bootstrap.min.css"), "html", null, true);
        echo "\">
\t\t<link rel=\"stylesheet\" href=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/style.css"), "html", null, true);
        echo "\">


\t\t<!-- CSS Header and Footer -->
\t\t<link rel=\"stylesheet\" href=\"";
        // line 27
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/headers/header-default.css"), "html", null, true);
        echo "\">
\t\t<link rel=\"stylesheet\" href=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/footers/footer-v1.css"), "html", null, true);
        echo "\">

\t\t<!-- CSS Implementing Plugins -->
\t\t<link rel=\"stylesheet\" href=\"";
        // line 31
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/animate.css"), "html", null, true);
        echo "\">
\t\t<link rel=\"stylesheet\" href=\"";
        // line 32
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/line-icons/line-icons.css"), "html", null, true);
        echo "\">
\t\t<link rel=\"stylesheet\" href=\"";
        // line 33
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/font-awesome/css/font-awesome.min.css"), "html", null, true);
        echo "\">
\t\t<link rel=\"stylesheet\" href=\"";
        // line 34
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/scrollbar/css/jquery.mCustomScrollbar.css"), "html", null, true);
        echo "\">
\t\t<link rel=\"stylesheet\" href=\"";
        // line 35
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/sky-forms-pro/skyforms/css/sky-forms.css"), "html", null, true);
        echo "\">
\t\t<link rel=\"stylesheet\" href=\"";
        // line 36
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/sky-forms-pro/skyforms/custom/custom-sky-forms.css"), "html", null, true);
        echo "\">

\t\t<!-- CSS Page Style -->
\t\t<link rel=\"stylesheet\" href=\"";
        // line 39
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/pages/page_log_reg_v1.css"), "html", null, true);
        echo "\">
\t\t<link rel=\"stylesheet\" href=\"";
        // line 40
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/pages/profile.css"), "html", null, true);
        echo "\">

\t\t<!-- CSS Theme -->
\t\t<link rel=\"stylesheet\" href=\"";
        // line 43
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/theme-colors/default.css"), "html", null, true);
        echo "\" id=\"style_color\">
\t\t<link rel=\"stylesheet\" href=\"";
        // line 44
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/theme-skins/dark.css"), "html", null, true);
        echo "\">
\t\t<link rel=\"stylesheet\" href=\"";
        // line 45
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/blocks.css"), "html", null, true);
        echo "\">

\t\t<!-- CSS Customization -->
\t\t<link rel=\"stylesheet\" href=\"";
        // line 48
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/custom.css"), "html", null, true);
        echo "\">
\t";
        
        $__internal_8e9bf82ef61b2588d0c51ccb6299dcb796787d8541833920ffbc7123e2364e4e->leave($__internal_8e9bf82ef61b2588d0c51ccb6299dcb796787d8541833920ffbc7123e2364e4e_prof);

        
        $__internal_a9fb80db09e8b805e7fd506056f51ca45993d318726bf559b36209e0c51c9e4a->leave($__internal_a9fb80db09e8b805e7fd506056f51ca45993d318726bf559b36209e0c51c9e4a_prof);

    }

    // line 54
    public function block_navbar($context, array $blocks = array())
    {
        $__internal_8bb7bdbc99a170fb681ae2c4ab5c788e760a44ab8e1c64fb37da66dd45390b11 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8bb7bdbc99a170fb681ae2c4ab5c788e760a44ab8e1c64fb37da66dd45390b11->enter($__internal_8bb7bdbc99a170fb681ae2c4ab5c788e760a44ab8e1c64fb37da66dd45390b11_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "navbar"));

        $__internal_ab58413ff8a9c0f954371372c3e75c223fc69102983076bf511e72c051b6d734 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ab58413ff8a9c0f954371372c3e75c223fc69102983076bf511e72c051b6d734->enter($__internal_ab58413ff8a9c0f954371372c3e75c223fc69102983076bf511e72c051b6d734_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "navbar"));

        // line 55
        echo "\t\t\t";
        $this->loadTemplate("_nav.html.twig", "::base.html.twig", 55)->display($context);
        // line 56
        echo "\t\t";
        
        $__internal_ab58413ff8a9c0f954371372c3e75c223fc69102983076bf511e72c051b6d734->leave($__internal_ab58413ff8a9c0f954371372c3e75c223fc69102983076bf511e72c051b6d734_prof);

        
        $__internal_8bb7bdbc99a170fb681ae2c4ab5c788e760a44ab8e1c64fb37da66dd45390b11->leave($__internal_8bb7bdbc99a170fb681ae2c4ab5c788e760a44ab8e1c64fb37da66dd45390b11_prof);

    }

    // line 63
    public function block_body($context, array $blocks = array())
    {
        $__internal_1fe8ef29243c288fa804c61289b164235381232c4210848c15a83976164ef5aa = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1fe8ef29243c288fa804c61289b164235381232c4210848c15a83976164ef5aa->enter($__internal_1fe8ef29243c288fa804c61289b164235381232c4210848c15a83976164ef5aa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_800d9d000f80b4b2db3b1582bd71636c9631514ee73faa0447a72910d77d6ad6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_800d9d000f80b4b2db3b1582bd71636c9631514ee73faa0447a72910d77d6ad6->enter($__internal_800d9d000f80b4b2db3b1582bd71636c9631514ee73faa0447a72910d77d6ad6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 64
        echo "
\t\t\t\t";
        
        $__internal_800d9d000f80b4b2db3b1582bd71636c9631514ee73faa0447a72910d77d6ad6->leave($__internal_800d9d000f80b4b2db3b1582bd71636c9631514ee73faa0447a72910d77d6ad6_prof);

        
        $__internal_1fe8ef29243c288fa804c61289b164235381232c4210848c15a83976164ef5aa->leave($__internal_1fe8ef29243c288fa804c61289b164235381232c4210848c15a83976164ef5aa_prof);

    }

    // line 71
    public function block_footer($context, array $blocks = array())
    {
        $__internal_a1b566512e60c2870b5d76a5c2c48fec14300cfbc8fa8546660550c4366c64bb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a1b566512e60c2870b5d76a5c2c48fec14300cfbc8fa8546660550c4366c64bb->enter($__internal_a1b566512e60c2870b5d76a5c2c48fec14300cfbc8fa8546660550c4366c64bb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        $__internal_2a9a769f11612e328647e61b82ad641e0725f17b724aa5a82a42a854162bca85 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2a9a769f11612e328647e61b82ad641e0725f17b724aa5a82a42a854162bca85->enter($__internal_2a9a769f11612e328647e61b82ad641e0725f17b724aa5a82a42a854162bca85_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        // line 72
        echo "\t\t\t";
        $this->loadTemplate("_footer.html.twig", "::base.html.twig", 72)->display($context);
        // line 73
        echo "\t\t";
        
        $__internal_2a9a769f11612e328647e61b82ad641e0725f17b724aa5a82a42a854162bca85->leave($__internal_2a9a769f11612e328647e61b82ad641e0725f17b724aa5a82a42a854162bca85_prof);

        
        $__internal_a1b566512e60c2870b5d76a5c2c48fec14300cfbc8fa8546660550c4366c64bb->leave($__internal_a1b566512e60c2870b5d76a5c2c48fec14300cfbc8fa8546660550c4366c64bb_prof);

    }

    // line 78
    public function block_javascript($context, array $blocks = array())
    {
        $__internal_8fce7dae9337d263137fa0628a12330e27b346f67f106020816949c6d8118ecf = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8fce7dae9337d263137fa0628a12330e27b346f67f106020816949c6d8118ecf->enter($__internal_8fce7dae9337d263137fa0628a12330e27b346f67f106020816949c6d8118ecf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascript"));

        $__internal_28ddf230aa15465f03e9bd2b74d40063012e9183ce91b09810f90afa6f28ce86 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_28ddf230aa15465f03e9bd2b74d40063012e9183ce91b09810f90afa6f28ce86->enter($__internal_28ddf230aa15465f03e9bd2b74d40063012e9183ce91b09810f90afa6f28ce86_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascript"));

        // line 79
        echo "
\t<!-- JS Global Compulsory -->
\t<script type=\"text/javascript\" src=\"";
        // line 81
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/jquery/jquery.min.js"), "html", null, true);
        echo "\"></script>
\t<script type=\"text/javascript\" src=\"";
        // line 82
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/jquery/jquery-migrate.min.js"), "html", null, true);
        echo "\"></script>
\t<script type=\"text/javascript\" src=\"";
        // line 83
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/bootstrap/js/bootstrap.min.js"), "html", null, true);
        echo "\"></script>
\t<!-- JS Implementing Plugins -->
\t<script type=\"text/javascript\" src=\"";
        // line 85
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/back-to-top.js"), "html", null, true);
        echo "\"></script>
\t<script type=\"text/javascript\" src=\"";
        // line 86
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/plugins/smoothScroll.js"), "html", null, true);
        echo "\"></script>
\t<!-- JS Customization -->
\t<script type=\"text/javascript\" src=\"";
        // line 88
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/js/custom.js"), "html", null, true);
        echo "\"></script>
\t<!-- JS Page Level -->
\t<script type=\"text/javascript\" src=\"";
        // line 90
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl(""), "html", null, true);
        echo "\"></script>
\t<script type=\"text/javascript\" src=\"assets/js/plugins/style-switcher.js\"></script>
\t<script type=\"text/javascript\">
        jQuery(document).ready(function() {
            App.init();
            StyleSwitcher.initStyleSwitcher();
        });
\t</script>
\t<!--[if lt IE 9]>
\t<script src=\"assets/plugins/respond.js\"></script>
\t<script src=\"assets/plugins/html5shiv.js\"></script>
\t<script src=\"assets/plugins/placeholder-IE-fixes.js\"></script>
\t<![endif]-->
";
        
        $__internal_28ddf230aa15465f03e9bd2b74d40063012e9183ce91b09810f90afa6f28ce86->leave($__internal_28ddf230aa15465f03e9bd2b74d40063012e9183ce91b09810f90afa6f28ce86_prof);

        
        $__internal_8fce7dae9337d263137fa0628a12330e27b346f67f106020816949c6d8118ecf->leave($__internal_8fce7dae9337d263137fa0628a12330e27b346f67f106020816949c6d8118ecf_prof);

    }

    public function getTemplateName()
    {
        return "::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  302 => 90,  297 => 88,  292 => 86,  288 => 85,  283 => 83,  279 => 82,  275 => 81,  271 => 79,  262 => 78,  252 => 73,  249 => 72,  240 => 71,  229 => 64,  220 => 63,  210 => 56,  207 => 55,  198 => 54,  186 => 48,  180 => 45,  176 => 44,  172 => 43,  166 => 40,  162 => 39,  156 => 36,  152 => 35,  148 => 34,  144 => 33,  140 => 32,  136 => 31,  130 => 28,  126 => 27,  119 => 23,  115 => 22,  106 => 15,  97 => 14,  85 => 104,  83 => 78,  77 => 74,  75 => 71,  68 => 66,  66 => 63,  62 => 62,  55 => 57,  53 => 54,  47 => 50,  45 => 14,  30 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<!--[if IE 8]> <html lang=\"en\" class=\"ie8\"> <![endif]-->
<!--[if IE 9]> <html lang=\"en\" class=\"ie9\"> <![endif]-->
<!--[if !IE]><!--> <html lang=\"en\"> <!--<![endif]-->
<head>
\t<title>Gestion des prospections</title>

\t<!-- Meta -->
\t<meta charset=\"utf-8\">
\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
\t<meta name=\"description\" content=\"\">
\t<meta name=\"author\" content=\"\">

\t{% block stylesheet %}
\t\t<!-- Favicon -->
\t\t<link rel=\"shortcut icon\" href=\"favicon.ico\">

\t\t<!-- Web Fonts -->
\t\t<link rel='stylesheet' type='text/css' href='//fonts.googleapis.com/css?family=Open+Sans:400,300,600&amp;subset=cyrillic,latin'>

\t\t<!-- CSS Global Compulsory -->
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/plugins/bootstrap/css/bootstrap.min.css') }}\">
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/css/style.css') }}\">


\t\t<!-- CSS Header and Footer -->
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/css/headers/header-default.css') }}\">
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/css/footers/footer-v1.css') }}\">

\t\t<!-- CSS Implementing Plugins -->
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/plugins/animate.css') }}\">
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/plugins/line-icons/line-icons.css') }}\">
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/plugins/font-awesome/css/font-awesome.min.css') }}\">
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/plugins/scrollbar/css/jquery.mCustomScrollbar.css') }}\">
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/plugins/sky-forms-pro/skyforms/css/sky-forms.css') }}\">
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/plugins/sky-forms-pro/skyforms/custom/custom-sky-forms.css') }}\">

\t\t<!-- CSS Page Style -->
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/css/pages/page_log_reg_v1.css') }}\">
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/css/pages/profile.css') }}\">

\t\t<!-- CSS Theme -->
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/css/theme-colors/default.css') }}\" id=\"style_color\">
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/css/theme-skins/dark.css') }}\">
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/css/blocks.css') }}\">

\t\t<!-- CSS Customization -->
\t\t<link rel=\"stylesheet\" href=\"{{ asset('assets/css/custom.css') }}\">
\t{% endblock %}
</head>

<body class=\"\">
\t<div class=\"wrapper\">
\t\t{% block navbar %}
\t\t\t{% include('_nav.html.twig') %}
\t\t{% endblock %}

\t\t<!--=== Content Part ===-->
\t\t<div class=\"container content margin-top-20\">
\t\t\t<div class=\"row\">

                    {{ include('_flash.html.twig') }}
\t\t\t\t{% block body %}

\t\t\t\t{% endblock %}
\t\t\t</div>
\t\t</div><!--/container-->
\t\t<!--=== End Content Part ===-->

\t\t<!--=== Footer Version 1 ===-->
\t\t{% block footer %}
\t\t\t{% include('_footer.html.twig') %}
\t\t{% endblock %}
\t\t<!--=== End Footer Version 1 ===-->
\t</div>


{% block javascript %}

\t<!-- JS Global Compulsory -->
\t<script type=\"text/javascript\" src=\"{{ asset('assets/plugins/jquery/jquery.min.js') }}\"></script>
\t<script type=\"text/javascript\" src=\"{{ asset('assets/plugins/jquery/jquery-migrate.min.js') }}\"></script>
\t<script type=\"text/javascript\" src=\"{{ asset('assets/plugins/bootstrap/js/bootstrap.min.js') }}\"></script>
\t<!-- JS Implementing Plugins -->
\t<script type=\"text/javascript\" src=\"{{ asset('assets/plugins/back-to-top.js') }}\"></script>
\t<script type=\"text/javascript\" src=\"{{ asset('assets/plugins/smoothScroll.js') }}\"></script>
\t<!-- JS Customization -->
\t<script type=\"text/javascript\" src=\"{{ asset('assets/js/custom.js') }}\"></script>
\t<!-- JS Page Level -->
\t<script type=\"text/javascript\" src=\"{{ asset('') }}\"></script>
\t<script type=\"text/javascript\" src=\"assets/js/plugins/style-switcher.js\"></script>
\t<script type=\"text/javascript\">
        jQuery(document).ready(function() {
            App.init();
            StyleSwitcher.initStyleSwitcher();
        });
\t</script>
\t<!--[if lt IE 9]>
\t<script src=\"assets/plugins/respond.js\"></script>
\t<script src=\"assets/plugins/html5shiv.js\"></script>
\t<script src=\"assets/plugins/placeholder-IE-fixes.js\"></script>
\t<![endif]-->
{% endblock %}
</body>
</html>
", "::base.html.twig", "C:\\wamp64\\www\\appli-era\\app/Resources\\views/base.html.twig");
    }
}
