<?php

/* @Framework/Form/form_widget.html.php */
class __TwigTemplate_43155966c45df880a914bea0e34fee9b9926202925b729a7a23e24bf8e15c10a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_982129be98ae763eed61085a103ac663d7b167060f4b1c0d1d78583576ba3882 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_982129be98ae763eed61085a103ac663d7b167060f4b1c0d1d78583576ba3882->enter($__internal_982129be98ae763eed61085a103ac663d7b167060f4b1c0d1d78583576ba3882_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        $__internal_b832013184d0e89a21b559d81f8d7556c0856fac4b2092dbd7ffcca30b57b11d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b832013184d0e89a21b559d81f8d7556c0856fac4b2092dbd7ffcca30b57b11d->enter($__internal_b832013184d0e89a21b559d81f8d7556c0856fac4b2092dbd7ffcca30b57b11d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        // line 1
        echo "<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
";
        
        $__internal_982129be98ae763eed61085a103ac663d7b167060f4b1c0d1d78583576ba3882->leave($__internal_982129be98ae763eed61085a103ac663d7b167060f4b1c0d1d78583576ba3882_prof);

        
        $__internal_b832013184d0e89a21b559d81f8d7556c0856fac4b2092dbd7ffcca30b57b11d->leave($__internal_b832013184d0e89a21b559d81f8d7556c0856fac4b2092dbd7ffcca30b57b11d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
", "@Framework/Form/form_widget.html.php", "C:\\wamp64\\www\\appli-era\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_widget.html.php");
    }
}
