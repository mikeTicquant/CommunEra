<?php

/* @Framework/Form/password_widget.html.php */
class __TwigTemplate_0b2e340029cc87b1c12b1220a336951822d49ce04d09d92fdb3a875c8bbc0834 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4e32ea7bba4ca31b667ed7e86d4f5a9246b7f2f8488732c8ec46db19b22e28b6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4e32ea7bba4ca31b667ed7e86d4f5a9246b7f2f8488732c8ec46db19b22e28b6->enter($__internal_4e32ea7bba4ca31b667ed7e86d4f5a9246b7f2f8488732c8ec46db19b22e28b6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        $__internal_0f4d3a4ff7435ecec2d00ca8b3846e3577b2f61191f727bdb517069254988e47 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0f4d3a4ff7435ecec2d00ca8b3846e3577b2f61191f727bdb517069254988e47->enter($__internal_0f4d3a4ff7435ecec2d00ca8b3846e3577b2f61191f727bdb517069254988e47_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'password')) ?>
";
        
        $__internal_4e32ea7bba4ca31b667ed7e86d4f5a9246b7f2f8488732c8ec46db19b22e28b6->leave($__internal_4e32ea7bba4ca31b667ed7e86d4f5a9246b7f2f8488732c8ec46db19b22e28b6_prof);

        
        $__internal_0f4d3a4ff7435ecec2d00ca8b3846e3577b2f61191f727bdb517069254988e47->leave($__internal_0f4d3a4ff7435ecec2d00ca8b3846e3577b2f61191f727bdb517069254988e47_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/password_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'password')) ?>
", "@Framework/Form/password_widget.html.php", "C:\\wamp64\\www\\appli-era\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\password_widget.html.php");
    }
}
