<?php

/* user/index.html.twig */
class __TwigTemplate_8ab488b84d4ebd4db6b23cbb429d704d8cdf030f35a30c4195e8ba655dde4fce extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "user/index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_83290cf3ddda2b3c132f56141c6752eb06d3784701753cf3effc01a3670fee03 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_83290cf3ddda2b3c132f56141c6752eb06d3784701753cf3effc01a3670fee03->enter($__internal_83290cf3ddda2b3c132f56141c6752eb06d3784701753cf3effc01a3670fee03_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/index.html.twig"));

        $__internal_21af58ee154a3e49bf04d3f394409fd0a73e39be25a543ff260c66bae924ebe5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_21af58ee154a3e49bf04d3f394409fd0a73e39be25a543ff260c66bae924ebe5->enter($__internal_21af58ee154a3e49bf04d3f394409fd0a73e39be25a543ff260c66bae924ebe5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_83290cf3ddda2b3c132f56141c6752eb06d3784701753cf3effc01a3670fee03->leave($__internal_83290cf3ddda2b3c132f56141c6752eb06d3784701753cf3effc01a3670fee03_prof);

        
        $__internal_21af58ee154a3e49bf04d3f394409fd0a73e39be25a543ff260c66bae924ebe5->leave($__internal_21af58ee154a3e49bf04d3f394409fd0a73e39be25a543ff260c66bae924ebe5_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_062da44bce3f0dc5129330ac5ed2f757385bae4541113b1c9983046540e613c3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_062da44bce3f0dc5129330ac5ed2f757385bae4541113b1c9983046540e613c3->enter($__internal_062da44bce3f0dc5129330ac5ed2f757385bae4541113b1c9983046540e613c3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_7f5da011514d187518ca87b58a850b6bceedc38959c03c4fe65669e3b240b11a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7f5da011514d187518ca87b58a850b6bceedc38959c03c4fe65669e3b240b11a->enter($__internal_7f5da011514d187518ca87b58a850b6bceedc38959c03c4fe65669e3b240b11a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
    <div class=\"container content profile\">
        <div class=\"row\">


            <!-- Profile Content -->
            <div class=\"col-md-12\">
                <div class=\"profile-body margin-bottom-20\">
                    <div class=\"tab-v1\">
                        <ul class=\"nav nav-justified nav-tabs\">
                            <li class=\"active\"><a data-toggle=\"tab\" href=\"#profile\">Premier RDV</a></li>
                            <li><a data-toggle=\"tab\" href=\"#passwordTab\">Estimatoin</a></li>
                            <li><a data-toggle=\"tab\" href=\"#payment\">Estimation rendue</a></li>
                            <li><a data-toggle=\"tab\" href=\"#settings\">Notifications</a></li>
                        </ul>
                        <div class=\"tab-content\">
                            <div id=\"profile\" class=\"profile-edit tab-pane fade in active\">
                                <h2 class=\"heading-md\"></h2>

                                <br>
                                <br>
                                <br>
                                <br>
                                <br>
                                <br>
                                <br>
                                <br>
                                <br>

                                <button type=\"submit\" class=\"btn-u\">Valider les modifications</button>
                                <button type=\"button\" class=\"btn-u btn-u-default\">Annuler</button>

                            </div>

                            <div id=\"passwordTab\" class=\"profile-edit tab-pane fade\">
                                <h2 class=\"heading-md\"></h2>
                                <p></p>
                                <br>

                            </div>

                            <div id=\"payment\" class=\"profile-edit tab-pane fade\">
                                <h2 class=\"heading-md\"></h2>
                                <p></p>
                                <br>

                            </div>

                            <div id=\"settings\" class=\"profile-edit tab-pane fade\">
                                <h2 class=\"heading-md\"></h2>
                                <p></p>
                                <br>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Profile Content -->
        </div><!--/end row-->
    </div>


";
        
        $__internal_7f5da011514d187518ca87b58a850b6bceedc38959c03c4fe65669e3b240b11a->leave($__internal_7f5da011514d187518ca87b58a850b6bceedc38959c03c4fe65669e3b240b11a_prof);

        
        $__internal_062da44bce3f0dc5129330ac5ed2f757385bae4541113b1c9983046540e613c3->leave($__internal_062da44bce3f0dc5129330ac5ed2f757385bae4541113b1c9983046540e613c3_prof);

    }

    public function getTemplateName()
    {
        return "user/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}

    <div class=\"container content profile\">
        <div class=\"row\">


            <!-- Profile Content -->
            <div class=\"col-md-12\">
                <div class=\"profile-body margin-bottom-20\">
                    <div class=\"tab-v1\">
                        <ul class=\"nav nav-justified nav-tabs\">
                            <li class=\"active\"><a data-toggle=\"tab\" href=\"#profile\">Premier RDV</a></li>
                            <li><a data-toggle=\"tab\" href=\"#passwordTab\">Estimatoin</a></li>
                            <li><a data-toggle=\"tab\" href=\"#payment\">Estimation rendue</a></li>
                            <li><a data-toggle=\"tab\" href=\"#settings\">Notifications</a></li>
                        </ul>
                        <div class=\"tab-content\">
                            <div id=\"profile\" class=\"profile-edit tab-pane fade in active\">
                                <h2 class=\"heading-md\"></h2>

                                <br>
                                <br>
                                <br>
                                <br>
                                <br>
                                <br>
                                <br>
                                <br>
                                <br>

                                <button type=\"submit\" class=\"btn-u\">Valider les modifications</button>
                                <button type=\"button\" class=\"btn-u btn-u-default\">Annuler</button>

                            </div>

                            <div id=\"passwordTab\" class=\"profile-edit tab-pane fade\">
                                <h2 class=\"heading-md\"></h2>
                                <p></p>
                                <br>

                            </div>

                            <div id=\"payment\" class=\"profile-edit tab-pane fade\">
                                <h2 class=\"heading-md\"></h2>
                                <p></p>
                                <br>

                            </div>

                            <div id=\"settings\" class=\"profile-edit tab-pane fade\">
                                <h2 class=\"heading-md\"></h2>
                                <p></p>
                                <br>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Profile Content -->
        </div><!--/end row-->
    </div>


{% endblock %}


", "user/index.html.twig", "C:\\wamp64\\www\\appli-era\\app\\Resources\\views\\user\\index.html.twig");
    }
}
