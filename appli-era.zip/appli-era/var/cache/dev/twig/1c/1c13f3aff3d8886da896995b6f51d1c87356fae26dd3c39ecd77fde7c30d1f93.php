<?php

/* user/gagence/gagence.html.twig */
class __TwigTemplate_4eb371face71090eb74cd240a6d045207cd6bf3f4558e7dee94903d7e523a95e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "user/gagence/gagence.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_97f8bd0a6d221e1074af624dfe13e6ecf92e2d0ba63e5185bf867ca5db48a326 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_97f8bd0a6d221e1074af624dfe13e6ecf92e2d0ba63e5185bf867ca5db48a326->enter($__internal_97f8bd0a6d221e1074af624dfe13e6ecf92e2d0ba63e5185bf867ca5db48a326_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/gagence/gagence.html.twig"));

        $__internal_f400a2c118255cd389aa280e9129130d4cf159f84e6349de324fd2e3b42c419f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f400a2c118255cd389aa280e9129130d4cf159f84e6349de324fd2e3b42c419f->enter($__internal_f400a2c118255cd389aa280e9129130d4cf159f84e6349de324fd2e3b42c419f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/gagence/gagence.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_97f8bd0a6d221e1074af624dfe13e6ecf92e2d0ba63e5185bf867ca5db48a326->leave($__internal_97f8bd0a6d221e1074af624dfe13e6ecf92e2d0ba63e5185bf867ca5db48a326_prof);

        
        $__internal_f400a2c118255cd389aa280e9129130d4cf159f84e6349de324fd2e3b42c419f->leave($__internal_f400a2c118255cd389aa280e9129130d4cf159f84e6349de324fd2e3b42c419f_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_cd5ef12ba5d929e539cb7542f3cfcd94d844923012b47b897c1948a2f6d20687 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cd5ef12ba5d929e539cb7542f3cfcd94d844923012b47b897c1948a2f6d20687->enter($__internal_cd5ef12ba5d929e539cb7542f3cfcd94d844923012b47b897c1948a2f6d20687_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_4c1f1e60020bfb7f9ca737ec1d801702937f15abbf54ebdcd55d1fed23b38739 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4c1f1e60020bfb7f9ca737ec1d801702937f15abbf54ebdcd55d1fed23b38739->enter($__internal_4c1f1e60020bfb7f9ca737ec1d801702937f15abbf54ebdcd55d1fed23b38739_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "

    <div class=\"container content profile\">
        <div class=\"row\">
            <!--Left Sidebar-->
            <div class=\"col-md-3 md-margin-bottom-40\">

                ";
        // line 10
        $context["filename"] = (($this->getAttribute($this->getAttribute(($context["app"] ?? null), "user", array(), "any", false, true), "photo", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute($this->getAttribute(($context["app"] ?? null), "user", array(), "any", false, true), "photo", array()), "img32-md.jpg")) : ("img32-md.jpg"));
        // line 11
        echo "                ";
        $context["url"] = ((($context["globalUserPhotoUri"] ?? $this->getContext($context, "globalUserPhotoUri")) . "/") . ($context["filename"] ?? $this->getContext($context, "filename")));
        // line 12
        echo "                <img class=\"img-thumbnail\" id=\"photo\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl(($context["url"] ?? $this->getContext($context, "url"))), "html", null, true);
        echo "\"/>
                <br><br>
                <ul class=\"list-group sidebar-nav-v1 margin-bottom-40\" id=\"sidebar-nav-1\">
                    <li class=\"list-group-item active\">
                        <a href=\"#\"><i class=\"fa fa-bar-chart-o\"></i> Tableau de bord</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"";
        // line 19
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_profil");
        echo "\"><i class=\"fa fa-user\"></i> Profil</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"";
        // line 22
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_addreseau");
        echo "\"><i class=\"fa fa-group\"></i> Code d'affiliation</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"";
        // line 25
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_addreseau");
        echo "\"><i class=\"fa fa-group\"></i> Reseau</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"";
        // line 28
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_addcda");
        echo "\"><i class=\"fa fa-group\"></i> Cda</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"";
        // line 31
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_addgagence");
        echo "\"><i class=\"fa fa-group\"></i> Groupe Agence</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"";
        // line 34
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_addreseau");
        echo "\"><i class=\"fa fa-group\"></i> Agence</a>
                    </li>

                    <li class=\"list-group-item\">
                        <a href=\"#\"><i class=\"fa fa-cog\"></i> Settings</a>
                    </li>
                </ul>

            </div>
            <!--End Left Sidebar-->

            <!-- Profile Content -->
            <div class=\"col-md-9\">
                <div class=\"profile-body margin-bottom-20\">

                    <h2 class=\"heading-md\">Code d'affiliation</h2>
                    <br>

                    <dl class=\"dl-horizontal\">
                        <dt></dt>
                        <dd>
                            ";
        // line 55
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start', array("attr" => array("novalidate" => "novalidate")));
        echo "
                            <section>

                                <label class=\"input\">

                                    ";
        // line 60
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        echo "

                                </label>
                            </section>
                            <section>
                                <br>
                                <button class=\"btn-u\" type=\"submit\">Ajouter le code d'affiliation</button>
                                <button type=\"button\" class=\"btn-u btn-u-default\">Annuler</button>
                                ";
        // line 68
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        echo "
                            </section>
                        </dd>
                    </dl>

                        <br>
                        <hr>

                </div>

            </div>
        </div>
        <!-- End Profile Content -->
    </div><!--/end row-->



";
        
        $__internal_4c1f1e60020bfb7f9ca737ec1d801702937f15abbf54ebdcd55d1fed23b38739->leave($__internal_4c1f1e60020bfb7f9ca737ec1d801702937f15abbf54ebdcd55d1fed23b38739_prof);

        
        $__internal_cd5ef12ba5d929e539cb7542f3cfcd94d844923012b47b897c1948a2f6d20687->leave($__internal_cd5ef12ba5d929e539cb7542f3cfcd94d844923012b47b897c1948a2f6d20687_prof);

    }

    public function getTemplateName()
    {
        return "user/gagence/gagence.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  147 => 68,  136 => 60,  128 => 55,  104 => 34,  98 => 31,  92 => 28,  86 => 25,  80 => 22,  74 => 19,  63 => 12,  60 => 11,  58 => 10,  49 => 3,  40 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block body %}


    <div class=\"container content profile\">
        <div class=\"row\">
            <!--Left Sidebar-->
            <div class=\"col-md-3 md-margin-bottom-40\">

                {% set filename = app.user.photo|default('img32-md.jpg') %}
                {% set url = globalUserPhotoUri ~ '/' ~ filename %}
                <img class=\"img-thumbnail\" id=\"photo\" src=\"{{ asset(url) }}\"/>
                <br><br>
                <ul class=\"list-group sidebar-nav-v1 margin-bottom-40\" id=\"sidebar-nav-1\">
                    <li class=\"list-group-item active\">
                        <a href=\"#\"><i class=\"fa fa-bar-chart-o\"></i> Tableau de bord</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"{{ path('app_user_user_profil') }}\"><i class=\"fa fa-user\"></i> Profil</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"{{ path('app_user_user_addreseau') }}\"><i class=\"fa fa-group\"></i> Code d'affiliation</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"{{ path('app_user_user_addreseau') }}\"><i class=\"fa fa-group\"></i> Reseau</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"{{ path('app_user_user_addcda') }}\"><i class=\"fa fa-group\"></i> Cda</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"{{ path('app_user_user_addgagence') }}\"><i class=\"fa fa-group\"></i> Groupe Agence</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"{{ path('app_user_user_addreseau') }}\"><i class=\"fa fa-group\"></i> Agence</a>
                    </li>

                    <li class=\"list-group-item\">
                        <a href=\"#\"><i class=\"fa fa-cog\"></i> Settings</a>
                    </li>
                </ul>

            </div>
            <!--End Left Sidebar-->

            <!-- Profile Content -->
            <div class=\"col-md-9\">
                <div class=\"profile-body margin-bottom-20\">

                    <h2 class=\"heading-md\">Code d'affiliation</h2>
                    <br>

                    <dl class=\"dl-horizontal\">
                        <dt></dt>
                        <dd>
                            {{ form_start(form,{attr:{novalidate:'novalidate'}}) }}
                            <section>

                                <label class=\"input\">

                                    {{ form_widget(form) }}

                                </label>
                            </section>
                            <section>
                                <br>
                                <button class=\"btn-u\" type=\"submit\">Ajouter le code d'affiliation</button>
                                <button type=\"button\" class=\"btn-u btn-u-default\">Annuler</button>
                                {{ form_end(form) }}
                            </section>
                        </dd>
                    </dl>

                        <br>
                        <hr>

                </div>

            </div>
        </div>
        <!-- End Profile Content -->
    </div><!--/end row-->



{% endblock %}", "user/gagence/gagence.html.twig", "C:\\wamp64\\www\\appli-era\\app\\Resources\\views\\user\\gagence\\gagence.html.twig");
    }
}
