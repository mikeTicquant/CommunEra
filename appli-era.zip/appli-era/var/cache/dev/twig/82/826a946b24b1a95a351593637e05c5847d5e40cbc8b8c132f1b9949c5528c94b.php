<?php

/* @Twig/Exception/error.js.twig */
class __TwigTemplate_0848ea48b99295e47a9f6c24c38a7898512be2ad0ddcdf3b0d827acc7c55d453 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_67b5b130938433954303b10781b371b3320933a5ff78466e8aaa49b1e96ab97c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_67b5b130938433954303b10781b371b3320933a5ff78466e8aaa49b1e96ab97c->enter($__internal_67b5b130938433954303b10781b371b3320933a5ff78466e8aaa49b1e96ab97c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.js.twig"));

        $__internal_126295bf0b1c040e4832a7103e03506ad14caf8a1e234bc027eeaf78b46624b6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_126295bf0b1c040e4832a7103e03506ad14caf8a1e234bc027eeaf78b46624b6->enter($__internal_126295bf0b1c040e4832a7103e03506ad14caf8a1e234bc027eeaf78b46624b6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, ($context["status_code"] ?? $this->getContext($context, "status_code")), "js", null, true);
        echo " ";
        echo twig_escape_filter($this->env, ($context["status_text"] ?? $this->getContext($context, "status_text")), "js", null, true);
        echo "

*/
";
        
        $__internal_67b5b130938433954303b10781b371b3320933a5ff78466e8aaa49b1e96ab97c->leave($__internal_67b5b130938433954303b10781b371b3320933a5ff78466e8aaa49b1e96ab97c_prof);

        
        $__internal_126295bf0b1c040e4832a7103e03506ad14caf8a1e234bc027eeaf78b46624b6->leave($__internal_126295bf0b1c040e4832a7103e03506ad14caf8a1e234bc027eeaf78b46624b6_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ status_code }} {{ status_text }}

*/
", "@Twig/Exception/error.js.twig", "C:\\wamp64\\www\\appli-era\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.js.twig");
    }
}
