<?php

/* :admin/default:index.html.twig */
class __TwigTemplate_2ea2075b9fc15da9e4d03cc34f70cbdb6903602e1a3227ff0ecf1dcd9ea10fa5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":admin/default:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5ec7b7bd6f74ca172affa92fb3f54fc2a8e13bb2f1fe00be96fb77627829d43e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5ec7b7bd6f74ca172affa92fb3f54fc2a8e13bb2f1fe00be96fb77627829d43e->enter($__internal_5ec7b7bd6f74ca172affa92fb3f54fc2a8e13bb2f1fe00be96fb77627829d43e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":admin/default:index.html.twig"));

        $__internal_344e6868c66700338ffac58fa3b590e53bc17e317a9118630951e1b85291095d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_344e6868c66700338ffac58fa3b590e53bc17e317a9118630951e1b85291095d->enter($__internal_344e6868c66700338ffac58fa3b590e53bc17e317a9118630951e1b85291095d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":admin/default:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5ec7b7bd6f74ca172affa92fb3f54fc2a8e13bb2f1fe00be96fb77627829d43e->leave($__internal_5ec7b7bd6f74ca172affa92fb3f54fc2a8e13bb2f1fe00be96fb77627829d43e_prof);

        
        $__internal_344e6868c66700338ffac58fa3b590e53bc17e317a9118630951e1b85291095d->leave($__internal_344e6868c66700338ffac58fa3b590e53bc17e317a9118630951e1b85291095d_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_81842a01d6ff934d9bda26dcf7ddf8e749f486e2109a472f6c55ba4b6c3ff3eb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_81842a01d6ff934d9bda26dcf7ddf8e749f486e2109a472f6c55ba4b6c3ff3eb->enter($__internal_81842a01d6ff934d9bda26dcf7ddf8e749f486e2109a472f6c55ba4b6c3ff3eb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_b7b85efbbdd888ef38bc2054ac509bda6abaab5db6f179b7236c7e12f1de67e0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b7b85efbbdd888ef38bc2054ac509bda6abaab5db6f179b7236c7e12f1de67e0->enter($__internal_b7b85efbbdd888ef38bc2054ac509bda6abaab5db6f179b7236c7e12f1de67e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\DumpExtension')->dump($this->env, $context, $this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()));
        echo "
";
        
        $__internal_b7b85efbbdd888ef38bc2054ac509bda6abaab5db6f179b7236c7e12f1de67e0->leave($__internal_b7b85efbbdd888ef38bc2054ac509bda6abaab5db6f179b7236c7e12f1de67e0_prof);

        
        $__internal_81842a01d6ff934d9bda26dcf7ddf8e749f486e2109a472f6c55ba4b6c3ff3eb->leave($__internal_81842a01d6ff934d9bda26dcf7ddf8e749f486e2109a472f6c55ba4b6c3ff3eb_prof);

    }

    public function getTemplateName()
    {
        return ":admin/default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    {{ dump(app.user) }}
{% endblock %}
", ":admin/default:index.html.twig", "C:\\wamp64\\www\\appli-era\\app/Resources\\views/admin/default/index.html.twig");
    }
}
