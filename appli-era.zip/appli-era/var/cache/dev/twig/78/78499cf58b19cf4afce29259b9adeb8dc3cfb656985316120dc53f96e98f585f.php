<?php

/* @Framework/Form/integer_widget.html.php */
class __TwigTemplate_ad3d50a8c1716d27acccfd469660829cc3a9cac32557a1577eab2d7fd7e5c8a8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5ad3bef1d1a94932dc038264bbe7c351ae36503bfa86d4384bfecf3177664a56 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5ad3bef1d1a94932dc038264bbe7c351ae36503bfa86d4384bfecf3177664a56->enter($__internal_5ad3bef1d1a94932dc038264bbe7c351ae36503bfa86d4384bfecf3177664a56_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/integer_widget.html.php"));

        $__internal_66328ee1b222e3d0c8c7ff2e0d8b755ac254ca1114a141e8c9d8d18a8aff986f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_66328ee1b222e3d0c8c7ff2e0d8b755ac254ca1114a141e8c9d8d18a8aff986f->enter($__internal_66328ee1b222e3d0c8c7ff2e0d8b755ac254ca1114a141e8c9d8d18a8aff986f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/integer_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'number')) ?>
";
        
        $__internal_5ad3bef1d1a94932dc038264bbe7c351ae36503bfa86d4384bfecf3177664a56->leave($__internal_5ad3bef1d1a94932dc038264bbe7c351ae36503bfa86d4384bfecf3177664a56_prof);

        
        $__internal_66328ee1b222e3d0c8c7ff2e0d8b755ac254ca1114a141e8c9d8d18a8aff986f->leave($__internal_66328ee1b222e3d0c8c7ff2e0d8b755ac254ca1114a141e8c9d8d18a8aff986f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/integer_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'number')) ?>
", "@Framework/Form/integer_widget.html.php", "C:\\wamp64\\www\\appli-era\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\integer_widget.html.php");
    }
}
