<?php

/* @Framework/Form/form_end.html.php */
class __TwigTemplate_dece533eae3a867b80852feeb852d1e792806433d3124856faabc9498796bf79 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5099d7664a7a0bc2e625424c7c8b611d74787a7fe9f58acedfbb2cbf735dc039 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5099d7664a7a0bc2e625424c7c8b611d74787a7fe9f58acedfbb2cbf735dc039->enter($__internal_5099d7664a7a0bc2e625424c7c8b611d74787a7fe9f58acedfbb2cbf735dc039_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        $__internal_50befc361cf9079a9d8b1c61065304a18549da010339305e196f2f26adef4aa6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_50befc361cf9079a9d8b1c61065304a18549da010339305e196f2f26adef4aa6->enter($__internal_50befc361cf9079a9d8b1c61065304a18549da010339305e196f2f26adef4aa6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        // line 1
        echo "<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
";
        
        $__internal_5099d7664a7a0bc2e625424c7c8b611d74787a7fe9f58acedfbb2cbf735dc039->leave($__internal_5099d7664a7a0bc2e625424c7c8b611d74787a7fe9f58acedfbb2cbf735dc039_prof);

        
        $__internal_50befc361cf9079a9d8b1c61065304a18549da010339305e196f2f26adef4aa6->leave($__internal_50befc361cf9079a9d8b1c61065304a18549da010339305e196f2f26adef4aa6_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_end.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
", "@Framework/Form/form_end.html.php", "C:\\wamp64\\www\\appli-era\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_end.html.php");
    }
}
