<?php

/* TwigBundle:Exception:error.css.twig */
class __TwigTemplate_27dfc0357f4a86ef8dd9df905b055f309b691c61cae3b23e342a366881a19fbb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_820d2b1c353a1f0990716a37a5479222e087a7131c9efd5caa17646bf6438407 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_820d2b1c353a1f0990716a37a5479222e087a7131c9efd5caa17646bf6438407->enter($__internal_820d2b1c353a1f0990716a37a5479222e087a7131c9efd5caa17646bf6438407_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.css.twig"));

        $__internal_4e755daa1ce86d6d9d7162762db859fc5dc7393f9f8b12221436228174eedbba = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4e755daa1ce86d6d9d7162762db859fc5dc7393f9f8b12221436228174eedbba->enter($__internal_4e755daa1ce86d6d9d7162762db859fc5dc7393f9f8b12221436228174eedbba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, ($context["status_code"] ?? $this->getContext($context, "status_code")), "css", null, true);
        echo " ";
        echo twig_escape_filter($this->env, ($context["status_text"] ?? $this->getContext($context, "status_text")), "css", null, true);
        echo "

*/
";
        
        $__internal_820d2b1c353a1f0990716a37a5479222e087a7131c9efd5caa17646bf6438407->leave($__internal_820d2b1c353a1f0990716a37a5479222e087a7131c9efd5caa17646bf6438407_prof);

        
        $__internal_4e755daa1ce86d6d9d7162762db859fc5dc7393f9f8b12221436228174eedbba->leave($__internal_4e755daa1ce86d6d9d7162762db859fc5dc7393f9f8b12221436228174eedbba_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ status_code }} {{ status_text }}

*/
", "TwigBundle:Exception:error.css.twig", "C:\\wamp64\\www\\appli-era\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.css.twig");
    }
}
