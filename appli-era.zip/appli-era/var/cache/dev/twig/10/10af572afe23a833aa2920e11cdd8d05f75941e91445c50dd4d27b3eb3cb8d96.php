<?php

/* @Framework/Form/button_row.html.php */
class __TwigTemplate_60e4c89623cceb6bbce80753f52f6abb881e1fb7a88d35ada90c333489a8b02f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f2f867ff16a62f1e35ad4cdd4be947d077ad0eb004eedc8d9f149e39158a896b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f2f867ff16a62f1e35ad4cdd4be947d077ad0eb004eedc8d9f149e39158a896b->enter($__internal_f2f867ff16a62f1e35ad4cdd4be947d077ad0eb004eedc8d9f149e39158a896b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        $__internal_e17284bc2c6b274f5b805aff8a3938a55ecae17a6b1a32cf6bf0e28bc9b81a6a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e17284bc2c6b274f5b805aff8a3938a55ecae17a6b1a32cf6bf0e28bc9b81a6a->enter($__internal_e17284bc2c6b274f5b805aff8a3938a55ecae17a6b1a32cf6bf0e28bc9b81a6a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_f2f867ff16a62f1e35ad4cdd4be947d077ad0eb004eedc8d9f149e39158a896b->leave($__internal_f2f867ff16a62f1e35ad4cdd4be947d077ad0eb004eedc8d9f149e39158a896b_prof);

        
        $__internal_e17284bc2c6b274f5b805aff8a3938a55ecae17a6b1a32cf6bf0e28bc9b81a6a->leave($__internal_e17284bc2c6b274f5b805aff8a3938a55ecae17a6b1a32cf6bf0e28bc9b81a6a_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
", "@Framework/Form/button_row.html.php", "C:\\wamp64\\www\\appli-era\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\button_row.html.php");
    }
}
