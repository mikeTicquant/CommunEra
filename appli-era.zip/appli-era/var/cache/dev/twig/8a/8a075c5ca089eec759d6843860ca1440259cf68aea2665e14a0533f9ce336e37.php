<?php

/* _nav.html.twig */
class __TwigTemplate_6b81192f761be876ded73373d905353c7887e0bfdc9c9365779361cfcd39b701 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a0300e273025ec26afa590e2436006a5cffde145a78ad915a0711c0c0430fed1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a0300e273025ec26afa590e2436006a5cffde145a78ad915a0711c0c0430fed1->enter($__internal_a0300e273025ec26afa590e2436006a5cffde145a78ad915a0711c0c0430fed1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "_nav.html.twig"));

        $__internal_9d0159b63e9e7bb652e651fb3a65ab4dc237404756967d5193577e9e5064f0ed = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9d0159b63e9e7bb652e651fb3a65ab4dc237404756967d5193577e9e5064f0ed->enter($__internal_9d0159b63e9e7bb652e651fb3a65ab4dc237404756967d5193577e9e5064f0ed_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "_nav.html.twig"));

        // line 1
        $context["prospec_macros"] = $this->loadTemplate("_macro.html.twig", "_nav.html.twig", 1);
        // line 2
        echo "
";
        // line 3
        $context["currentRoute"] = $this->getAttribute($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "attributes", array()), "get", array(0 => "_route"), "method");
        // line 4
        echo "
<nav class=\"navbar navbar-default navbar-fixed-top\">
    <div class=\"container-fluid\">

        <div class=\"navbar-header\">
            <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#nav\" aria-expanded=\"false\">
                <span class=\"sr-only\">Afficher/Cacher la navigation</span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
            </button>
            <a class=\"navbar-brand animated slideInLeft\" href=\"";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("homepage");
        echo "\">
                PROSPEC
            </a>
        </div>

        <div class=\"collapse navbar-collapse\" id=\"nav\">


            <ul class=\"nav navbar-nav navbar-right\">
                ";
        // line 24
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("IS_AUTHENTICATED_FULLY")) {
            // line 25
            echo "
                    <li><p class=\"navbar-text\">Bonjour ";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "username", array()), "html", null, true);
            echo " !</p></li>
                    <li class=\"dropdown\">
                        <a href=\"";
            // line 28
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_profil");
            echo "\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\">
                            <span class=\"fa fa-fw fa-user-circle\"></span> Mon profil

                            <span class=\"caret\"></span>
                        </a>
                        <ul class=\"dropdown-menu\">
                            <li><a href=\"";
            // line 34
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_index");
            echo "\"><span class=\"fa fa-dashboard\"></span> Tableau de bord</a></li>
                            <li role=\"separator\" class=\"divider\"></li>
                            <li><a href=\"";
            // line 36
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_index");
            echo "\"><span class=\"fa fa-fw fa-tasks\"></span> Actions</a></li>
                            <li role=\"separator\" class=\"divider\"></li>
                            <li><a href=\"";
            // line 38
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_index");
            echo "\"><span class=\"fa fa-fw fa-user-o\"></span> Notification</a></li>
                            <li role=\"separator\" class=\"divider\"></li>
                            <li><a href=\"";
            // line 40
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("logout");
            echo "\"><span class=\"fa fa-fw fa-sign-out\"></span> Déconnexion</a></li>
                        </ul>
                    </li>

                ";
        } else {
            // line 45
            echo "
                    ";
            // line 46
            echo $context["prospec_macros"]->getnav_li_a("app_user_user_signup", "Inscription", "user-plus", ($context["currentRoute"] ?? $this->getContext($context, "currentRoute")));
            echo "
                    ";
            // line 47
            echo $context["prospec_macros"]->getnav_li_a("login", "Mon compte", "user", ($context["currentRoute"] ?? $this->getContext($context, "currentRoute")));
            echo "

                ";
        }
        // line 50
        echo "            </ul>

        </div>
    </div>
</nav>
";
        
        $__internal_a0300e273025ec26afa590e2436006a5cffde145a78ad915a0711c0c0430fed1->leave($__internal_a0300e273025ec26afa590e2436006a5cffde145a78ad915a0711c0c0430fed1_prof);

        
        $__internal_9d0159b63e9e7bb652e651fb3a65ab4dc237404756967d5193577e9e5064f0ed->leave($__internal_9d0159b63e9e7bb652e651fb3a65ab4dc237404756967d5193577e9e5064f0ed_prof);

    }

    public function getTemplateName()
    {
        return "_nav.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  112 => 50,  106 => 47,  102 => 46,  99 => 45,  91 => 40,  86 => 38,  81 => 36,  76 => 34,  67 => 28,  62 => 26,  59 => 25,  57 => 24,  45 => 15,  32 => 4,  30 => 3,  27 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% import '_macro.html.twig' as prospec_macros %}

{% set currentRoute = app.request.attributes.get('_route') %}

<nav class=\"navbar navbar-default navbar-fixed-top\">
    <div class=\"container-fluid\">

        <div class=\"navbar-header\">
            <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#nav\" aria-expanded=\"false\">
                <span class=\"sr-only\">Afficher/Cacher la navigation</span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
            </button>
            <a class=\"navbar-brand animated slideInLeft\" href=\"{{ path('homepage') }}\">
                PROSPEC
            </a>
        </div>

        <div class=\"collapse navbar-collapse\" id=\"nav\">


            <ul class=\"nav navbar-nav navbar-right\">
                {% if is_granted('IS_AUTHENTICATED_FULLY') %}

                    <li><p class=\"navbar-text\">Bonjour {{ app.user.username }} !</p></li>
                    <li class=\"dropdown\">
                        <a href=\"{{ path('app_user_user_profil') }}\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\">
                            <span class=\"fa fa-fw fa-user-circle\"></span> Mon profil

                            <span class=\"caret\"></span>
                        </a>
                        <ul class=\"dropdown-menu\">
                            <li><a href=\"{{ path('app_user_user_index') }}\"><span class=\"fa fa-dashboard\"></span> Tableau de bord</a></li>
                            <li role=\"separator\" class=\"divider\"></li>
                            <li><a href=\"{{ path('app_user_user_index') }}\"><span class=\"fa fa-fw fa-tasks\"></span> Actions</a></li>
                            <li role=\"separator\" class=\"divider\"></li>
                            <li><a href=\"{{ path('app_user_user_index') }}\"><span class=\"fa fa-fw fa-user-o\"></span> Notification</a></li>
                            <li role=\"separator\" class=\"divider\"></li>
                            <li><a href=\"{{ path('logout') }}\"><span class=\"fa fa-fw fa-sign-out\"></span> Déconnexion</a></li>
                        </ul>
                    </li>

                {% else %}

                    {{ prospec_macros.nav_li_a('app_user_user_signup', 'Inscription', 'user-plus', currentRoute) }}
                    {{ prospec_macros.nav_li_a('login', 'Mon compte', 'user', currentRoute) }}

                {% endif %}
            </ul>

        </div>
    </div>
</nav>
", "_nav.html.twig", "C:\\wamp64\\www\\appli-era\\app\\Resources\\views\\_nav.html.twig");
    }
}
