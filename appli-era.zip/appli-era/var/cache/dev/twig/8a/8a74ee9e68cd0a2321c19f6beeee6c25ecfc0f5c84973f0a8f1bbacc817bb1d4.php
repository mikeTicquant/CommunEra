<?php

/* @Framework/Form/number_widget.html.php */
class __TwigTemplate_c4bd20018e0fbad59f3b7de5d1f00ccec1b0d56d952fd169bf466198bb251fef extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3d9a04d3f4745495042099f4c8b3f8cbb8c495c54e6e0f26edd83135691a0b3c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3d9a04d3f4745495042099f4c8b3f8cbb8c495c54e6e0f26edd83135691a0b3c->enter($__internal_3d9a04d3f4745495042099f4c8b3f8cbb8c495c54e6e0f26edd83135691a0b3c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/number_widget.html.php"));

        $__internal_93fad7e3821bb103f1c414f164fd057b84fc38c772cff3f2b302e43a8e65db1a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_93fad7e3821bb103f1c414f164fd057b84fc38c772cff3f2b302e43a8e65db1a->enter($__internal_93fad7e3821bb103f1c414f164fd057b84fc38c772cff3f2b302e43a8e65db1a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/number_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?>
";
        
        $__internal_3d9a04d3f4745495042099f4c8b3f8cbb8c495c54e6e0f26edd83135691a0b3c->leave($__internal_3d9a04d3f4745495042099f4c8b3f8cbb8c495c54e6e0f26edd83135691a0b3c_prof);

        
        $__internal_93fad7e3821bb103f1c414f164fd057b84fc38c772cff3f2b302e43a8e65db1a->leave($__internal_93fad7e3821bb103f1c414f164fd057b84fc38c772cff3f2b302e43a8e65db1a_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/number_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?>
", "@Framework/Form/number_widget.html.php", "C:\\wamp64\\www\\appli-era\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\number_widget.html.php");
    }
}
