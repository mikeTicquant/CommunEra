<?php

/* default/register.html.twig */
class __TwigTemplate_cd381826b50281cd25aa5cd9db15c3810be034cfb92f1d65f68e1e660ec0ee72 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/register.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cdc3769207e9424ec38ededf20ea301c1a20a85d53dcfa85866224b60af18aea = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cdc3769207e9424ec38ededf20ea301c1a20a85d53dcfa85866224b60af18aea->enter($__internal_cdc3769207e9424ec38ededf20ea301c1a20a85d53dcfa85866224b60af18aea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/register.html.twig"));

        $__internal_f43e7037186fbbea5a646a9645de71673460bdf166410c7998e0cc37bbd7c4b1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f43e7037186fbbea5a646a9645de71673460bdf166410c7998e0cc37bbd7c4b1->enter($__internal_f43e7037186fbbea5a646a9645de71673460bdf166410c7998e0cc37bbd7c4b1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/register.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_cdc3769207e9424ec38ededf20ea301c1a20a85d53dcfa85866224b60af18aea->leave($__internal_cdc3769207e9424ec38ededf20ea301c1a20a85d53dcfa85866224b60af18aea_prof);

        
        $__internal_f43e7037186fbbea5a646a9645de71673460bdf166410c7998e0cc37bbd7c4b1->leave($__internal_f43e7037186fbbea5a646a9645de71673460bdf166410c7998e0cc37bbd7c4b1_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_6e73140319593c424a03c6bce5e477efd99133f7616c96bb81f40b863243be23 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6e73140319593c424a03c6bce5e477efd99133f7616c96bb81f40b863243be23->enter($__internal_6e73140319593c424a03c6bce5e477efd99133f7616c96bb81f40b863243be23_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_3c572057daa54175a55f3242da6ea124183062125e9f35ec681c1e2c532a520a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3c572057daa54175a55f3242da6ea124183062125e9f35ec681c1e2c532a520a->enter($__internal_3c572057daa54175a55f3242da6ea124183062125e9f35ec681c1e2c532a520a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "<div class=\"page-register\">

    <div class=\"container content\">
        <div class=\"row\">
            <div class=\"col-md-8 col-md-offset-2\">


                    <fieldset>
                    <div>
                        <div class=\"headline\"><h2>Bienvenue sur PROSPEC-FLY</h2></div>
                        <p>Déjà inscrit? Cliquez sur <a href=\"";
        // line 13
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("login");
        echo "\" class=\"color-blue\">Se connecter</a> pour vous connecter à votre compte.</p>
                    </div>
                        <h3>Vos coordonnées personnelles</h3>
                    </fieldset>

                    <fieldset>
                        ";
        // line 19
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start', array("attr" => array("novalidate" => "novalidate")));
        echo "
                        ";
        // line 20
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "civility", array()), 'row');
        echo "
                        ";
        // line 21
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "first_name", array()), 'row');
        echo "
                        ";
        // line 22
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "last_name", array()), 'row');
        echo "
                        ";
        // line 23
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "email", array()), 'row');
        echo "
                        ";
        // line 24
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "job", array()), 'row');
        echo "
                        ";
        // line 25
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "role", array()), 'row');
        echo "
                        ";
        // line 26
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "address_street", array()), 'row');
        echo "
                        ";
        // line 27
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "address_postal_code", array()), 'row');
        echo "
                        ";
        // line 28
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "address_city", array()), 'row');
        echo "
                        ";
        // line 29
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "rawPassword", array()), 'row');
        echo "
                        ";
        // line 30
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "photoFile", array()), 'row');
        echo "
                        <hr>
                        <h3>Votre entreprise</h3>

                        ";
        // line 34
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["formBusiness"] ?? $this->getContext($context, "formBusiness")), 'row');
        echo "

                    </fieldset>
                    <button class=\"btn-u\" type=\"submit\">S'inscrie</button>
                    ";
        // line 38
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        echo "

            </div>
        </div>
    </div>

</div>
";
        
        $__internal_3c572057daa54175a55f3242da6ea124183062125e9f35ec681c1e2c532a520a->leave($__internal_3c572057daa54175a55f3242da6ea124183062125e9f35ec681c1e2c532a520a_prof);

        
        $__internal_6e73140319593c424a03c6bce5e477efd99133f7616c96bb81f40b863243be23->leave($__internal_6e73140319593c424a03c6bce5e477efd99133f7616c96bb81f40b863243be23_prof);

    }

    public function getTemplateName()
    {
        return "default/register.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  128 => 38,  121 => 34,  114 => 30,  110 => 29,  106 => 28,  102 => 27,  98 => 26,  94 => 25,  90 => 24,  86 => 23,  82 => 22,  78 => 21,  74 => 20,  70 => 19,  61 => 13,  49 => 3,  40 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block body %}
<div class=\"page-register\">

    <div class=\"container content\">
        <div class=\"row\">
            <div class=\"col-md-8 col-md-offset-2\">


                    <fieldset>
                    <div>
                        <div class=\"headline\"><h2>Bienvenue sur PROSPEC-FLY</h2></div>
                        <p>Déjà inscrit? Cliquez sur <a href=\"{{ path(\"login\") }}\" class=\"color-blue\">Se connecter</a> pour vous connecter à votre compte.</p>
                    </div>
                        <h3>Vos coordonnées personnelles</h3>
                    </fieldset>

                    <fieldset>
                        {{ form_start(form,{attr:{novalidate:'novalidate'}}) }}
                        {{ form_row(form.civility) }}
                        {{ form_row(form.first_name) }}
                        {{ form_row(form.last_name) }}
                        {{ form_row(form.email) }}
                        {{ form_row(form.job) }}
                        {{ form_row(form.role) }}
                        {{ form_row(form.address_street) }}
                        {{ form_row(form.address_postal_code) }}
                        {{ form_row(form.address_city) }}
                        {{ form_row(form.rawPassword) }}
                        {{ form_row(form.photoFile) }}
                        <hr>
                        <h3>Votre entreprise</h3>

                        {{ form_row(formBusiness) }}

                    </fieldset>
                    <button class=\"btn-u\" type=\"submit\">S'inscrie</button>
                    {{ form_end(form) }}

            </div>
        </div>
    </div>

</div>
{% endblock %}
", "default/register.html.twig", "C:\\wamp64\\www\\appli-era\\app\\Resources\\views\\default\\register.html.twig");
    }
}
