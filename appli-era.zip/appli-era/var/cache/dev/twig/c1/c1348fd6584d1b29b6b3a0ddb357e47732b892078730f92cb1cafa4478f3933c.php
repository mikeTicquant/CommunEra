<?php

/* grpagence/index.html.twig */
class __TwigTemplate_059d8ea11ae9a7a5ad65b41f058c12345b9b37d7c2040dee319bbdc6a0420e4a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "grpagence/index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c5fa9ccb720afe10d22563daf4ef04d1981ae72d52929b1d8e8392f77fb31c97 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c5fa9ccb720afe10d22563daf4ef04d1981ae72d52929b1d8e8392f77fb31c97->enter($__internal_c5fa9ccb720afe10d22563daf4ef04d1981ae72d52929b1d8e8392f77fb31c97_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "grpagence/index.html.twig"));

        $__internal_eef79dbe03e01566127707b4a7283648a0c91a0d608fe86fc8f3d2cf8ec2a567 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eef79dbe03e01566127707b4a7283648a0c91a0d608fe86fc8f3d2cf8ec2a567->enter($__internal_eef79dbe03e01566127707b4a7283648a0c91a0d608fe86fc8f3d2cf8ec2a567_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "grpagence/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c5fa9ccb720afe10d22563daf4ef04d1981ae72d52929b1d8e8392f77fb31c97->leave($__internal_c5fa9ccb720afe10d22563daf4ef04d1981ae72d52929b1d8e8392f77fb31c97_prof);

        
        $__internal_eef79dbe03e01566127707b4a7283648a0c91a0d608fe86fc8f3d2cf8ec2a567->leave($__internal_eef79dbe03e01566127707b4a7283648a0c91a0d608fe86fc8f3d2cf8ec2a567_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_8a4cadd1b92400f3bf8930cb866c098f3fbc7850431ae9eb9ca38a33d0d3fbe8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8a4cadd1b92400f3bf8930cb866c098f3fbc7850431ae9eb9ca38a33d0d3fbe8->enter($__internal_8a4cadd1b92400f3bf8930cb866c098f3fbc7850431ae9eb9ca38a33d0d3fbe8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_892d615c60661736717c8dcb52245c4e328fa9d9bfdd8f9b401e85196871f088 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_892d615c60661736717c8dcb52245c4e328fa9d9bfdd8f9b401e85196871f088->enter($__internal_892d615c60661736717c8dcb52245c4e328fa9d9bfdd8f9b401e85196871f088_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    <h1>Espace Groupe Agence</h1>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
";
        
        $__internal_892d615c60661736717c8dcb52245c4e328fa9d9bfdd8f9b401e85196871f088->leave($__internal_892d615c60661736717c8dcb52245c4e328fa9d9bfdd8f9b401e85196871f088_prof);

        
        $__internal_8a4cadd1b92400f3bf8930cb866c098f3fbc7850431ae9eb9ca38a33d0d3fbe8->leave($__internal_8a4cadd1b92400f3bf8930cb866c098f3fbc7850431ae9eb9ca38a33d0d3fbe8_prof);

    }

    public function getTemplateName()
    {
        return "grpagence/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 3,  40 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block body %}
    <h1>Espace Groupe Agence</h1>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
{% endblock %}", "grpagence/index.html.twig", "C:\\wamp64\\www\\appli-era\\app\\Resources\\views\\grpagence\\index.html.twig");
    }
}
