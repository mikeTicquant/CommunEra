<?php

/* @Framework/FormTable/form_row.html.php */
class __TwigTemplate_2fbcc80903a889934e317688aaa3542d6cbe402c5fabaef50deacacf2f79db7f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_aec7089d66eaf6c1e6c1e2b9e7370a1726841fdbf5fd909f9bdc13a1c967d908 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_aec7089d66eaf6c1e6c1e2b9e7370a1726841fdbf5fd909f9bdc13a1c967d908->enter($__internal_aec7089d66eaf6c1e6c1e2b9e7370a1726841fdbf5fd909f9bdc13a1c967d908_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        $__internal_21d9122c34f68ddd30be989db03c12850815dfe0513e6033f5bf6a6f20105dbc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_21d9122c34f68ddd30be989db03c12850815dfe0513e6033f5bf6a6f20105dbc->enter($__internal_21d9122c34f68ddd30be989db03c12850815dfe0513e6033f5bf6a6f20105dbc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        // line 1
        echo "<tr>
    <td>
        <?php echo \$view['form']->label(\$form) ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form) ?>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_aec7089d66eaf6c1e6c1e2b9e7370a1726841fdbf5fd909f9bdc13a1c967d908->leave($__internal_aec7089d66eaf6c1e6c1e2b9e7370a1726841fdbf5fd909f9bdc13a1c967d908_prof);

        
        $__internal_21d9122c34f68ddd30be989db03c12850815dfe0513e6033f5bf6a6f20105dbc->leave($__internal_21d9122c34f68ddd30be989db03c12850815dfe0513e6033f5bf6a6f20105dbc_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr>
    <td>
        <?php echo \$view['form']->label(\$form) ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form) ?>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
", "@Framework/FormTable/form_row.html.php", "C:\\wamp64\\www\\appli-era\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\FormTable\\form_row.html.php");
    }
}
