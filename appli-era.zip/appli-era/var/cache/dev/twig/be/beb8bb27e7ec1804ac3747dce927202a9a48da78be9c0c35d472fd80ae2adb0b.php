<?php

/* notif/index.html.twig */
class __TwigTemplate_9964a364d8c13e4be051e510b709458db31884386baeece55303a4719e71d186 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "notif/index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9f6acd65453a545cd9e92d96df031df42034fd9753b4c3fb5e36f829b0f43815 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9f6acd65453a545cd9e92d96df031df42034fd9753b4c3fb5e36f829b0f43815->enter($__internal_9f6acd65453a545cd9e92d96df031df42034fd9753b4c3fb5e36f829b0f43815_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "notif/index.html.twig"));

        $__internal_483b7c8828238b3617bd31791faf07ab027c43122f79c8b623f363cd9c64b971 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_483b7c8828238b3617bd31791faf07ab027c43122f79c8b623f363cd9c64b971->enter($__internal_483b7c8828238b3617bd31791faf07ab027c43122f79c8b623f363cd9c64b971_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "notif/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9f6acd65453a545cd9e92d96df031df42034fd9753b4c3fb5e36f829b0f43815->leave($__internal_9f6acd65453a545cd9e92d96df031df42034fd9753b4c3fb5e36f829b0f43815_prof);

        
        $__internal_483b7c8828238b3617bd31791faf07ab027c43122f79c8b623f363cd9c64b971->leave($__internal_483b7c8828238b3617bd31791faf07ab027c43122f79c8b623f363cd9c64b971_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_f16d9d40bf8ae3263ac847091e48e4a7b63dd0a341c8590af4a821f52510adcc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f16d9d40bf8ae3263ac847091e48e4a7b63dd0a341c8590af4a821f52510adcc->enter($__internal_f16d9d40bf8ae3263ac847091e48e4a7b63dd0a341c8590af4a821f52510adcc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_ee8e3b7daa42daee8225c58f66b81c72e8adabcade0ed2f167391e2d647d92c5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ee8e3b7daa42daee8225c58f66b81c72e8adabcade0ed2f167391e2d647d92c5->enter($__internal_ee8e3b7daa42daee8225c58f66b81c72e8adabcade0ed2f167391e2d647d92c5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "
    <div class=\"container content profile\">
        <div class=\"row\">
            <!--Left Sidebar-->
            <div class=\"col-md-3 md-margin-bottom-40\">

                ";
        // line 11
        $context["filename"] = (($this->getAttribute($this->getAttribute(($context["app"] ?? null), "user", array(), "any", false, true), "photo", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute($this->getAttribute(($context["app"] ?? null), "user", array(), "any", false, true), "photo", array()), "img32-md.jpg")) : ("img32-md.jpg"));
        // line 12
        echo "                ";
        $context["url"] = ((($context["globalUserPhotoUri"] ?? $this->getContext($context, "globalUserPhotoUri")) . "/") . ($context["filename"] ?? $this->getContext($context, "filename")));
        // line 13
        echo "                <img class=\"img-thumbnail\" id=\"photo\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl(($context["url"] ?? $this->getContext($context, "url"))), "html", null, true);
        echo "\"/>
                <br><br>
                <ul class=\"list-group sidebar-nav-v1 margin-bottom-40\" id=\"sidebar-nav-1\">
                    <li class=\"list-group-item active\">
                        <a href=\"#\"><i class=\"fa fa-bar-chart-o\"></i> Tableau de bord</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"";
        // line 20
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_profil");
        echo "\">
                            <i class=\"fa fa-user\"></i> Profil
                        </a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"";
        // line 25
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_profil");
        echo "\">
                            <i class=\"fa fa-building-o\"></i> Entreprise
                        </a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"";
        // line 30
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_affiliate");
        echo "\">
                            <i class=\"fa fa-flag-o\"></i> Code d'affialition
                        </a>
                    </li>


                    <li class=\"list-group-item\">
                        <a href=\"#\"><i class=\"fa fa-cog\"></i> Settings</a>
                    </li>
                </ul>

            </div>
            <!--End Left Sidebar-->

            <!-- Profile Content -->

            <div class=\"col-md-9\">

                <div class=\"profile-body\">
                    <div class=\"tab-v1\">
                            ";
        // line 50
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start');
        echo "
                            ";
        // line 51
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "alert", array()), 'row');
        echo "
                            ";
        // line 52
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "code", array()), 'row', array("attr" => array("disabled" => "disabled")));
        echo "
                            ";
        // line 53
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "liste", array()), 'row');
        echo "
                            ";
        // line 54
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        echo "
                    </div>
                    <input type=\"submit\" value=\"ENVOYER\">
                </div>

            </div>
            <!-- End Profile Content -->
    </div>

    <!-- End Profile Content -->

    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>

";
        
        $__internal_ee8e3b7daa42daee8225c58f66b81c72e8adabcade0ed2f167391e2d647d92c5->leave($__internal_ee8e3b7daa42daee8225c58f66b81c72e8adabcade0ed2f167391e2d647d92c5_prof);

        
        $__internal_f16d9d40bf8ae3263ac847091e48e4a7b63dd0a341c8590af4a821f52510adcc->leave($__internal_f16d9d40bf8ae3263ac847091e48e4a7b63dd0a341c8590af4a821f52510adcc_prof);

    }

    public function getTemplateName()
    {
        return "notif/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  128 => 54,  124 => 53,  120 => 52,  116 => 51,  112 => 50,  89 => 30,  81 => 25,  73 => 20,  62 => 13,  59 => 12,  57 => 11,  49 => 5,  40 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}


{% block body %}

    <div class=\"container content profile\">
        <div class=\"row\">
            <!--Left Sidebar-->
            <div class=\"col-md-3 md-margin-bottom-40\">

                {% set filename = app.user.photo|default('img32-md.jpg') %}
                {% set url = globalUserPhotoUri ~ '/' ~ filename %}
                <img class=\"img-thumbnail\" id=\"photo\" src=\"{{ asset(url) }}\"/>
                <br><br>
                <ul class=\"list-group sidebar-nav-v1 margin-bottom-40\" id=\"sidebar-nav-1\">
                    <li class=\"list-group-item active\">
                        <a href=\"#\"><i class=\"fa fa-bar-chart-o\"></i> Tableau de bord</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"{{ path('app_user_user_profil') }}\">
                            <i class=\"fa fa-user\"></i> Profil
                        </a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"{{ path('app_user_user_profil') }}\">
                            <i class=\"fa fa-building-o\"></i> Entreprise
                        </a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"{{ path('app_user_user_affiliate') }}\">
                            <i class=\"fa fa-flag-o\"></i> Code d'affialition
                        </a>
                    </li>


                    <li class=\"list-group-item\">
                        <a href=\"#\"><i class=\"fa fa-cog\"></i> Settings</a>
                    </li>
                </ul>

            </div>
            <!--End Left Sidebar-->

            <!-- Profile Content -->

            <div class=\"col-md-9\">

                <div class=\"profile-body\">
                    <div class=\"tab-v1\">
                            {{ form_start(form) }}
                            {{ form_row(form.alert) }}
                            {{ form_row(form.code, {'attr' : {'disabled':'disabled'}}) }}
                            {{ form_row(form.liste) }}
                            {{ form_end(form) }}
                    </div>
                    <input type=\"submit\" value=\"ENVOYER\">
                </div>

            </div>
            <!-- End Profile Content -->
    </div>

    <!-- End Profile Content -->

    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>

{% endblock %}



", "notif/index.html.twig", "C:\\wamp64\\www\\appli-era\\app\\Resources\\views\\notif\\index.html.twig");
    }
}
