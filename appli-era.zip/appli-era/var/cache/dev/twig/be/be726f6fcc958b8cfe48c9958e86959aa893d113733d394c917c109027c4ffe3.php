<?php

/* :Business:index.html.twig */
class __TwigTemplate_fa5524d685534c744bf391cf62d5606c607e9f864da682c9dcc8561243776adb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("base.html.twig", ":Business:index.html.twig", 3);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_06d12153af9e9ca8c9d108a322d3922f25b7d39d865b12b998162526eb565ba8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_06d12153af9e9ca8c9d108a322d3922f25b7d39d865b12b998162526eb565ba8->enter($__internal_06d12153af9e9ca8c9d108a322d3922f25b7d39d865b12b998162526eb565ba8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Business:index.html.twig"));

        $__internal_b6d98626c60ad0499b3dd758fc38a88ae483bf2d277314ab28955f5e426581f3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b6d98626c60ad0499b3dd758fc38a88ae483bf2d277314ab28955f5e426581f3->enter($__internal_b6d98626c60ad0499b3dd758fc38a88ae483bf2d277314ab28955f5e426581f3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Business:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_06d12153af9e9ca8c9d108a322d3922f25b7d39d865b12b998162526eb565ba8->leave($__internal_06d12153af9e9ca8c9d108a322d3922f25b7d39d865b12b998162526eb565ba8_prof);

        
        $__internal_b6d98626c60ad0499b3dd758fc38a88ae483bf2d277314ab28955f5e426581f3->leave($__internal_b6d98626c60ad0499b3dd758fc38a88ae483bf2d277314ab28955f5e426581f3_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_4b7c355fe9ee9917889e8909f8d93efd3cad24f32b88a0e6c9d0e75a78985e91 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4b7c355fe9ee9917889e8909f8d93efd3cad24f32b88a0e6c9d0e75a78985e91->enter($__internal_4b7c355fe9ee9917889e8909f8d93efd3cad24f32b88a0e6c9d0e75a78985e91_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_e1de72d341a5bb222d3d16c139032070bde0a2be13278f8f28a49b607ec8a3e8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e1de72d341a5bb222d3d16c139032070bde0a2be13278f8f28a49b607ec8a3e8->enter($__internal_e1de72d341a5bb222d3d16c139032070bde0a2be13278f8f28a49b607ec8a3e8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "

    <div class=\"container content profile\">
        <div class=\"row\">
            <!--Left Sidebar-->
            <div class=\"col-md-3 md-margin-bottom-40\">

                ";
        // line 12
        $context["filename"] = (($this->getAttribute($this->getAttribute(($context["app"] ?? null), "user", array(), "any", false, true), "photo", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute($this->getAttribute(($context["app"] ?? null), "user", array(), "any", false, true), "photo", array()), "img32-md.jpg")) : ("img32-md.jpg"));
        // line 13
        echo "                ";
        $context["url"] = ((($context["globalUserPhotoUri"] ?? $this->getContext($context, "globalUserPhotoUri")) . "/") . ($context["filename"] ?? $this->getContext($context, "filename")));
        // line 14
        echo "                <img class=\"img-thumbnail\" id=\"photo\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl(($context["url"] ?? $this->getContext($context, "url"))), "html", null, true);
        echo "\"/>
                <br><br>
                <ul class=\"list-group sidebar-nav-v1 margin-bottom-40\" id=\"sidebar-nav-1\">
                    <li class=\"list-group-item active\">
                        <a href=\"#\"><i class=\"fa fa-bar-chart-o\"></i> Tableau de bord</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"";
        // line 21
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_profil");
        echo "\"><i class=\"fa fa-user\"></i> Profil</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"";
        // line 24
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_addreseau");
        echo "\"><i class=\"fa fa-group\"></i> Code d'affiliation</a>
                    </li>
                    <!--            <li class=\"list-group-item\">
                        <a href=\"";
        // line 27
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_addreseau");
        echo "\"><i class=\"fa fa-group\"></i> Reseau</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"";
        // line 30
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_addcda");
        echo "\"><i class=\"fa fa-group\"></i> Cda</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"";
        // line 33
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_addgagence");
        echo "\"><i class=\"fa fa-group\"></i> Groupe Agence</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"";
        // line 36
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_user_user_addreseau");
        echo "\"><i class=\"fa fa-group\"></i> Agence</a>
                    </li>

                    <li class=\"list-group-item\">
                        <a href=\"#\"><i class=\"fa fa-cog\"></i> Settings</a>
                    </li>

                    -->
                </ul>

            </div>
            <!--End Left Sidebar-->

            <!-- Profile Content -->
            <div class=\"col-md-9\">
                <div class=\"profile-body margin-bottom-20\">


                    <fieldset>
                        <div>
                            <div class=\"headline\"><h2>PROSPEC-FLY</h2></div>
                        </div>
                        <h3>Votre entreprise</h3>
                    </fieldset>

                    <fieldset>
                        ";
        // line 62
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start', array("attr" => array("novalidate" => "novalidate")));
        echo "
                        ";
        // line 63
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        echo "

                    </fieldset>
                    <button class=\"btn-u\" type=\"submit\">Valider</button>
                    ";
        // line 67
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        echo "

                </div>

            </div>
        </div>
        <!-- End Profile Content -->
    </div><!--/end row-->


";
        
        $__internal_e1de72d341a5bb222d3d16c139032070bde0a2be13278f8f28a49b607ec8a3e8->leave($__internal_e1de72d341a5bb222d3d16c139032070bde0a2be13278f8f28a49b607ec8a3e8_prof);

        
        $__internal_4b7c355fe9ee9917889e8909f8d93efd3cad24f32b88a0e6c9d0e75a78985e91->leave($__internal_4b7c355fe9ee9917889e8909f8d93efd3cad24f32b88a0e6c9d0e75a78985e91_prof);

    }

    public function getTemplateName()
    {
        return ":Business:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  144 => 67,  137 => 63,  133 => 62,  104 => 36,  98 => 33,  92 => 30,  86 => 27,  80 => 24,  74 => 21,  63 => 14,  60 => 13,  58 => 12,  49 => 5,  40 => 4,  11 => 3,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("

{% extends 'base.html.twig' %}
{% block body %}


    <div class=\"container content profile\">
        <div class=\"row\">
            <!--Left Sidebar-->
            <div class=\"col-md-3 md-margin-bottom-40\">

                {% set filename = app.user.photo|default('img32-md.jpg') %}
                {% set url = globalUserPhotoUri ~ '/' ~ filename %}
                <img class=\"img-thumbnail\" id=\"photo\" src=\"{{ asset(url) }}\"/>
                <br><br>
                <ul class=\"list-group sidebar-nav-v1 margin-bottom-40\" id=\"sidebar-nav-1\">
                    <li class=\"list-group-item active\">
                        <a href=\"#\"><i class=\"fa fa-bar-chart-o\"></i> Tableau de bord</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"{{ path('app_user_user_profil') }}\"><i class=\"fa fa-user\"></i> Profil</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"{{ path('app_user_user_addreseau') }}\"><i class=\"fa fa-group\"></i> Code d'affiliation</a>
                    </li>
                    <!--            <li class=\"list-group-item\">
                        <a href=\"{{ path('app_user_user_addreseau') }}\"><i class=\"fa fa-group\"></i> Reseau</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"{{ path('app_user_user_addcda') }}\"><i class=\"fa fa-group\"></i> Cda</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"{{ path('app_user_user_addgagence') }}\"><i class=\"fa fa-group\"></i> Groupe Agence</a>
                    </li>
                    <li class=\"list-group-item\">
                        <a href=\"{{ path('app_user_user_addreseau') }}\"><i class=\"fa fa-group\"></i> Agence</a>
                    </li>

                    <li class=\"list-group-item\">
                        <a href=\"#\"><i class=\"fa fa-cog\"></i> Settings</a>
                    </li>

                    -->
                </ul>

            </div>
            <!--End Left Sidebar-->

            <!-- Profile Content -->
            <div class=\"col-md-9\">
                <div class=\"profile-body margin-bottom-20\">


                    <fieldset>
                        <div>
                            <div class=\"headline\"><h2>PROSPEC-FLY</h2></div>
                        </div>
                        <h3>Votre entreprise</h3>
                    </fieldset>

                    <fieldset>
                        {{ form_start(form,{attr:{novalidate:'novalidate'}}) }}
                        {{ form_widget(form) }}

                    </fieldset>
                    <button class=\"btn-u\" type=\"submit\">Valider</button>
                    {{ form_end(form) }}

                </div>

            </div>
        </div>
        <!-- End Profile Content -->
    </div><!--/end row-->


{% endblock %}", ":Business:index.html.twig", "C:\\wamp64\\www\\appli-era\\app/Resources\\views/Business/index.html.twig");
    }
}
